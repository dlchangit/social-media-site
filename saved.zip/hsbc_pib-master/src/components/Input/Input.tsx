import React, { CSSProperties } from 'react';
import { useDebounce } from '../../hook/useDebounce';
import css from './Input.module.scss';
import cn from 'classnames';
import { useComponentVisible } from '../../hook/useComponentVisible';
import { useClickOutside } from '../../hook/useClickOutside';

const charToTriggerAutoComplete = 3;

export interface InputProps {
  type: string;
  className?: string;
  style?: CSSProperties;
  value?: string | number;
  rightIcon?: React.ReactElement;
  placeholder?: string;
  freeText?: boolean;
  autoCompleteCallback?: (keyword: string) => Promise<string[]>;
  inputThrottlingThreshold?: number;
  onChange: (value: string | number) => void;
  tabIndex?: number;
}

interface State {
  value: string | number;
  autoCompleteListFrom: string | null;
  autoCompleteList: string[];
  match: boolean;
}

type Action =
  | {
      action: 'clickSuggestion' | 'keyboardInput' | 'externalUpdate';
      value: string | number;
    }
  | { action: 'blur' }
  | { action: 'suggestionCallBack'; suggestion: string[]; autoCompleteListFrom: string | null };

export const Input: React.FC<InputProps> = (props) => {
  const {
    type,
    className,
    style,
    value,
    placeholder,
    freeText,
    autoCompleteCallback,
    onChange,
    rightIcon,
    inputThrottlingThreshold = 300,
    tabIndex,
  } = props;

  const inputRef = React.useRef<HTMLInputElement | null>(null);
  const { ref, isComponentVisible, setIsComponentVisible } = useComponentVisible(false, [inputRef]);
  const [state, onAction] = React.useReducer<React.Reducer<State, Action>>(
    (state, action) => {
      switch (action.action) {
        case 'clickSuggestion':
          onChange(action.value);
          return {
            value: action.value,
            autoCompleteList: [],
            autoCompleteListFrom: null,
            match: true,
          };
        case 'keyboardInput':
          if (!autoCompleteCallback || freeText) {
            onChange(action.value);
          }
          return { ...state, value: action.value, match: false };
        case 'externalUpdate':
          return { ...state, value: action.value };
        case 'blur':
          if (autoCompleteCallback && !freeText && !state.match) {
            return {
              value: '',
              autoCompleteList: [],
              autoCompleteListFrom: null,
              match: false,
            };
          }
          return state;
        case 'suggestionCallBack':
          return {
            ...state,
            autoCompleteList: action.suggestion,
            autoCompleteListFrom: action.autoCompleteListFrom,
          };
        default:
          console.error('Unexpected action', action);
          return state;
      }
    },
    {
      value: value || '',
      autoCompleteList: [],
      autoCompleteListFrom: '',
      match: false,
    }
  );
  const debouncedState = useDebounce(state, inputThrottlingThreshold);
  const autocompleteRefs: (HTMLButtonElement | null)[] = [];

  React.useEffect(() => {
    if (value != null) {
      onAction({ action: 'externalUpdate', value });
    }
  }, [value]);

  React.useEffect(() => {
    (async () => {
      if (autoCompleteCallback) {
        if (
          typeof debouncedState.value === 'string' &&
          debouncedState.value.length >= charToTriggerAutoComplete &&
          debouncedState.value !== debouncedState.autoCompleteListFrom
        ) {
          const list = await autoCompleteCallback(debouncedState.value);
          if (list.length === 1 && list[0] === debouncedState.value) {
            onAction({ action: 'suggestionCallBack', suggestion: [], autoCompleteListFrom: null });
            onAction({ action: 'clickSuggestion', value: debouncedState.value });
          } else {
            onAction({
              action: 'suggestionCallBack',
              suggestion: list,
              autoCompleteListFrom: debouncedState.value,
            });
          }
          return;
        }
      }
    })();
  }, [debouncedState]);

  useClickOutside(() => {
    onAction({ action: 'blur' });
  }, [ref, inputRef]);

  return (
    <div className={cn(css.wrapper, className)} style={style}>
      <input
        ref={inputRef}
        className={cn(css.input)}
        value={state.value}
        type={type}
        onChange={(event) => {
          const value = event.currentTarget.value;
          if (value !== state.value) {
            onAction({ action: 'keyboardInput', value: event.currentTarget.value });
          }
        }}
        onClick={() => setIsComponentVisible(true)}
        onKeyDown={(e) => {
          if (e.key === 'Tab' || e.key === 'ArrowDown') {
            const firstRef = autocompleteRefs[0];
            if (firstRef != null) {
              e.preventDefault();
              e.stopPropagation();
              firstRef.focus();
            }
          }
        }}
        placeholder={placeholder}
        tabIndex={tabIndex}
      />
      {rightIcon && <div className={css.rightIcon}>{rightIcon}</div>}
      {isComponentVisible && state.autoCompleteList.length > 0 && (
        <div ref={ref} className={cn(css.inputAutoCompleteList)}>
          {state.autoCompleteList.map((value, idx) => (
            <div key={value} className={css.inputAutoCompleteRow}>
              <div className={css.inputAutoCompleteCell}>
                <button
                  ref={(ref) => autocompleteRefs.push(ref)}
                  className={cn(css.inputAutoCompleteItem)}
                  onClick={() => onAction({ action: 'clickSuggestion', value })}
                  onKeyDown={(e) => {
                    if (e.key === 'ArrowUp' || e.key === 'ArrowDown' || e.key === 'Tab') {
                      e.stopPropagation();
                      e.preventDefault();
                      if (e.key === 'ArrowUp' || (e.key === 'Tab' && e.shiftKey)) {
                        if (idx > 0) {
                          autocompleteRefs[idx - 1]?.focus();
                        } else {
                          inputRef.current?.focus();
                        }
                      } else {
                        autocompleteRefs[idx + 1]?.focus();
                      }
                    }
                  }}
                >
                  {value}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
