import React, { CSSProperties } from 'react';
import { format, parse } from 'date-fns';
import cn from 'classnames';
import css from './InputDate.module.scss';
import { useDebounce } from '../../hook/useDebounce';
import useMergeRef from '../../hook/useMergeRef';

export interface InputDateProp {
  className?: string;
  dateFormat?: string;
  style?: CSSProperties;
  value?: Date;
  placeholder?: string;
  tabIndex?: number;
  onChange: (value: Date | null, error: boolean) => void;
  onEnterPressed?: () => void;
  _forceRerender?: number;
}

const allowedKey = /([0-9/]|Tab|Delete|Backspace|Enter)/;

function updateRange(
  text: string,
  start: number,
  end: number,
  target: string,
  replace?: boolean
): string {
  if (replace && start != end) {
    return text.slice(0, start) + target + text.slice(end);
  } else if (replace && start === end) {
    return text.slice(0, start) + target + text.slice(end + target.length);
  }
  return text.slice(0, start) + target + text.slice(end);
}

export const InputDate = React.forwardRef<HTMLInputElement, InputDateProp>((props, ref) => {
  const {
    className,
    style,
    value: originValue,
    placeholder,
    onChange,
    tabIndex,
    dateFormat = 'dd/MM/yyyy',
    _forceRerender,
    onEnterPressed,
  } = props;

  const [value, setValue] = React.useState<{ text: string; emit: boolean }>({
    text: originValue ? format(originValue, dateFormat) : '',
    emit: false,
  });
  const [error, setError] = React.useState(false);
  const inputRef = React.useRef<HTMLInputElement | null>(null);
  const finalRef = useMergeRef(ref, inputRef);
  const debouncedValue = useDebounce(value, 500);

  React.useEffect(() => {
    if (originValue != null) {
      const text = format(originValue, dateFormat);
      setValue({ text, emit: false });
      if (inputRef.current) {
        const { selectionStart, selectionEnd } = inputRef.current;
        inputRef.current.value = text;
        if (selectionStart && selectionEnd) {
          inputRef.current?.setSelectionRange(selectionStart, selectionEnd);
        }
      }
    }
  }, [originValue, _forceRerender]);

  // Select the clicked day, month or year, move the cursor to the beginning if clicking the end of the text
  const onClick = () => {
    const ref = inputRef?.current;
    if (ref == null) {
      return;
    }
    const { selectionStart, selectionEnd } = ref;
    if (selectionStart === 0 && selectionEnd === 0) {
      return;
    }
    if (selectionStart != null && selectionEnd != null && selectionStart === selectionEnd) {
      let start: number = selectionStart;
      let end: number = selectionStart;
      const text = ref.value;
      if (selectionStart === text.length) {
        start = 0;
        end = 0;
      } else {
        while (text[start - 1] != '/' && start > 0) {
          start--;
        }
        while (text[end] != '/' && end <= text.length) {
          end++;
        }
      }
      ref.setSelectionRange(start, end);
    }
  };

  const onInputChange = React.useCallback(
    (event: React.KeyboardEvent<HTMLInputElement>) => {
      const ref = inputRef?.current;
      if (ref == null) {
        return;
      }
      if (event.key !== 'Backspace' && event.key !== 'Delete' && (event.altKey || event.metaKey)) {
        // Ignored keystroke with alt/meta/shift
        return;
      }
      if (!allowedKey.test(event.key)) {
        if (event.key.length === 1) {
          event.preventDefault();
          event.stopPropagation();
        }
        // Ignored key like alphabetical char
        return;
      }

      let startIdx = ref.selectionStart || 0;
      let endIdx = ref.selectionEnd || 0;

      let text = inputRef?.current?.value ?? '';
      let cursorStart = startIdx;
      let cursorEnd = 0;

      if (event.key.length === 1) {
        // padding leading zero when user press '/'
        if (event.key === '/') {
          const textStriped = text.replaceAll('/', '');
          if (textStriped.length === 1) {
            text = '0' + textStriped + '/';
            cursorStart = 3;
          } else if (textStriped.length === 3) {
            text = updateRange(text, 3, 3, '0') + '/';
            cursorStart = 7;
          } else {
            text = updateRange(text, startIdx, endIdx, '/');
            cursorStart++;
          }
        } else {
          if (text.length === dateFormat?.length && startIdx === endIdx && text[startIdx] === '/') {
            startIdx += 1;
            endIdx += 1;
            cursorStart += 1;
          }
          text = updateRange(text, startIdx, endIdx, event.key, text.length === dateFormat?.length);
          cursorStart += 1;
          if ((text.length === 2 || text.length === 5) && text[text.length - 1] !== '/') {
            text += '/';
            cursorStart += 1;
          }
        }
      } else if (event.key === 'Backspace') {
        if (startIdx !== endIdx) {
          text = updateRange(text, startIdx, endIdx, '');
        } else if (startIdx > 0) {
          text = updateRange(text, startIdx - 1, endIdx, '');
          cursorStart -= 1;
        }
      } else if (event.key === 'Delete') {
        if (startIdx !== endIdx) {
          text = updateRange(text, startIdx, endIdx, '');
        } else {
          text = updateRange(text, startIdx, endIdx + 1, '');
        }
      } else if (event.key === 'Tab') {
        if (text.length === 0) {
          return;
        }
        if (event.shiftKey) {
          if (endIdx <= 2) {
            return;
          } else if (endIdx <= 5) {
            cursorStart = 0;
            cursorEnd = 2;
          } else {
            cursorStart = 3;
            cursorEnd = 5;
          }
        } else {
          if (endIdx <= 2) {
            cursorStart = 3;
            cursorEnd = 5;
          } else if (endIdx <= 5) {
            cursorStart = 6;
            cursorEnd = 10;
          } else {
            return;
          }
        }
      } else if (event.key === 'Enter') {
        event.preventDefault();
        event.stopPropagation();
        onEnterPressed && onEnterPressed();
        return;
      }
      cursorStart = Math.max(cursorStart, 0);
      text = text.slice(0, dateFormat?.length);
      ref.value = text;
      ref.setSelectionRange(cursorStart, cursorEnd || cursorStart);
      setValue({ text, emit: true });
      event.preventDefault();
      event.stopPropagation();
    },
    [inputRef]
  );

  React.useEffect(() => {
    if (!value) {
      setError(false);
      return;
    }

    const result = parse(value.text, dateFormat, new Date());
    if (isNaN(result.getTime())) {
      setError(true);
    } else {
      if (result.getUTCFullYear() < 1900) {
        return;
      }
      setError(false);
      value.emit && onChange(result, false);
    }
  }, [debouncedValue]);

  React.useEffect(() => {
    if (error) {
      onChange(null, true);
    }
  }, [error]);

  return (
    <div className={cn(css.wrapper)} style={style}>
      <input
        ref={finalRef}
        className={cn(css.input, { [css.error]: error }, className)}
        type={'string'}
        placeholder={placeholder}
        defaultValue={value.text}
        tabIndex={tabIndex}
        onMouseUp={onClick}
        onDoubleClick={() => inputRef?.current?.setSelectionRange(0, 10)}
        onKeyDown={onInputChange}
      />
    </div>
  );
});
