import React, { MutableRefObject, useRef, useState } from 'react';
import cn from 'classnames';
import { toArray } from '../../utils/dom';
import { Button } from '../Button';
import { IconChevronLeft, IconChevronRight } from '../Icon';
import css from './Carousel.module.scss';

export interface CarouselProps {
  className?: string;
  style?: React.CSSProperties;
  children: React.ReactElement | React.ReactElement[];
  anchorOfAll: React.ReactElement;
}

export const Carousel: React.FC<CarouselProps> = (props) => {
  const { className, style, children, anchorOfAll } = props;
  const [currentKey, setCurrentKey] = useState(0);

  // useEffect(() => {
  // const timer = setInterval(() => {
  //   setCurrentKey(getNextKey());
  // }, 2000);
  // return () => clearInterval(timer);
  // }, [currentKey]);

  const kids = toArray(children);
  const size = kids.length;

  const getNextKey = () => {
    let newKey = currentKey + 1;
    if (newKey >= size) {
      newKey = 0;
    }
    return newKey;
  };

  const getPreviousKey = () => {
    let newKey = currentKey - 1;
    if (newKey < 0) {
      newKey = size - 1;
    }
    return newKey;
  };

  const getNewChild = (child: React.ReactElement, index: number) => {
    if (!child) return null;

    const isActive = currentKey === index;

    const childCls = cn(css.carouselContent, { [css.carouselContentActive]: isActive });
    const ref = useRef() as MutableRefObject<HTMLDivElement>;

    let style = {};
    if (ref.current) {
      style = {
        transform: `translateX(-${ref.current.offsetLeft}px)`,
      };
    }

    return (
      <div ref={ref} key={index} className={childCls} aria-hidden={!isActive} style={style}>
        {child}
      </div>
    );
  };

  return (
    <div className={cn(css.carousel, className)} style={style}>
      <div className={css.carouselContentWrapper}>{toArray(children).map(getNewChild)}</div>
      <div className={css.carouselFooter}>
        {anchorOfAll}
        <div className={css.carouselButtonGroup}>
          <Button onClick={() => setCurrentKey(getPreviousKey())} icon={<IconChevronLeft />} />
          <Button onClick={() => setCurrentKey(getNextKey())} icon={<IconChevronRight />} />
        </div>
      </div>
    </div>
  );
};
