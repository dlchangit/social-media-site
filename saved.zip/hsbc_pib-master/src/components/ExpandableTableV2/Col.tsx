import React from 'react';
import cn from 'classnames';
import css from './ExpandableTableV2.module.scss';
import { Space } from '../Space';
import { IconChevronDown } from '../Icon';
import { TypographyProps } from '../Typography';
import { SortDirection } from '../../utils/sort';

export interface TableColV2Props<T> {
  align?: 'left' | 'center' | 'right';
  weight?: TypographyProps['weight'];
  className?: string;
  style?: React.CSSProperties;

  header: string | (() => React.ReactElement);

  defaultSortDirection?: SortDirection;

  sorting?(a: T, B: T, direction: SortDirection): 1 | -1 | 0;

  render(data: T, isExpanded: boolean, setIsExpanded: (arg: boolean) => void): React.ReactChild;

  expandClassName?: string;

  expand?(data: T, isExpanded: boolean, setIsExpanded: (arg: boolean) => void): React.ReactElement;
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function TableColV2<T>(props: TableColV2Props<T>): JSX.Element {
  return <></>;
}

TableColV2.displayName = 'TableColV2Props';

export interface ExpandControlV2Props {
  isActive: boolean;
  className?: string;
  style?: React.CSSProperties;

  onClick?(event: React.MouseEvent): void;
}

export const ExpandControlV2: React.FC<ExpandControlV2Props> = (props) => {
  const { isActive, className, style, onClick, children } = props;

  const cls = cn(css.expandIcon, { [css.expandIconActive]: isActive });

  const render = () => {
    if (children) {
      return (
        <Space align={'center'}>
          <IconChevronDown className={cls} />
          {children}
        </Space>
      );
    } else {
      return <IconChevronDown className={cls} />;
    }
  };
  return (
    <button className={cn(css.expandButton, className)} onClick={onClick} style={style}>
      {render()}
    </button>
  );
};
