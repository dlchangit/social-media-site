import React, { useEffect, useState } from 'react';
import cn from 'classnames';

import css from './ExpandableTableV2.module.scss';
import { toArray } from '../../utils/dom';
import { TableColV2, TableColV2Props } from './Col';
import { nextSortDirection, SortDirection } from '../../utils/sort';
import { Typography } from '../Typography';
import { Space } from '../Space';
import { Button } from '../Button';
import { IconSort, IconSortAscending, IconSortDescending } from '../Icon';

export interface ExpandableTableV2Props<T> {
  emptyView?: React.ReactElement;
  errorView?: React.ReactNode;
  loadingView?: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
  children: React.ReactElement | React.ReactElement[];
  data: T[];
}

export function ExpandableTableV2<T>(props: ExpandableTableV2Props<T>): JSX.Element {
  const { emptyView, errorView, loadingView, className, style, data, children } = props;

  const kids = toArray(children).filter((it) => it.type === TableColV2) as React.ReactElement<
    TableColV2Props<T>
  >[];

  const colSize = kids.length;

  const [sortedData, setSortedData] = useState([...data]);
  const [expandRows, setExpandRows] = useState(
    Array.from({ length: data.length }).map(() => false)
  );
  const [sortDirections, setSortDirections] = useState(
    kids.map((it) => ({
      direction: it.props.defaultSortDirection ?? SortDirection.NONE,
      algorithm: it.props.sorting,
    }))
  );

  const onSortChange = () => {
    const sort = sortDirections.find((it) => it.direction !== SortDirection.NONE);
    if (sort === undefined) {
      setSortedData([...data]);
      setExpandRows(data.map(() => false));
    } else {
      const alg = sort.algorithm;
      if (typeof alg === 'function') {
        const sorted = [...data].sort((a, b) => {
          return alg(a, b, sort.direction);
        });
        setSortedData(sorted);
        setExpandRows(sorted.map(() => false));
      }
    }
  };

  useEffect(() => {
    onSortChange();
  }, [JSON.stringify(data), sortDirections]);

  const renderView = () => {
    if (errorView) {
      return (
        <td colSpan={colSize} className={css.viewContainer}>
          {errorView}
        </td>
      );
    }
    if (loadingView) {
      return (
        <td colSpan={colSize} className={css.viewContainer}>
          {loadingView}
        </td>
      );
    }
    if (data.length === 0) {
      return (
        <td colSpan={colSize} className={css.viewContainer}>
          {emptyView}
        </td>
      );
    }
    return null;
  };

  const renderContent = () => {
    const view = renderView();
    if (view) {
      return <tr>{view}</tr>;
    }

    return sortedData.map((rowData, rowIndex) => {
      const isExpanded = expandRows[rowIndex] ?? false;
      const setIsExpanded = (toggle: boolean) => {
        const updatedExpandRows = expandRows.map(() => false);
        if (updatedExpandRows[rowIndex] !== undefined) {
          updatedExpandRows[rowIndex] = toggle;
        }
        setExpandRows(updatedExpandRows);
      };

      let nested = undefined;
      let nestedClassName = undefined;
      return (
        <React.Fragment key={rowIndex}>
          <tr>
            {kids.map((col, colIndex) => {
              const { align = 'right', className, expandClassName } = col.props;

              if (typeof col.props.expand === 'function') {
                nested = col.props.expand(rowData, isExpanded, setIsExpanded);
                nestedClassName = expandClassName;
              }
              return (
                <Typography size={6} weight={'light'} key={colIndex}>
                  <td className={cn(css.tableCol, className)} align={align} valign={'top'}>
                    {col.props.render(rowData, isExpanded, setIsExpanded)}
                  </td>
                </Typography>
              );
            })}
          </tr>
          <tr aria-expanded={isExpanded} className={cn({ [css.hide]: !isExpanded })}>
            <td colSpan={kids.length} className={nestedClassName}>
              {nested}
            </td>
          </tr>
        </React.Fragment>
      );
    });
  };

  const headers = kids.map((col, index) => {
    const direction = sortDirections[index].direction;
    const { align = 'right', weight = 'medium', className } = col.props;

    return (
      <td
        key={index}
        aria-sort={direction}
        align={align}
        valign={'top'}
        className={cn(css.tableHeader, css.tableCol, className)}
      >
        <Space justify={align === 'right' ? 'end' : 'start'} align={'start'}>
          <Typography size={6} weight={weight} className={css.wordBreak}>
            {typeof col.props.header === 'function' ? col.props.header() : col.props.header}
          </Typography>
          {col.props.sorting && (
            <Button
              type={'raw'}
              className={css.buttonSort}
              onClick={() => {
                const updated = sortDirections.map((it, i) => {
                  if (i === index) {
                    return {
                      direction: nextSortDirection(it.direction),
                      algorithm: it.algorithm,
                    };
                  }
                  return {
                    direction: SortDirection.NONE,
                    algorithm: it.algorithm,
                  };
                });
                setSortDirections(updated);
              }}
            >
              <span className={cn(css.hide, { [css.show]: direction === SortDirection.NONE })}>
                <IconSort />
              </span>
              <span className={cn(css.hide, { [css.show]: direction === SortDirection.ASC })}>
                <IconSortAscending />
              </span>
              <span className={cn(css.hide, { [css.show]: direction === SortDirection.DESC })}>
                <IconSortDescending />
              </span>
            </Button>
          )}
        </Space>
      </td>
    );
  });

  return (
    <table className={cn(css.tableWrapper, className)} style={style}>
      <thead>
        <tr>{headers}</tr>
      </thead>
      <tbody>{renderContent()}</tbody>
    </table>
  );
}
