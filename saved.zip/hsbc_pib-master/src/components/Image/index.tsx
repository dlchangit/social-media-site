import React from 'react';
import styled from 'styled-components';

import imgAssetManagement from './assets/icn_01_dashboard_asset_management_28x28@2x.png';
import imgDataChart from './assets/icn_01_dashboard_data_chart_28x28@2x.png';
import imgInvestment from './assets/icn_01_dashboard_investment_28x28@2x.png';
import imgLiquidity from './assets/icn_01_dashboard_liquidity_management_28x28@2x.png';
import imgHoldingsEmpty from './assets/icn_02_holdings_detail_EmptyState_64x64@2x.png';

export interface ImageProps extends React.HTMLAttributes<HTMLImageElement> {
  alt?: string;
}

const Image = styled.img`
  display: block;
  width: 28px;
  height: 28px;
`;

export const ImageAssetManagement: React.FC<ImageProps> = (props) => {
  return <Image src={imgAssetManagement} {...props} />;
};
export const ImageDataChart: React.FC<ImageProps> = (props) => {
  return <Image src={imgDataChart} {...props} />;
};
export const ImageInvestment: React.FC<ImageProps> = (props) => {
  return <Image src={imgInvestment} {...props} />;
};
export const ImageLiquidity: React.FC<ImageProps> = (props) => {
  return <Image src={imgLiquidity} {...props} />;
};
export const ImageHoldingEmpty: React.FC<ImageProps> = (props) => {
  return <Image src={imgHoldingsEmpty} {...props} />;
};
