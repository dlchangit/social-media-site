import React from 'react';
import { formatDigits } from '../../utils/math';

import arrowUp from './icn_position_up_16x8@2x.png';
import arrowDown from './icn_position_down_18x9@2x.png';
import { IconAddWatch, IconBuy, IconSell } from '../Icon';
import { Button } from '../Button';

import css from './Holding.module.scss';
import cn from 'classnames';
import { Typography } from '../Typography';
import { QuickMenu } from '../QuickMenu/QuickMenu';

export interface HoldingProps {
  stock: string;
  symbol: string;
  currency: string;
  amount: number;
  percentage: number;
  style?: React.CSSProperties;
}

export const Holding: React.FC<HoldingProps> = (props) => {
  const { stock, symbol, currency, amount, percentage, ...rest } = props;

  const renderPercentage = (percentage: number) => {
    if (percentage >= 0) {
      return (
        <div className={cn(css.percentage, css.green)}>
          <img className={css.icon} src={arrowUp} alt="" />
          <span>+{formatDigits(percentage)}%</span>
        </div>
      );
    }

    return (
      <div className={cn(css.percentage, css.red)}>
        <img className={css.icon} src={arrowDown} alt="" />
        <span>{formatDigits(percentage)}%</span>
      </div>
    );
  };

  return (
    <div className={css.holding} {...rest}>
      <div className={css.info}>
        <div className={css.long}>{stock}</div>
        <Typography className={css.short} size={6} weight={'light'}>
          {symbol}
        </Typography>
      </div>
      <Typography className={css.number} size={6} weight={'medium'}>
        <div className={css.amount}>{currency + ' ' + formatDigits(amount)}</div>
        {renderPercentage(percentage)}
      </Typography>
      <QuickMenu>
        {(_, setVisible) => (
          <>
            <Button
              type="text"
              icon={<IconBuy />}
              block
              className={css.icon}
              onClick={() => setVisible(false)}
            >
              Quick buy
            </Button>
            <Button
              type="text"
              icon={<IconSell />}
              block
              className={css.icon}
              onClick={() => setVisible(false)}
            >
              Quick sell
            </Button>
            <Button
              type="text"
              icon={<IconAddWatch />}
              block
              className={css.icon}
              onClick={() => setVisible(false)}
            >
              Add to wishlist
            </Button>
          </>
        )}
      </QuickMenu>
    </div>
  );
};
