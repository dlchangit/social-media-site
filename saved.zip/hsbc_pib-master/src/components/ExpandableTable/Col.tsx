import React, { forwardRef, useEffect, useState } from 'react';
import cn from 'classnames';
import css from './ExpandableTable.module.scss';
import { Space } from '../Space';
import { IconSort, IconSortAscending, IconSortDescending } from '../Icon';
import { Button } from '../Button';
import { Typography, TypographyProps } from '../Typography';
import { SortDirection } from '../../utils/sort';

export interface TableColProps extends React.HTMLAttributes<HTMLDivElement> {
  align?: 'left' | 'center' | 'right';
  weight?: TypographyProps['weight'];
}

export const TableCol = forwardRef<HTMLDivElement, TableColProps>((props, ref) => {
  const { className, style, children, align = 'left', weight = 'light', ...rest } = props;
  const cls = cn(css.col, css[`text-${align}`], className);

  return (
    <Typography size={6} weight={weight}>
      <div ref={ref} role="gridcell" className={cls} style={style} {...rest}>
        {children}
      </div>
    </Typography>
  );
});
TableCol.displayName = 'TableCol';

export interface SortableTableColProps extends React.HTMLAttributes<HTMLDivElement> {
  defaultDirection?: SortDirection;
  direction?: SortDirection;
  children: React.ReactChild;
  onSortChange?: (direction: SortDirection) => void;
}

export const SortableTableCol = forwardRef<HTMLDivElement, SortableTableColProps>((props, ref) => {
  const { children, defaultDirection, onSortChange, direction, ...rest } = props;

  const [internalDirection, setInternalDirection] = useState<SortDirection>(
    ('direction' in props ? direction : defaultDirection) ?? SortDirection.NONE
  );

  useEffect(() => {
    if ('direction' in props) {
      setInternalDirection(direction ?? SortDirection.NONE);
    }
  }, [direction]);

  const onSort = () => {
    let newDirection = internalDirection;
    if (internalDirection === SortDirection.NONE) {
      newDirection = SortDirection.DESC;
    }
    if (internalDirection === SortDirection.DESC) {
      newDirection = SortDirection.ASC;
    }
    if (internalDirection === SortDirection.ASC) {
      newDirection = SortDirection.NONE;
    }
    if (typeof onSortChange === 'function') {
      onSortChange(newDirection);
    }

    if (!('direction' in props)) {
      setInternalDirection(newDirection);
    }
  };

  return (
    <TableCol ref={ref} {...rest} align={'right'} weight={'medium'} aria-sort={internalDirection}>
      <Space justify={'end'} align={'start'}>
        <span className={css.break}>{children}</span>
        <Button type={'raw'} className={css.buttonSort} onClick={onSort}>
          <span className={cn(css.hide, { [css.show]: internalDirection === SortDirection.NONE })}>
            <IconSort />
          </span>
          <span className={cn(css.hide, { [css.show]: internalDirection === SortDirection.ASC })}>
            <IconSortAscending />
          </span>
          <span className={cn(css.hide, { [css.show]: internalDirection === SortDirection.DESC })}>
            <IconSortDescending />
          </span>
        </Button>
      </Space>
    </TableCol>
  );
});
SortableTableCol.displayName = 'SortableTableCol';
