import React, { forwardRef, useState } from 'react';
import cn from 'classnames';
import css from './ExpandableTable.module.scss';
import { toArray } from '../../utils/dom';
import { Typography } from '../Typography';
import { Space } from '../Space';
import { isFragment } from 'react-is';

type Element = React.ReactElement | React.ReactElement[];

export interface TableRowProps extends React.HTMLAttributes<HTMLDivElement> {
  children: Element | Element[];
  header?: boolean;
}

export const TableRow = forwardRef<HTMLDivElement, TableRowProps>((props, ref) => {
  const { className, style, children, header, ...rest } = props;

  const cls = cn(css.row, { [css.rowHeader]: header }, className);
  const kids = toArray(children);

  return (
    <Typography size={6}>
      <Space ref={ref} role="row" className={cls} style={style} {...rest}>
        {kids.map((it, index) => {
          return React.cloneElement(it, {
            key: index,
            ...it.props,
            role: header ? 'columnheader' : undefined,
            className: cn(it.props.className, { [css.colLast]: index === kids.length - 1 }),
          });
        })}
      </Space>
    </Typography>
  );
});
TableRow.displayName = 'TableRow';

export interface ExpandableTableRowProps extends React.HTMLAttributes<HTMLDivElement> {
  children: (
    isExpanded: boolean,
    setExpanded: (expanded: boolean) => void
  ) => React.ReactElement | React.ReactElement[];
  expandChild: React.ReactElement | React.ReactElement[];
}

export const ExpandableTableRow = forwardRef<HTMLDivElement, ExpandableTableRowProps>(
  (props, ref) => {
    const [isExpanded, setExpanded] = useState(false);
    const { className, style, children, expandChild, ...rest } = props;

    const ele = children(isExpanded, setExpanded);
    const kids = toArray(isFragment(ele) ? ele.props.children : ele);

    return (
      <Typography size={6} weight={'light'}>
        <div ref={ref} role="row" className={cn(css.row, className)} style={style} {...rest}>
          <Space>
            {kids.map((it, index) => {
              return React.cloneElement(it, {
                key: index,
                ...it.props,
                className: cn(it.props?.className, { [css.colLast]: index === kids.length - 1 }),
              });
            })}
          </Space>
          {isExpanded && expandChild}
        </div>
      </Typography>
    );
  }
);
ExpandableTableRow.displayName = 'ExpandableTableRow';
