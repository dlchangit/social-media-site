import React from 'react';
import cn from 'classnames';

import css from './ExpandableTable.module.scss';
import { toArray } from '../../utils/dom';

export interface ExpandableTableProps {
  emptyView?: React.ReactElement;
  errorView?: React.ReactNode;
  loadingView?: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
  header: React.ReactElement | React.ReactElement[];
  children: React.ReactElement | React.ReactElement[];
}

export const ExpandableTable: React.FC<ExpandableTableProps> = (prop: ExpandableTableProps) => {
  const { emptyView, errorView, loadingView, className, style, header, children } = prop;

  const kids = toArray(children);

  const renderContent = () => {
    if (errorView) {
      return <div className={css.viewContainer}>{errorView}</div>;
    }
    if (loadingView) {
      return <div className={css.viewContainer}>{loadingView}</div>;
    }
    if (kids.length === 0) {
      return <div className={css.viewContainer}>{emptyView}</div>;
    }

    return kids.map((it, index) => {
      return React.cloneElement(it, {
        key: index,
        'aria-rowindex': index,
        ...it.props,
        className: cn(it.props.className, { [css.rowLast]: index === kids.length - 1 }),
      });
    });
  };

  return (
    <div className={cn(css.tableWrapper, className)} style={style} role="grid">
      {header}
      {renderContent()}
    </div>
  );
};
