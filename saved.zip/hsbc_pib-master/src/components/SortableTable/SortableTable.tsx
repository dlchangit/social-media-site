import React, {
  CSSProperties,
  ReactNode,
  ReactNodeArray,
  useCallback,
  useEffect,
  useState,
} from 'react';

import { Typography } from '../Typography';
import cn from 'classnames';
import { IconRefresh, IconSort, IconSortAscending, IconSortDescending } from '../Icon';
import { ImageHoldingEmpty } from '../Image';
import { Button } from '../Button';
import { LoadResult } from '../Result';

import css from './SortableTable.module.scss';

export interface SortableTableProp<T> {
  data: T[];
  columns: Column<T>[];
  emptyView?: React.ReactElement;
  errorView?: React.ReactElement;
  loadingView?: React.ReactElement;
  fontSize?: 5 | 6;
  defaultSortState?: SortState<T>[];
  multipleSort?: boolean;
  externalSort?: boolean; // If sort by API
  style?: CSSProperties;
  className?: string;
}

type SortCol<T> = (a: T, b: T, sort: Sort) => number;
type Formatter<T> = (t: T) => string | ReactNode | ReactNodeArray;

export interface Column<Row> {
  key: keyof Row;
  label: string;
  fixed?: boolean; // fixed at LHS when scroll horizontally
  sortable?: boolean;
  bold?: boolean;
  width?: number | string;
  align?: 'left' | 'center' | 'right';
  formatter?: Formatter<Row>;
  sortFn?: SortCol<Row>; // For frontend sort
  onColumnSort?: (sort: Sort) => void; // For API sort
}

export enum Sort {
  Ascending,
  Descending,
}

interface SortState<T> {
  key: keyof T;
  sort: Sort;
}

function compare<T>(a: T, b: T, key: keyof T, sort: Sort, sortFn?: SortCol<T>): number {
  if (sortFn != null) {
    return sortFn(a, b, sort);
  }
  const valueA = a[key];
  const valueB = b[key];
  if (typeof valueA === 'string' && typeof valueB === 'string') {
    return sort === Sort.Ascending ? valueA.localeCompare(valueB) : valueB.localeCompare(valueA);
  }
  if (typeof valueA === 'number' && typeof valueB === 'number') {
    if (sort === Sort.Ascending) {
      return valueA >= valueB ? 1 : valueA === valueB ? 0 : -1;
    } else {
      return valueA >= valueB ? -1 : valueA === valueB ? 0 : 1;
    }
  }
  return 0;
}

const SortIcon: React.FC<{ sort?: Sort }> = (prop: { sort?: Sort }) => {
  return (
    <div className={css.sortIcon}>
      {prop.sort == null && <IconSort />}
      {prop.sort == Sort.Ascending && <IconSortAscending />}
      {prop.sort == Sort.Descending && <IconSortDescending />}
    </div>
  );
};

export const LoadingView: React.FC<{ message: string }> = ({ message }) => {
  return <LoadResult label={message} />;
};

export const EmptyView: React.FC<{ message: string }> = ({ message }) => {
  return (
    <>
      <ImageHoldingEmpty className={css.emptyViewImg} />
      <Typography size={6}>{message}</Typography>
    </>
  );
};

export const ErrorView: React.FC<{ message: string; refresh?: () => void }> = ({
  message,
  refresh,
}) => {
  return (
    <>
      <Typography size={6}>{message}</Typography>
      {refresh && (
        <Button icon={<IconRefresh />} onClick={refresh} type={'text'}>
          Refresh
        </Button>
      )}
    </>
  );
};

export function SortableTable<T>(prop: SortableTableProp<T>): JSX.Element {
  const {
    data,
    columns,
    fontSize,
    defaultSortState,
    emptyView,
    errorView,
    loadingView,
    multipleSort,
    externalSort,
    className,
    style,
  } = prop;
  const [sortState, setSortState] = useState<SortState<T>[]>(defaultSortState ?? []);
  const [sortedData, setSortedData] = useState<T[]>(data);

  const onColumnSort = useCallback(
    (key: keyof T) => {
      const currentState = sortState.find((it) => it.key === key)?.sort;
      const removedList = sortState.filter((it) => it.key !== key);
      const newList = multipleSort ? removedList : [];
      if (currentState === Sort.Ascending) {
        newList.push({ key, sort: Sort.Descending });
      } else if (currentState == null) {
        newList.push({ key, sort: Sort.Ascending });
      }
      setSortState(newList);
    },
    [sortState]
  );

  useEffect(() => {
    if (externalSort) {
      return;
    }
    setSortedData(
      sortState.reduce(
        (acc: T[], curr) => {
          return acc.sort((a, b) => {
            const sortFn = columns.find((col) => col.key === curr.key)?.sortFn;
            return compare(a, b, curr.key, curr.sort, sortFn);
          });
        },
        [...data]
      )
    );
  }, [sortState]);

  useEffect(() => {
    setSortedData(data);
  }, [data]);

  return (
    <div className={cn(css.tableWrapper, className)} style={style}>
      <table className={css.table}>
        <thead>
          <tr>
            {columns.map((col) => (
              <th
                key={col.label}
                className={cn(css[col.align ?? 'left'], {
                  [css.sortable]: col.sortable,
                })}
                onClick={() => col.sortable && onColumnSort(col.key)}
                style={{ width: col.width }}
              >
                <div className={css.header}>
                  <Typography
                    size={fontSize ?? 6}
                    weight={'regular'}
                    className={cn({ [css.bold]: col.bold })}
                  >
                    {col.label}
                  </Typography>
                  {col.sortable && (
                    <SortIcon sort={sortState.find((it) => it.key === col.key)?.sort} />
                  )}
                </div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {errorView == null &&
            loadingView == null &&
            sortedData &&
            sortedData.map((row, rowIdx) => (
              <tr key={rowIdx}>
                {columns.map((col, colIdx) => (
                  <td key={`${rowIdx}-${colIdx}`} className={cn(css[col.align ?? 'left'])}>
                    <Typography size={fontSize ?? 6}>
                      {col.formatter ? col.formatter(row) : row[col.key]}
                    </Typography>
                  </td>
                ))}
              </tr>
            ))}
        </tbody>
      </table>
      {errorView == null && loadingView == null && sortedData.length === 0 && (
        <div className={css.viewContainer}>{emptyView}</div>
      )}
      {errorView && <div className={css.viewContainer}>{errorView}</div>}
      {loadingView && <div className={css.viewContainer}>{loadingView}</div>}
    </div>
  );
}
