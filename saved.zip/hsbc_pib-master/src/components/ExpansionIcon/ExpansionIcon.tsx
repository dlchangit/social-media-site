import React from 'react';
import { IconChevronDown } from '../Icon';
import cn from 'classnames';
import css from './ExpansionIcon.module.scss';

export interface ExpansionIconProps {
  className?: string;
  style?: React.CSSProperties;
  active?: boolean;
}

export const ExpansionIcon: React.VFC<ExpansionIconProps> = (props) => {
  const { className, style, active } = props;
  return (
    <IconChevronDown className={cn(css.icon, { [css.active]: active }, className)} style={style} />
  );
};
