import React from 'react';

import cn from 'classnames';
import css from './CurrencyWithPercent.module.scss';

import { formatDigits } from '../../utils/math';

export interface CurrencyAmountProps {
  currency: string;
  amount: number;
  percent: number;
}

export const CurrencyPercent: React.FC<CurrencyAmountProps> = (props) => {
  const { currency, amount, percent } = props;

  let internalColor: typeof css.green | typeof css.green | null = null;
  if (amount > 0) {
    internalColor = css.green;
  }
  if (amount < 0) {
    internalColor = css.red;
  }
  const prefix = amount > 0 ? '+' : '-';

  const cls = cn(css.currency, internalColor);

  return (
    <div className={cls}>
      <div className={cn(css.amount)}>
        {prefix}
        <span>{currency + ' ' + formatDigits(Math.abs(amount))}</span>
      </div>
      <div className={cn(css.amount)}>
        {prefix}
        <span>{formatDigits(Math.abs(percent))}%</span>
      </div>
    </div>
  );
};
