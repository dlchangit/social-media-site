import React, { MutableRefObject, useLayoutEffect, useRef } from 'react';
import * as am4core from '@amcharts/amcharts4/core';
import * as am4charts from '@amcharts/amcharts4/charts';
import { XYChart } from '@amcharts/amcharts4/charts';
import { CategoryData, DateChartProps } from './interface';
import {
  CHART_COLORS,
  FONT_COLOR,
  FONT_REGULAR,
  FONT_SIZE_S5,
  FONT_SIZE_S6,
  TOOLTIP_BACKGROUND_COLOR,
  TOOLTIP_BORDER_COLOR,
} from './util';

const barWidth = 40;

export const DateChart: React.FC<DateChartProps> = React.memo((props) => {
  const { id, data, valueTitle, style, loadingResult, emptyResult } = props;

  const ref = useRef() as MutableRefObject<XYChart>;

  useLayoutEffect(() => {
    const chart = am4core.create(id, am4charts.XYChart);
    ref.current = chart;

    chart.paddingTop = 50;
    // chart.numberFormatter.numberFormat = '#,###.00';
    chart.numberFormatter.numberFormat = {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    };

    const dateAxis = chart.xAxes.push(new am4charts.DateAxis());
    dateAxis.renderer.grid.template.disabled = true;
    dateAxis.renderer.grid.template.location = 0;
    dateAxis.renderer.minGridDistance = 0;
    dateAxis.fontSize = FONT_SIZE_S6;
    dateAxis.baseInterval = {
      timeUnit: 'month',
      count: 1,
    };
    dateAxis.dateFormats.setKey('month', 'MMM');
    dateAxis.periodChangeDateFormats.setKey('month', 'MMM\nyyyy');
    dateAxis.renderer.labels.template.textAlign = 'middle';
    dateAxis.renderer.labels.template.marginTop = 8;

    const valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
    valueAxis.renderer.minGridDistance = 50;
    valueAxis.renderer.grid.template.location = 0;
    valueAxis.layout = 'absolute';
    if (valueTitle) {
      valueAxis.title.text = valueTitle;
      valueAxis.title.rotation = 0;
      valueAxis.title.align = 'right';
      valueAxis.title.valign = 'top';
      valueAxis.title.dx = -10;
      valueAxis.title.dy = -50;
      valueAxis.fontSize = FONT_SIZE_S6;
    }

    const series = chart.series.push(new am4charts.ColumnSeries());
    series.dataFields.dateX = 'date';
    series.dataFields.valueY = 'value';
    series.columns.template.width = barWidth;
    series.columns.template.fill = am4core.color(CHART_COLORS[0]);
    series.columns.template.strokeWidth = 0;
    //move to top of the bar
    series.columns.template.tooltipY = am4core.percent(0);
    series.columns.template.hoverOnFocus = true;
    // series.columns.template.alwaysShowTooltip = true;

    if (series.tooltip) {
      series.tooltip.pointerOrientation = 'vertical';
      series.tooltip.getFillFromObject = false;
      series.tooltip.label.fill = am4core.color(FONT_COLOR);
      series.tooltip.label.fontSize = FONT_SIZE_S5;
      series.tooltip.label.fontFamily = FONT_REGULAR.family;
      series.tooltip.background.fill = am4core.color(TOOLTIP_BACKGROUND_COLOR);
      series.tooltip.background.fillOpacity = 1;
      series.tooltip.background.stroke = am4core.color(TOOLTIP_BORDER_COLOR);
      series.tooltip.background.strokeWidth = 2;
      series.tooltip.background.cornerRadius = 0;
      //remove shadow & blur
      series.tooltip.background.filters.clear();
    }

    chart.data = data;

    const tooltipHandler = (event: any) => {
      const item = event.target.column.dataItem;
      const ctx = item?.dataContext as CategoryData;

      if (item && series.tooltip && ctx?.tooltipFormatter) {
        series.columns.template.tooltipHTML = ctx.tooltipFormatter(item) as string;
        // series.columns.template.tooltipText = ctx.tooltipFormatter(item) as string;
      }
    };
    series.columns.template.events.on('focus', tooltipHandler);
    series.columns.template.events.on('over', tooltipHandler);

    return () => {
      chart.dispose();
    };
  }, [data, valueTitle]);

  if (loadingResult) {
    return loadingResult;
  }
  if (data.length === 0) {
    return emptyResult;
  }
  return <div id={id} style={style} />;
});

DateChart.displayName = 'DateChart';
