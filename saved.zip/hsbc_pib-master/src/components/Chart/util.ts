import * as am4core from '@amcharts/amcharts4/core';
import { FontWeight, Label, RoundedRectangle } from '@amcharts/amcharts4/core';
import { Legend } from '@amcharts/amcharts4/charts';

export const FONT_SIZE_S5 = '1rem';
export const FONT_SIZE_S6 = '0.875rem';
export const RADIUS_RATIO = 0.48;

//14 colors
export const CHART_COLORS = [
  '#6D8EA6',
  '#14A5AB',
  '#4FA62F',
  '#E67310',
  '#D71E8D',
  '#834EFF',
  '#2580DC',
  '#4D6474',
  '#008580',
  '#34880F',
  '#BF610F',
  '#A8166D',
  '#6637D5',
  '#1564B5',
];

export const FONT_COLOR = '#333333';
export const BORDER_COLOR = '#979797';
export const GRID_COLOR = '#EDEDED';
export const TOOLTIP_BACKGROUND_COLOR = '#FFFFFF';
export const TOOLTIP_BORDER_COLOR = '#D7D8D6';

export const FONT_REGULAR = {
  family: 'Univers Next for HSBC Regular',
  weight: '400' as FontWeight,
};

export const FONT_MEDIUM = {
  family: 'Univers Next for HSBC Medium',
  weight: '500' as FontWeight,
};

export const FONT_LIGHT = {
  family: 'Univers Next for HSBC Light',
  weight: '300' as FontWeight,
};

/**
 * create legends with squared marker, font style
 * @important do not put label settings here, will not work
 */
export function createLegend(): Legend {
  const legend = new Legend();

  const sprite = legend.markers.template.children.getIndex(0) as RoundedRectangle;
  sprite.cornerRadius(0, 0, 0, 0);

  // legend.scrollable = true;
  // legend.itemContainers.template.paddingTop = 12;
  legend.itemContainers.template.clickable = false;
  legend.itemContainers.template.focusable = false;
  legend.itemContainers.template.cursorOverStyle = am4core.MouseCursorStyle.default;
  legend.fontFamily = 'Univers Next for HSBC Regular';
  legend.fontSize = FONT_SIZE_S6;

  return legend;
}

export function createTooltipLabel(style?: { bold?: boolean; light?: boolean }): Label {
  const label = new am4core.Label();
  label.wrap = true;
  label.horizontalCenter = 'middle';
  label.verticalCenter = 'middle';
  label.textAlign = 'middle';
  label.fontSize = FONT_SIZE_S6;
  label.fill = am4core.color(FONT_COLOR);
  label.fontFamily = FONT_REGULAR.family;
  label.fontWeight = FONT_REGULAR.weight;

  if (style?.bold) {
    label.fontFamily = FONT_MEDIUM.family;
    label.fontWeight = FONT_MEDIUM.weight;
  }

  if (style?.light) {
    label.fontFamily = FONT_LIGHT.family;
    label.fontWeight = FONT_LIGHT.weight;
  }
  return label;
}
