import React, { useLayoutEffect } from 'react';
import * as am4core from '@amcharts/amcharts4/core';
import * as am4charts from '@amcharts/amcharts4/charts';
import { RoundedRectangle } from '@amcharts/amcharts4/core';
import { CHART_COLORS, FONT_LIGHT, FONT_SIZE_S6 } from './util';

export interface ChartProps {
  id: string;
  data: { id: string; value: string }[];
  labels?: { id: string; label: string }[];
  style?: React.CSSProperties;
  legendFormatter?: (label: string, value: string) => string;
}

interface Data {
  category: string;
  from: number;
  to: number;
  name: string;
  fill: am4core.Color;
}

export const HoldingChart: React.FC<ChartProps> = (props) => {
  const { id, labels, data, style, legendFormatter } = props;

  useLayoutEffect(() => {
    const chart = am4core.create(id, am4charts.XYChart);

    const colorSet = new am4core.ColorSet();
    // Map data
    chart.data = data.reduce(
      (acc: { start: number; array: Data[] }, { id, value }, index) => {
        const to = acc.start + parseFloat(value);
        const label = labels?.find((it) => it.id === id)?.label ?? id;

        let name = label;
        if (legendFormatter) {
          name = legendFormatter(label, value);
        }

        let fill = colorSet.next();
        const color = CHART_COLORS[index];
        if (color != null) {
          fill = am4core.color(color);
        }

        acc.array.push({
          category: '',
          from: acc.start,
          to,
          name,
          fill,
        });
        acc.start = to;
        return acc;
      },
      { start: 0, array: [] }
    ).array;

    // Create axes
    const yAxis = chart.yAxes.push(new am4charts.CategoryAxis());
    yAxis.dataFields.category = 'category';
    yAxis.renderer.grid.template.disabled = true;
    yAxis.renderer.labels.template.disabled = true;

    const xAxis = chart.xAxes.push(new am4charts.ValueAxis());
    xAxis.renderer.grid.template.disabled = true;
    xAxis.renderer.labels.template.disabled = true;
    xAxis.renderer.baseGrid.disabled = true;
    xAxis.max = 1;

    // Create series
    const series = chart.series.push(new am4charts.ColumnSeries());
    series.dataFields.valueX = 'to';
    series.dataFields.openValueX = 'from';
    series.dataFields.categoryY = 'category';
    series.columns.template.propertyFields.fill = 'fill';
    series.columns.template.stroke = am4core.color('#ffffff');
    series.columns.template.strokeOpacity = 1;
    series.columns.template.strokeWidth = 4;
    series.columns.template.height = 30;

    // Legend
    const legend = new am4charts.Legend();
    legend.parent = chart.chartContainer;
    legend.markers.template.width = 14;
    legend.markers.template.height = 14;
    const sprite = legend.markers.template.children.getIndex(0) as RoundedRectangle;
    sprite.cornerRadius(0, 0, 0, 0);
    legend.fontFamily = FONT_LIGHT.family;
    legend.fontWeight = FONT_LIGHT.weight;
    legend.fontSize = FONT_SIZE_S6;
    legend.marginTop = 28;
    legend.marginBottom = 28;
    // legend.contentValign = 'top';
    legend.itemContainers.template.clickable = false;
    legend.itemContainers.template.focusable = false;
    legend.itemContainers.template.cursorOverStyle = am4core.MouseCursorStyle.default;
    legend.contentAlign = 'left';
    legend.data = chart.data;

    return () => {
      chart.dispose();
    };
  }, [data, labels, legendFormatter]);

  return <div id={id} style={style} />;
};
