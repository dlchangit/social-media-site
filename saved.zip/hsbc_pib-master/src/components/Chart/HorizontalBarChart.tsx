import React, { MutableRefObject, useLayoutEffect, useRef } from 'react';
import * as am4core from '@amcharts/amcharts4/core';
import * as am4charts from '@amcharts/amcharts4/charts';
import { CategoryChartProps } from './interface';
import { BORDER_COLOR, CHART_COLORS, FONT_SIZE_S6, GRID_COLOR } from './util';

const barHeight = 24;
const barSpacing = 16;

export const HorizontalBarChart: React.FC<CategoryChartProps> = (props) => {
  const { id, data, valueTitle, style, loadingResult, emptyResult } = props;

  const ref = useRef() as MutableRefObject<HTMLDivElement>;
  // const chartRef = useRef() as MutableRefObject<am4charts.XYChart>;
  // const labelRef = useRef() as MutableRefObject<am4core.Label>;
  //
  // useEffect(() => {
  //   let resizeObserver: ResizeObserver;
  //
  //   const ro = new ResizeObserver((_, observer) => {
  //     if (!ref.current) return;
  //     resizeObserver = observer;
  //     console.log('resize....');
  //     const valueAxis = chartRef.current.xAxes.getIndex(0);
  //     if (labelRef.current && valueAxis) {
  //       console.log('put.??');
  //       labelRef.current.dx = -valueAxis.axisFullLength - 20;
  //     }
  //   });
  //   ro.observe(ref?.current);
  //   return () => {
  //     resizeObserver && resizeObserver.disconnect();
  //   };
  // }, []);

  useLayoutEffect(() => {
    const chart = am4core.create(id, am4charts.XYChart);
    // chartRef.current = chart;

    chart.paddingRight = 30;
    chart.data = data;

    chart.chartContainer.userClassName = 'chart-container-class';
    chart.chartAndLegendContainer.userClassName = 'chart-and-legend-container-class';
    chart.seriesContainer.userClassName = 'series-container-class';
    chart.topAxesContainer.userClassName = 'top-axis-container-class';
    chart.bottomAxesContainer.userClassName = 'bottom-axis-container-class';
    chart.yAxesAndPlotContainer.userClassName = 'yaxis-plot-container-class';

    const categoryAxis = chart.yAxes.push(new am4charts.CategoryAxis());

    categoryAxis.dataFields.category = 'category';
    categoryAxis.renderer.inversed = true;
    categoryAxis.renderer.grid.template.disabled = true;
    categoryAxis.renderer.grid.template.location = 0;
    categoryAxis.renderer.minGridDistance = 1;

    //axis line
    categoryAxis.renderer.line.strokeOpacity = 1;
    categoryAxis.renderer.line.strokeWidth = 1;
    categoryAxis.renderer.line.stroke = am4core.color(BORDER_COLOR);

    categoryAxis.fontSize = FONT_SIZE_S6;
    categoryAxis.renderer.cellStartLocation = -0.5;
    categoryAxis.renderer.cellEndLocation = 1.5;

    const valueAxis = chart.xAxes.push(new am4charts.ValueAxis());
    valueAxis.min = 0;
    valueAxis.fontSize = FONT_SIZE_S6;
    valueAxis.renderer.grid.template.stroke = am4core.color(GRID_COLOR);
    valueAxis.renderer.grid.template.strokeWidth = 1;
    valueAxis.renderer.grid.template.strokeOpacity = 1;
    valueAxis.renderer.gridContainer.userClassName = 'grid-container-class';

    //disable grid line for zero
    valueAxis.renderer.baseGrid.disabled = true;

    //axis line
    valueAxis.renderer.line.strokeOpacity = 1;
    valueAxis.renderer.line.strokeWidth = 0;
    valueAxis.renderer.line.stroke = am4core.color(BORDER_COLOR);

    // format axis label
    valueAxis.renderer.labels.template.fontSize = FONT_SIZE_S6;
    valueAxis.numberFormatter.numberFormat = '#.00';
    valueAxis.adjustLabelPrecision = false;

    // chart.bottomAxesContainer.valign = 'middle';
    // const label = chart.bottomAxesContainer.createChild(am4core.Label);
    // labelRef.current = label;
    // label.text = valueTitle;
    // label.fontSize = fontSize;
    // label.align = 'right';
    // label.dy = -27;

    if (valueTitle) {
      valueAxis.title.text = valueTitle;
    }

    const series = chart.series.push(new am4charts.ColumnSeries());
    series.dataFields.categoryY = 'category';
    series.dataFields.valueX = 'value';
    series.columns.template.height = barHeight;
    series.columns.template.fill = am4core.color(CHART_COLORS[0]);
    series.columns.template.strokeWidth = 0;

    const cellSize = barHeight + barSpacing;
    chart.events.on('ready', () => {
      // Get objects of interest
      const categoryAxis = chart.yAxes.getIndex(0);
      if (!chart || !chart.svgContainer || !categoryAxis) {
        return;
      }

      // Calculate how we need to adjust chart height
      const adjustHeight = chart.data.length * cellSize - categoryAxis.pixelHeight;
      // get current chart height
      const targetHeight = chart.pixelHeight + adjustHeight;
      // Set it on chart's container
      chart.svgContainer.htmlElement.style.height = targetHeight + 'px';
    });

    return () => {
      chart.dispose();
    };
  }, [data]);

  if (loadingResult) {
    return loadingResult;
  }
  if (data.length === 0) {
    return emptyResult;
  }
  return <div id={id} style={style} ref={ref} />;
};
