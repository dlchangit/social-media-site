import React, { MutableRefObject, useLayoutEffect, useRef } from 'react';
import * as am4core from '@amcharts/amcharts4/core';
import { Container, Percent } from '@amcharts/amcharts4/core';
import * as am4charts from '@amcharts/amcharts4/charts';
import { PieChart } from '@amcharts/amcharts4/charts';
import { CategoryChartProps, CategoryData } from './interface';
import { CHART_COLORS, createLegend, FONT_MEDIUM, FONT_SIZE_S5, RADIUS_RATIO } from './util';
import { Space } from '../Space';
import css from './Chart.module.scss';
import cn from 'classnames';

export const DonutChart: React.FC<CategoryChartProps> = (props) => {
  const { id, data, valueTitle, style, loadingResult, emptyResult } = props;

  const ref = useRef() as MutableRefObject<HTMLDivElement>;

  // useEffect(() => {
  //   let resizeObserver: ResizeObserver;
  //   const ro = new ResizeObserver((_, observer) => {
  //     resizeObserver = observer;
  //   });
  //   ro.observe(ref.current);
  //   return () => {
  //     resizeObserver && resizeObserver.disconnect();
  //   };
  // }, []);

  useLayoutEffect(() => {
    const chart = am4core.create(id, PieChart);

    const normalized = data.sort((a, b) => {
      if (a.value === b.value) {
        return 0;
      }
      //sort descending
      return a.value > b.value ? -1 : 1;
    });

    chart.chartContainer.userClassName = 'chart-container-class';
    chart.chartAndLegendContainer.userClassName = 'chart-and-legend-container-class';
    chart.seriesContainer.userClassName = 'series-container-class';

    chart.chartContainer.layout = 'absolute';
    // chart.chartAndLegendContainer.background.fill = new Color({ r: 0, g: 0, b: 255 });

    //useless
    // chart.chartContainer.verticalCenter = 'top';
    // chart.chartAndLegendContainer.verticalCenter = 'top';
    // chart.chartContainer.valign = 'top';
    // chart.chartContainer.contentValign = 'top';
    // chart.chartAndLegendContainer.contentValign = 'top';
    // chart.chartAndLegendContainer.valign = 'top';

    chart.chartContainer.padding(0, 0, 0, 0);
    chart.chartAndLegendContainer.padding(0, 0, 0, 0);
    chart.seriesContainer.padding(0, 0, 0, 0);

    chart.innerRadius = am4core.percent(RADIUS_RATIO * 100);
    chart.data = normalized;

    const pieSeries = chart.series.push(new am4charts.PieSeries());

    //rotate
    pieSeries.startAngle = 90;
    pieSeries.endAngle = 450;

    pieSeries.dataFields.value = 'value';
    pieSeries.dataFields.category = 'category';

    //disable labels and tooltips
    pieSeries.labels.template.disabled = true;
    pieSeries.ticks.template.disabled = true;
    pieSeries.slices.template.tooltipText = '';

    //disable click to magnify
    pieSeries.slices.template.clickable = false;

    //add gaps between slices
    pieSeries.slices.template.stroke = am4core.color('#fff');
    pieSeries.slices.template.strokeWidth = 4;
    pieSeries.slices.template.strokeOpacity = 1;
    pieSeries.hiddenState.properties.opacity = 1;
    pieSeries.hiddenState.properties.endAngle = -90;
    pieSeries.hiddenState.properties.startAngle = -90;

    //fill color
    pieSeries.colors.list = CHART_COLORS.map((it) => am4core.color(it));

    const nested = am4core.create(id + '-legend', Container);
    nested.userClassName = 'nested-class';
    nested.height = new Percent(100);
    nested.layout = 'vertical';
    // nested.background.fill = new Color({ r: 100, g: 100, b: 100 });

    const legend = createLegend();

    if (valueTitle) {
      const legendTitle = nested.createChild(am4core.Label);
      legendTitle.text = valueTitle;
      legendTitle.fontFamily = FONT_MEDIUM.family;
      legendTitle.fontWeight = FONT_MEDIUM.weight;
      legendTitle.fontSize = FONT_SIZE_S5;
    }

    const lc = nested.createChild(am4core.Container);
    lc.userClassName = 'legend-class';
    // lc.background.fill = new Color({ r: 200, g: 200, b: 200 });
    chart.legend = legend;
    chart.legend.parent = lc;
    chart.legend.position = 'right';

    //no ellipsis
    legend.maxWidth = undefined as never;
    legend.valueLabels.template.align = 'left';
    legend.valueLabels.template.textAlign = 'start';
    legend.valueLabels.template.text = "({value.percent.formatNumber('#.0')}%)";

    const spacing = 12;
    const legendHeight = 23;
    legend.itemContainers.template.paddingTop = 0;
    legend.itemContainers.template.marginLeft = 0;
    legend.itemContainers.template.paddingBottom = spacing;
    const cellSize = legendHeight + spacing;
    chart.events.on('datavalidated', () => {
      //add 24 for title line, 24 for padding-bottom;
      if (nested.htmlContainer) {
        nested.htmlContainer.style.minHeight = cellSize * chart.data.length + 24 + 24 + 'px';
      }
    });

    //tooltip center
    const tooltipContainer = new am4core.Container();
    tooltipContainer.parent = pieSeries;
    tooltipContainer.layout = 'vertical';
    tooltipContainer.horizontalCenter = 'middle';
    tooltipContainer.verticalCenter = 'middle';

    //tooltip label
    const label = new am4core.Label();
    label.parent = tooltipContainer;
    label.horizontalCenter = 'middle';
    label.verticalCenter = 'middle';

    //tooltip word break
    const focusHandler = (event: any) => {
      tooltipContainer.disposeChildren();
      const item = event.target.slice.dataItem;
      const ctx = item?.dataContext as CategoryData;
      tooltipContainer.maxWidth = Math.floor(chart.seriesContainer.contentWidth * RADIUS_RATIO);

      if (item && ctx?.tooltipFormatter) {
        const container = ctx.tooltipFormatter(item) as Container;
        container.parent = tooltipContainer;
      }
    };

    //tooltip event
    pieSeries.slices.template.events.on('over', focusHandler);
    pieSeries.slices.template.events.on('focus', focusHandler);
    pieSeries.slices.template.events.on('out', () => {
      tooltipContainer.disposeChildren();
    });

    return () => {
      console.log('dispose');
      chart.dispose();
    };
  }, [data, valueTitle]);

  const hide = loadingResult || data.length === 0;

  return (
    <Space style={style} ref={ref} wrap={true} justify={'center'}>
      <div id={id} className={cn(css.flex, { [css.hide]: hide })} />
      <div id={id + '-legend'} className={cn(css.legendWrapper, { [css.hide]: hide })} />
      <div style={{ display: !hide ? 'none' : undefined }} className={css.result}>
        {loadingResult}
        {!loadingResult && data.length === 0 ? emptyResult : undefined}
      </div>
    </Space>
  );
};
