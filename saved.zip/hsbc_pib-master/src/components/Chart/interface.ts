import React from 'react';
import * as am4core from '@amcharts/amcharts4/core';
import { DataItem } from '@amcharts/amcharts4/core';

export interface CategoryData {
  category: string;
  value: number;
  tooltipFormatter?: (target: DataItem) => am4core.Container | string;
}

interface DateData {
  date: string;
  value: number;
}

interface BaseChartProps {
  id: string;
  valueTitle?: string;
  style?: React.CSSProperties;

  emptyResult: React.ReactElement;
  loadingResult?: React.ReactElement;
}

export interface CategoryChartProps extends BaseChartProps {
  data: CategoryData[];
}

export interface DateChartProps extends BaseChartProps {
  data: DateData[];
}
