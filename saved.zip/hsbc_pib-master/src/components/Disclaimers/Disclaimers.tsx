import React, { CSSProperties } from 'react';
import { Expand } from '../Expand/Expand';
import { Typography } from '../Typography';
import css from './Disclaimers.module.scss';

export interface DisclaimersProps {
  title: string;
  content: string;
  style?: CSSProperties;
  className?: string;
}

export const Disclaimers: React.FC<DisclaimersProps> = (props) => {
  const { title, content, style, className } = props;
  return (
    <Expand
      style={style}
      className={className}
      title={
        <Typography size={5} weight={'light'}>
          {title}
        </Typography>
      }
    >
      <div className={css.content}>
        <Typography size={6} weight={'light'}>
          {content}
        </Typography>
      </div>
    </Expand>
  );
};
