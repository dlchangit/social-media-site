import React, { forwardRef } from 'react';
import cn from 'classnames';
import css from './Anchor.module.scss';
import chevronLeft from './icn_01_dashboard_chevron-left_8x11@2x.png';
import chevronRight from './icn_chevron_right_thick_8x12@2x.png';

export interface ChevronAnchorProps extends React.HTMLAttributes<HTMLAnchorElement> {
  children: React.ReactNode;
  href: string;
  target?: '_blank' | '_self' | '_parent' | '_top';
  direction?: 'forward' | 'backward' | false;
}

export const ChevronAnchor = forwardRef<HTMLAnchorElement, ChevronAnchorProps>((props, ref) => {
  const { children, href, target, direction = 'forward', className, ...rest } = props;

  const cls = cn(css.anchor, { [css.flex]: direction === 'backward' }, className);

  const isPlain =
    typeof children === 'string' || typeof children === 'boolean' || typeof children === 'number';

  const labelCls = cn({
    [css.rightMargin]: isPlain && direction === 'forward',
    [css.leftMargin]: isPlain && direction === 'backward',
  });

  const renderLabel = () => {
    if (isPlain) {
      return <span className={labelCls}>{children}</span>;
    }
    return children;
  };

  return (
    <a ref={ref} {...rest} className={cls} href={href} target={target} rel="noreferrer">
      {direction === 'backward' && (
        <span className={css.chevron}>
          <img src={chevronLeft} alt="" />
        </span>
      )}
      {renderLabel()}
      {direction === 'forward' && (
        <span className={css.chevron}>
          <img src={chevronRight} alt="" />
        </span>
      )}
    </a>
  );
});
