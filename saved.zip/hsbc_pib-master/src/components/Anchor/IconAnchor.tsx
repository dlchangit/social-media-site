import React, { forwardRef } from 'react';
import cn from 'classnames';
import css from './Anchor.module.scss';

export interface IconAnchorProps extends React.HTMLAttributes<HTMLAnchorElement> {
  href: string;
  children: string;
  icon?: React.ReactElement;
  className?: string;
  style?: React.CSSProperties;
}

export const IconAnchor = forwardRef<HTMLAnchorElement, IconAnchorProps>((props, ref) => {
  const { className, style, icon, href, children } = props;
  const cls = cn(css.anchor, css.flex, className);

  return (
    <a ref={ref} className={cls} style={style} href={href}>
      {icon && <span className={cn(css.icon, css.rightMargin)}>{icon}</span>}
      <span>{children}</span>
    </a>
  );
});

IconAnchor.displayName = 'IconAnchor';
