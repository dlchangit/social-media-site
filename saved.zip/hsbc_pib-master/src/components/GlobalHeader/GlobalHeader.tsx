import cn from 'classnames';
import css from './GlobalHeader.module.scss';
import React from 'react';

export const GlobalHeader: React.VFC = () => {
  return <div className={cn(css.globalHeader)}>HSBC global header</div>;
};
