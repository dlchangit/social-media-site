import React, { isValidElement } from 'react';
import cn from 'classnames';
import css from './Button.module.scss';

export interface ButtonProps extends React.HTMLAttributes<HTMLButtonElement> {
  type?: 'default' | 'text' | 'raw';
  disabled?: boolean;
  icon?: React.ReactElement<HTMLImageElement>;

  block?: boolean;
  round?: boolean;
  selected?: boolean;
  primary?: boolean;
  secondary?: boolean;
  htmlType?: 'submit' | 'reset' | 'button';
  align?: 'left' | 'center' | 'right';
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>((props, ref) => {
  const {
    className,
    children,
    disabled,
    icon,
    primary,
    secondary,
    type = 'default',
    round,
    block,
    selected,
    htmlType = 'button',
    align = 'center',
    ...rest
  } = props;

  const cls = cn(
    css.button,
    {
      [css.disabled]: disabled,
      [css.block]: block,
      [css.round]: round,
      [css.selected]: selected,
      [css.primary]: primary,
      [css.secondary]: secondary,
      [css.icon]: icon && !children,
    },
    align && css[align],
    type && css[type],
    className
  );

  let kids = children;
  if (children !== undefined && !isValidElement(children)) {
    kids = <span>{children}</span>;
  }

  return (
    <button
      ref={ref}
      className={cls}
      disabled={disabled}
      aria-disabled={disabled}
      type={htmlType}
      {...rest}
    >
      {icon && <span className={css.prefix}>{icon}</span>}
      {kids}
    </button>
  );
});
