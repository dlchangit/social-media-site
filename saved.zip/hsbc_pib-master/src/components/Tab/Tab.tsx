import React, { isValidElement, useEffect, useState } from 'react';
import { toArray } from '../../utils/dom';
import { Typography } from '../Typography';
import css from './Tab.module.scss';
import cn from 'classnames';

export interface TabProps {
  defaultKey?: string;
  onChange?: (key?: React.Key) => void;
  children: React.ReactElement[];
  className?: string;
}

export interface TabPaneProps {
  title: string;
  key: React.Key;
}

export const TabPane: React.FC<TabPaneProps> = (props) => {
  return <>{props.children}</>;
};

export const Tab: React.FC<TabProps> = (props) => {
  const { defaultKey, onChange, children, className } = props;
  const [activeKey, setActiveKey] = useState<React.Key | undefined>(defaultKey ?? undefined);

  const tabs = toArray(children)
    .filter((node) => isValidElement(node))
    .map((node: React.ReactElement<TabPaneProps>) => {
      return {
        ...node.props,
        node,
        key: node.key as React.Key | undefined,
      };
    })
    .filter((it) => it);

  useEffect(() => {
    onChange && onChange(activeKey);
  }, [activeKey]);

  const handleTabChange = (key?: React.Key) => {
    setActiveKey(key);
    if (typeof onChange === 'function') {
      onChange(key);
    }
  };

  return (
    <div className={cn(css.tab, className)}>
      <div className={css.tabBtnRow}>
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => handleTabChange(tab.key)}
            className={cn(css.tabBtn, { [css.active]: tab.key === activeKey })}
          >
            <Typography size={5} weight={'light'}>
              {tab.title}
            </Typography>
          </button>
        ))}
        <div className={css.tabBtnFiller} />
      </div>
      {tabs.filter((tab) => tab.key === activeKey).map((tab) => tab.node)}
    </div>
  );
};
