import { MutableRefObject } from 'react';

export const focusOption = (
  refs: MutableRefObject<HTMLElement>[],
  currentRef: MutableRefObject<HTMLElement>,
  direction: 'upward' | 'downward'
): void => {
  const current = refs.findIndex((it) => it === currentRef);
  if (current === undefined) {
    return;
  }
  if (direction === 'upward') {
    for (let i = current - 1; i >= 0; i--) {
      const ref = refs[i];
      if (ref.current?.getAttribute('aria-disabled') !== 'true') {
        ref.current?.focus();
        break;
      }
    }
  } else {
    for (let i = current + 1; i < refs.length; i++) {
      const ref = refs[i];
      if (ref.current?.getAttribute('aria-disabled') !== 'true') {
        ref.current?.focus();
        break;
      }
    }
  }
};
