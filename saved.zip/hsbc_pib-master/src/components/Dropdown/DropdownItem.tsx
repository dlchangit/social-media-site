import React from 'react';

export interface DropdownItemProps extends React.HTMLAttributes<HTMLButtonElement> {
  value: string;
  disabled?: boolean;
  children: string | React.ReactElement;
}

export const DropdownItem: React.FC<DropdownItemProps> = (props) => {
  if (typeof props.children === 'string') {
    return <span>{props.children}</span>;
  } else {
    return props.children as React.ReactElement;
  }
};
