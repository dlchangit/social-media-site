import React, {
  createRef,
  CSSProperties,
  MutableRefObject,
  ReactElement,
  ReactFragment,
  useEffect,
  useRef,
  useState,
} from 'react';
import cn from 'classnames';
import css from './Dropdown.module.scss';

import { useComponentVisible } from '../../hook/useComponentVisible';
import { DropdownItem, DropdownItemProps } from './DropdownItem';
import { Checkbox } from '../Checkbox';
import { Popover } from '../Popover';
import { IconChevronDown } from '../Icon';
import { toArray } from '../../utils/dom';
import { focusOption } from './util';

export interface MultipleDropdownProps {
  disabled?: boolean;
  onChange?: (values: string[]) => void;

  placeholder: string;
  allOption?: string;
  values?: string[];
  defaultValues?: string[];

  className?: string;
  style?: CSSProperties;
  children: ReactElement | ReactElement[] | ReactFragment;
}

interface OptionData {
  index: number;
  value: string;
  active: boolean;
  disabled: boolean;
  divider: boolean;
}

export const MultipleDropdown: React.FC<MultipleDropdownProps> = (props) => {
  const {
    placeholder,
    allOption,
    className,
    style,

    defaultValues,
    children,

    onChange,
    disabled,
  } = props;

  const buttonRef = useRef() as MutableRefObject<HTMLButtonElement>;
  const { ref, isComponentVisible, setIsComponentVisible } = useComponentVisible(false, [
    buttonRef,
  ]);

  const [selectedValues, setSelectedValue] = useState<Set<string>>(
    new Set(props.values !== undefined ? props.values : defaultValues ?? [])
  );
  const [displayLabel, setDisplayLabel] = useState(placeholder);

  const optionRefs: MutableRefObject<HTMLInputElement>[] = [];

  const chevronCls = cn(css.chevron, { [css.active]: isComponentVisible });
  const btnCls = cn(css.dropdown, { [css.disabled]: disabled });

  const onControl = (
    event: React.KeyboardEvent<HTMLDivElement>,
    currentRef: MutableRefObject<HTMLDivElement>
  ) => {
    if (event.key === 'ArrowUp') {
      event.preventDefault();
      focusOption(optionRefs, currentRef, 'upward');
    }
    if (event.key === 'ArrowDown') {
      event.preventDefault();
      focusOption(optionRefs, currentRef, 'downward');
    }
    if (event.key === 'Escape') {
      event.preventDefault();
      setIsComponentVisible(false);
      buttonRef.current?.focus();
    }
  };

  const renderItem = (children: React.ReactElement, option: OptionData) => {
    const onSelect = () => {
      if (option.disabled) return;
      const newSelected = new Set(selectedValues);
      if (option.value) {
        if (newSelected.has(option.value)) {
          newSelected.delete(option.value);
        } else {
          newSelected.add(option.value);
        }
      }
      if (!('values' in props)) {
        setSelectedValue(newSelected);
      }
      if (onChange) {
        onChange(Array.from(newSelected));
      }
    };

    const optionRef = createRef() as MutableRefObject<HTMLInputElement>;
    optionRefs.push(optionRef);

    return (
      <Checkbox
        ref={optionRef}
        data-value={option.value}
        key={option.index}
        className={cn(css.optionItem, { [css.divider]: option.divider })}
        checked={option.active}
        onChange={onSelect}
        intermediate={false}
        disabled={option.disabled}
        onKeyDown={(event) => onControl(event, optionRef)}
      >
        {children}
      </Checkbox>
    );
  };

  useEffect(() => {
    if ('values' in props) {
      setSelectedValue(new Set(props.values ?? []));
    }
  }, [JSON.stringify(props.values)]);

  useEffect(() => {
    if (selectedValues === null || selectedValues === undefined || selectedValues.size === 0) {
      setDisplayLabel(placeholder);
    } else {
      let label: string;
      if (allOption && selectedValues.size === availableKids().length) {
        label = allOption;
      } else {
        label = kids
          .filter((it) => {
            return it && selectedValues.has(it.props['data-value']);
          })
          .map((it) => it?.props?.children?.props?.children)
          .join(', ');
      }
      setDisplayLabel(label);
    }
  }, [selectedValues]);

  const childrenArray = toArray(children);
  const childValueSet = new Set(childrenArray.map((it) => it.props.value));

  const kids = childrenArray.map((child: React.ReactElement<DropdownItemProps>, index: number) => {
    if (child.type === DropdownItem) {
      return renderItem(child, {
        index,
        value: child.props.value,
        active: selectedValues?.has(child.props.value),
        disabled: child.props.disabled ?? false,
        divider: index < childrenArray.length,
      });
    } else {
      return (
        <div
          className={cn(css.optionItem, { [css.divider]: index < childrenArray.length })}
          key={index}
        >
          {child}
        </div>
      );
    }
  });

  const onToggle = () => {
    if (!disabled) {
      setIsComponentVisible(!isComponentVisible);
    }
  };

  const toggleAll = (event: React.ChangeEvent<HTMLInputElement>) => {
    let newSelected = new Set<string>();
    const filtered = availableKids();
    if (event.target.checked) {
      newSelected = new Set(filtered.map((it) => it?.props['data-value']));
    }
    if (!('values' in props)) {
      setSelectedValue(newSelected);
    }
    if (typeof onChange === 'function') {
      onChange(Array.from(newSelected));
    }
  };

  const availableKids = () => {
    return kids.filter((it) => it?.type === Checkbox && !it?.props?.disabled);
  };

  const renderAllOption = () => {
    if (allOption) {
      let checked = false;
      let intermediate = false;
      if (selectedValues.size > 0) {
        intermediate = true;
      }
      if (selectedValues.size === availableKids().length) {
        checked = true;
        intermediate = false;
      }
      const optionRef = createRef() as MutableRefObject<HTMLInputElement>;
      optionRefs.unshift(optionRef);

      return (
        <Checkbox
          ref={optionRef}
          className={cn(css.optionItem, { [css.divider]: childrenArray.length === 0 })}
          intermediate={intermediate}
          checked={checked}
          onChange={toggleAll}
          onKeyDown={(event) => onControl(event, optionRef)}
        >
          {allOption}
        </Checkbox>
      );
    }
  };

  if (childValueSet.size !== childrenArray.length) {
    console.warn('Warning! Duplicate value on DropdownItem!');
    return <></>;
  }

  return (
    <Popover
      visible={isComponentVisible}
      fullWidth={true}
      style={style}
      className={className}
      content={
        <div ref={ref} className={css.optionList} role="listbox">
          {renderAllOption()}
          {kids}
        </div>
      }
    >
      <div className={css.wrapper}>
        <button
          ref={buttonRef}
          className={btnCls}
          onClick={onToggle}
          aria-haspopup="listbox"
          aria-expanded={isComponentVisible}
          aria-pressed={isComponentVisible}
          aria-disabled={disabled}
          onKeyDown={(event) => {
            if (event.key === 'Enter') {
              event.preventDefault();
              onToggle();
            }
            if (event.key === 'Escape') {
              event.preventDefault();
              setIsComponentVisible(false);
            }
          }}
        >
          <div className={css.label}>{displayLabel || ''}</div>
          <div className={css.verticalBar} />
          <IconChevronDown className={chevronCls} alt="dropdown" />
        </button>
      </div>
    </Popover>
  );
};
