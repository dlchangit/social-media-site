import React, { CSSProperties, MutableRefObject, useEffect, useRef, useState } from 'react';
import cn from 'classnames';
import css from './Dropdown.module.scss';

import { useComponentVisible } from '../../hook/useComponentVisible';
import { toArray } from '../../utils/dom';
import { DropdownItem, DropdownItemProps } from './DropdownItem';
import { Popover } from '../Popover';
import { IconChevronDown } from '../Icon';
import { focusOption } from './util';

export interface SingleDropdownProps {
  disabled?: boolean;
  onChange?: (value?: string) => void;

  placeholder: string;
  value?: string;
  defaultValue?: string;

  className?: string;
  style?: CSSProperties;
  children: React.ReactElement | React.ReactElement[];
}

interface OptionData {
  index: number;
  value?: string;
  active: boolean;
  disabled: boolean;
}

export const SingleDropdown: React.FC<SingleDropdownProps> = (props) => {
  const {
    placeholder,
    className,
    style,

    defaultValue,
    children,

    onChange,
    disabled,
  } = props;

  const buttonRef = useRef() as MutableRefObject<HTMLButtonElement>;
  const { ref, isComponentVisible, setIsComponentVisible } = useComponentVisible(false, [
    buttonRef,
  ]);
  const [selectedValue, setSelectedValue] = useState(props.value ?? defaultValue);
  const [displayLabel, setDisplayLabel] = useState(placeholder);

  const chevronCls = cn(css.chevron, { [css.active]: isComponentVisible });
  const btnCls = cn(css.dropdown, { [css.disabled]: disabled });

  const optionRefs: MutableRefObject<HTMLDivElement>[] = [];

  const renderItem = (children: React.ReactElement, option: OptionData) => {
    const onSelect = () => {
      if (option.disabled) return;

      if (!('value' in props)) {
        setSelectedValue(option.value);
      }
      if (onChange) {
        onChange(option.value);
      }
      setIsComponentVisible(false);
      buttonRef.current?.focus();
    };

    const onControl = (
      event: React.KeyboardEvent<HTMLDivElement>,
      currentRef: MutableRefObject<HTMLDivElement>
    ) => {
      if (event.key === 'ArrowUp') {
        event.preventDefault();
        focusOption(optionRefs, currentRef, 'upward');
      }
      if (event.key === 'ArrowDown') {
        event.preventDefault();
        focusOption(optionRefs, currentRef, 'downward');
      }
      if (event.key === 'Escape') {
        event.preventDefault();
        setIsComponentVisible(false);
        buttonRef.current?.focus();
      }
      if (event.key === 'Enter') {
        event.preventDefault();
        onSelect();
      }
    };

    const optionRef = useRef() as MutableRefObject<HTMLDivElement>;
    optionRefs.push(optionRef);

    if (option.value === undefined) {
      return (
        <div ref={optionRef} className={css.optionItem} key={option.index}>
          {children}
        </div>
      );
    }

    return (
      <div
        ref={optionRef}
        className={cn(css.optionItem, {
          [css.selected]: option.active,
          [css.disabled]: option.disabled,
        })}
        key={option.index}
        role="option"
        tabIndex={option.disabled ? -1 : 0}
        aria-selected={option.active}
        aria-disabled={option.disabled}
        onClick={onSelect}
        onKeyDown={(event) => onControl(event, optionRef)}
      >
        {children}
      </div>
    );
  };

  const onToggle = () => {
    if (!disabled) {
      setIsComponentVisible((prevState) => !prevState);
    }
  };

  const getNewChild = (child: React.ReactElement<DropdownItemProps>, index: number) => {
    if (!child) return null;
    if (child.type === DropdownItem) {
      return renderItem(child, {
        index,
        value: child.props.value,
        active: selectedValue === child.props.value,
        disabled: child.props.disabled ?? false,
      });
    } else {
      return renderItem(child, {
        index,
        active: false,
        disabled: child.props.disabled ?? false,
      });
    }
  };

  const kids = toArray(children).map(getNewChild);

  useEffect(() => {
    if ('value' in props) {
      setSelectedValue(props.value);
    }
  }, [props.value]);

  useEffect(() => {
    if (selectedValue === null || selectedValue === undefined) {
      setDisplayLabel(placeholder);
    } else {
      const found = kids.find((it) => {
        return (
          it?.props?.children?.type === DropdownItem &&
          it?.props?.children?.props?.value === selectedValue
        );
      });
      setDisplayLabel(found?.props?.children?.props?.children || placeholder);
    }
  }, [selectedValue]);

  return (
    <Popover
      visible={isComponentVisible}
      fullWidth={true}
      style={style}
      className={className}
      content={
        <div ref={ref} className={css.optionList} role="listbox">
          {kids}
        </div>
      }
    >
      <div className={css.wrapper}>
        <button
          ref={buttonRef}
          className={btnCls}
          onClick={onToggle}
          aria-haspopup="listbox"
          aria-expanded={isComponentVisible}
          aria-pressed={isComponentVisible}
          aria-disabled={disabled}
          onKeyDown={(event) => {
            if (event.key === 'Enter') {
              event.preventDefault();
              onToggle();
            }
            if (event.key === 'Escape') {
              event.preventDefault();
              setIsComponentVisible(false);
            }
          }}
        >
          <div className={css.label}>{displayLabel || ''}</div>
          <div className={css.verticalBar} />
          <IconChevronDown className={chevronCls} alt="dropdown" />
        </button>
      </div>
    </Popover>
  );
};
