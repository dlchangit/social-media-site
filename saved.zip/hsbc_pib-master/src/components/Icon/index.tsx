import React from 'react';
import styled from 'styled-components';

import imgRefresh from './assets/icn_refresh_18x18@2x.png';
import imgData from './assets/icn_data_chart_18x18@2x.png';
import imgChevronUp from './assets/icn_chevron_up_18x18@2x.png';
import imgChevronDown from './assets/icn_chevron_down_18x18@2x.png';
import imgChevronLeft from './assets/icn_01_dashboard_chevron_left_18x18@2x.png';
import imgChevronRight from './assets/icn_01_dashboard_chevron_right_18x18@2x.png';
import imgCross from './assets/icn_01_dashboard_close_18x18@2x.png';
import imgMenu from './assets/icn_01_dashboard_menu_more_18x18@2x.png';
import imgBuy from './assets/icn_01_dashboard_shopping_bag_active_18x18@2x.png';
import imgSell from './assets/icn_01_dashboard_quick_sell_18x18@2x.png';
import imgAddWatch from './assets/icn_01_dashboard_add_watchlist_18x18@2x.png';
import imgFilter from './assets/icn_01_dashboard_filter_18x18@2x.png';
import imgSortDescending from './assets/icn_01_dashboard_A_to_Z_18x18@2x.png';
import imgSortAscending from './assets/icn_01_dashboard_Z_to_A_18x18@2x.png';
import imgSort from './assets/icn_01_dashboard_Sort_18x18@2x.png';
import imgAlert from './assets/icn_alert_18x18@2x.png';
import imgModal from './assets/icn_01_dashboard_new_modal_18x18@2x.png';
import imgSuccess from './assets/icn_01_dashboard_success_on_light_18x18@2x.png';
import imgError from './assets/icn_01_dashboard_error_on_light_18x18@2x.png';
import imgTooltip from './assets/icn_tooltip_18x18@2x.png';
import imgTooltipActive from './assets/icn_01_dashboard_tooltip_active_18x18@2x.png';
import imgBar from './assets/icn_01_dashboard_liquidity-management_18x18@2x.png';
import imgAsset from './assets/icn_01_dashboard_asset_management_28x28@2x.png';
import imgInvestment from './assets/icn_01_dashboard_investment_28x28@2x.png';
import imgDirectionUp from './assets/icn_01_dashboard_direction_up_18x18@2x.png';

export interface IconProps {
  className?: string;
  style?: React.CSSProperties;
  alt?: string;
}

const Icon = styled.img`
  width: 18px;
  height: 18px;
  display: block;

  &.small {
    width: 16px;
    height: 16px;
  }

  &.x-small {
    width: 12px;
    height: 12px;
  }
`;

export const IconRefresh: React.VFC<IconProps> = (props) => {
  return <Icon src={imgRefresh} {...props} />;
};

export const IconChart: React.VFC<IconProps> = (props) => {
  return <Icon src={imgData} {...props} />;
};

export const IconBar: React.VFC<IconProps> = (props) => {
  return <Icon src={imgBar} {...props} />;
};

export const IconChevronUp: React.VFC<IconProps> = (props) => {
  return <Icon src={imgChevronUp} {...props} />;
};

export const IconChevronDown: React.VFC<IconProps> = (props) => {
  return <Icon src={imgChevronDown} {...props} />;
};

export const IconChevronLeft: React.VFC<IconProps> = (props) => {
  return <Icon src={imgChevronLeft} {...props} />;
};

export const IconChevronRight: React.VFC<IconProps> = (props) => {
  return <Icon src={imgChevronRight} {...props} />;
};

export const IconCross: React.VFC<IconProps> = (props) => {
  return <Icon src={imgCross} {...props} alt={'close'} className={'small'} />;
};

export const IconMenu: React.VFC<IconProps> = (props) => {
  return <Icon src={imgMenu} {...props} alt={'menu'} />;
};

export const IconBuy: React.VFC<IconProps> = (props) => {
  return <Icon src={imgBuy} {...props} />;
};

export const IconSell: React.VFC<IconProps> = (props) => {
  return <Icon src={imgSell} {...props} />;
};

export const IconAddWatch: React.VFC<IconProps> = (props) => {
  return <Icon src={imgAddWatch} {...props} />;
};

export const IconFilter: React.VFC<IconProps> = (props) => {
  return <Icon src={imgFilter} {...props} />;
};

export const IconSortAscending: React.VFC<IconProps> = (props) => {
  return <Icon src={imgSortAscending} {...props} className={'x-small'} />;
};

export const IconSortDescending: React.VFC<IconProps> = (props) => {
  return <Icon src={imgSortDescending} {...props} className={'x-small'} />;
};

export const IconSort: React.VFC<IconProps> = (props) => {
  return <Icon src={imgSort} {...props} className={'x-small'} />;
};

export const IconAlert: React.VFC<IconProps> = (props) => {
  return <Icon src={imgAlert} {...props} />;
};

export const IconModal: React.VFC<IconProps> = (props) => {
  return <Icon src={imgModal} {...props} />;
};

export const IconSuccess: React.VFC<IconProps> = (props) => {
  return <Icon src={imgSuccess} {...props} />;
};

export const IconError: React.VFC<IconProps> = (props) => {
  return <Icon src={imgError} {...props} />;
};

export const IconTooltip: React.VFC<IconProps> = (props) => {
  return <Icon src={imgTooltip} {...props} />;
};

export const IconTooltipActive: React.VFC<IconProps> = (props) => {
  return <Icon src={imgTooltipActive} {...props} />;
};

export const IconAsset: React.VFC<IconProps> = (props) => {
  return <Icon src={imgAsset} {...props} />;
};

export const IconInvestment: React.VFC<IconProps> = (props) => {
  return <Icon src={imgInvestment} {...props} />;
};

export const IconDirectionUp: React.VFC<IconProps> = (props) => {
  return <Icon src={imgDirectionUp} {...props} />;
};
