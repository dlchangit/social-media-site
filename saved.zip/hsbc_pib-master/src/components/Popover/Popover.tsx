import React, { CSSProperties } from 'react';
import classnames from 'classnames';
import css from './Popover.module.scss';

export interface PopoverProps {
  visible: boolean;
  content: React.ReactElement;
  children: React.ReactChild;
  fullWidth?: boolean;
  className?: string;
  style?: CSSProperties;
}

export interface Position {
  top?: number;
  right?: number;
  bottom?: number;
  left?: number;
  maxHeight?: number;
}

/*
  The transparent boolean flag is lagging the displayNone flag one tick (render cycle)
  This allow to measure the dimension of the content to make the positioning before actually showing it to user in the wrong position.
 */
export const Popover: React.FC<PopoverProps> = (props) => {
  const { visible, content, children, className, fullWidth, style } = props;

  const ref = React.useRef<HTMLDivElement | null>(null);
  const contentRef = React.useRef<HTMLDivElement | null>(null);
  const classes = classnames(css.popover, className);
  const [position, setPosition] = React.useState<Position>({});
  const [displayNone, setDisplayNone] = React.useState(true);
  const [transparent, setTransparent] = React.useState(true);

  const reposition = React.useCallback(() => {
    const domRef: HTMLDivElement | null = ref.current;
    const contentDomRef: HTMLDivElement | null = contentRef.current;
    if (domRef != null && contentDomRef != null) {
      const { left, height } = domRef.getBoundingClientRect();
      const { width: contentWidth } = contentDomRef.getBoundingClientRect();
      const leftRight: { left?: number; right?: number } = {};
      const topBottom: { top?: number; bottom?: number } = {};

      if (left + contentWidth > document.documentElement.clientWidth) {
        leftRight.right = 0;
      } else {
        leftRight.left = 0;
      }

      if (fullWidth) {
        leftRight.left = 0;
        leftRight.right = 0;
      }

      // if (bottom + contentHeight > document.documentElement.clientHeight) {
      //   topBottom.bottom = height + 1;
      // } else {
      topBottom.top = height - 1;
      // }

      setPosition({
        ...topBottom,
        ...leftRight,
        // maxHeight: bottom - 50,
      });
    }
  }, [ref, contentRef]);

  React.useEffect(() => {
    const onScroll = () => visible && reposition();
    window.addEventListener('resize', onScroll);
    return () => {
      window.removeEventListener('resize', onScroll);
    };
  }, [visible]);
  React.useEffect(reposition, [displayNone]);
  React.useEffect(() => {
    setDisplayNone(!visible);
  }, [visible]);
  React.useEffect(() => setTransparent(displayNone), [displayNone]);

  return (
    <div ref={ref} className={classes} style={style}>
      {children}
      <div
        ref={contentRef}
        className={classnames(css.content, {
          [css.displayNone]: displayNone,
          [css.transparent]: transparent,
        })}
        style={{ ...position }}
      >
        {content}
      </div>
    </div>
  );
};
