import React, { useEffect, useState } from 'react';
import { toArray } from '../../utils/dom';
import { AccordionPanelProps } from './Panel';

export interface AccordionProps {
  className?: string;
  style?: React.CSSProperties;

  activeKey?: React.Key;
  defaultActiveKey?: React.Key;
  onChange?: (key?: React.Key) => void;

  children: React.ReactElement | React.ReactElement[];
}

export const Accordion: React.FC<AccordionProps> = (props) => {
  const { className, defaultActiveKey, style, onChange, children } = props;
  const [currentKey, setCurrentKey] = useState(
    'activeKey' in props ? props.activeKey : defaultActiveKey ?? undefined
  );
  useEffect(() => {
    if ('activeKey' in props) {
      setCurrentKey(props.activeKey);
    }
  }, [props.activeKey]);

  const onClickItem = (key?: React.Key) => {
    const newKey = currentKey !== key ? key : undefined;
    if ('activeKey' in props) {
      if (typeof onChange === 'function') {
        onChange(newKey);
      }
      return;
    }
    setCurrentKey(newKey);
    if (typeof onChange === 'function') {
      onChange(newKey);
    }
  };

  const getNewChild = (child: React.ReactElement<AccordionPanelProps>, index: number) => {
    if (!child) return null;
    if (typeof child.type === 'string') {
      return child;
    }

    const { panelKey, header, headerClass, disabled } = child.props;
    const keyValue = panelKey === undefined ? index : panelKey;
    const isActive = currentKey === keyValue;
    const childProps = {
      key: index,
      panelKey: keyValue,
      header,
      headerClass,
      isActive,
      onItemClick: disabled ? undefined : onClickItem,
      children: child.props.children,
    };
    return React.cloneElement(child, childProps);
  };

  const kids = toArray(children).map(getNewChild);

  return (
    <div className={className} style={style} role="tablist">
      {kids}
    </div>
  );
};
