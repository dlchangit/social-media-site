import React from 'react';
import cn from 'classnames';
import { PanelContent } from './PanelContent';
import { Divider } from '../Divider';
import css from './Accordion.module.scss';
import { ExpansionIcon } from '../ExpansionIcon';

export interface AccordionPanelProps {
  className?: string;
  style?: React.CSSProperties;
  disabled?: boolean;

  header?: string | React.ReactNode;
  headerClass?: string;

  panelKey?: React.Key;
  isActive?: boolean;
  onItemClick?: (panelKey?: React.Key) => void;

  children?: React.ReactElement;
}

export const Panel: React.FC<AccordionPanelProps> = (props) => {
  const {
    className,
    style,
    disabled,

    header,
    headerClass,

    panelKey,
    isActive,
    onItemClick,

    children,
  } = props;

  const itemCls = cn(
    {
      [css.collapseItemDisabled]: disabled,
    },
    className
  );

  const headerCls = cn(css.collapseHeader, headerClass);

  const handleItemClick = () => {
    if (typeof onItemClick === 'function') {
      onItemClick(panelKey);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleItemClick();
    }
  };

  return (
    <div className={itemCls} style={style}>
      <Divider />
      <div
        className={headerCls}
        role="tab"
        tabIndex={disabled ? -1 : 0}
        aria-expanded={isActive}
        onClick={handleItemClick}
        onKeyPress={handleKeyPress}
      >
        <div className={css.collapseHeaderText}>{header}</div>
        <ExpansionIcon active={isActive} />
      </div>
      <PanelContent isActive={isActive}>{children}</PanelContent>
    </div>
  );
};
