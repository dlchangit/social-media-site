import React, { MutableRefObject } from 'react';
import cn from 'classnames';
import { AccordionPanelProps } from './Panel';
import css from './Accordion.module.scss';

type PanelContentProps = Pick<AccordionPanelProps, 'isActive'>;

export const PanelContent: React.FC<PanelContentProps> = (props) => {
  const { isActive, children } = props;

  // const [rendered, setRendered] = React.useState(isActive);
  const [style, setStyle] = React.useState<{ height: number; visibility?: 'hidden' } | undefined>(
    undefined
  );
  const ref = React.createRef() as MutableRefObject<HTMLDivElement>;

  React.useEffect(() => {
    // if (isActive) {
    //   setRendered(true);
    // }

    if (isActive) {
      setExpanding();
    } else {
      setCollapsing();
    }
  }, [isActive]);

  // if (!rendered) {
  //   return null;
  // }

  const setExpanding = () => {
    if (!ref.current) return;
    setStyle({
      height: ref.current.scrollHeight,
    });
  };

  const setCollapsing = () => {
    if (!ref.current) return;
    setStyle({
      height: 0,
    });
  };

  const cls = cn({
    [css.collapseContent]: true,
    // [css.collapseContentActive]: isActive,
    // [css.collapseContentInactive]: !isActive,
    // 'collapse-content-hidden': hidden,
  });

  const onTransitionEnd = () => {
    // setStyle(undefined);
    // setHidden(!isActive);
    if (ref.current && !isActive) {
      setStyle({
        height: 0,
        visibility: isActive ? undefined : 'hidden',
      });
    }
  };

  return (
    <div className={cls} ref={ref} role="tabpanel" style={style} onTransitionEnd={onTransitionEnd}>
      <div className="collapse-content-box">{children}</div>
    </div>
  );
};
