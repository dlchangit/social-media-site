import React, { CSSProperties } from 'react';
import cn from 'classnames';
import css from './Typegraphy.module.scss';
import { isFragment } from 'react-is';

export interface TypographyProps {
  size: 1 | 2 | 3 | 4 | 5 | 6 | 7;
  weight?: 'light' | 'regular' | 'medium';
  children?: React.ReactNode | React.ReactNodeArray;
  className?: string;
  style?: CSSProperties;
}

export const Typography: React.FC<TypographyProps> = (props) => {
  const { size, weight, children, className, style } = props;

  if (children === null || children === undefined) {
    return null;
  }

  const cls = cn(size && css[`ts-${size}`], weight && css[`font-${weight}`], className);

  if (!React.isValidElement(children)) {
    return (
      <span className={cls} style={style}>
        {children}
      </span>
    );
  }

  let kids = children;
  if (isFragment(children)) {
    kids = children.props.children;
  }

  return (
    <>
      {React.Children.map(kids as React.ReactChild | React.ReactChild[], (child) => {
        if (typeof child === 'string') {
          return (
            <span className={cls} style={style}>
              {child}
            </span>
          );
        }
        const kid = child as React.ReactElement;
        return React.cloneElement(kid, {
          ...kid.props,
          className: cn(kid.props && kid.props.className, cls),
          style,
        });
      })}
    </>
  );
};
