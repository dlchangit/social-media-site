import React from 'react';
import { Button } from '../Button';
import { IconMenu } from '../Icon';
import { Popover } from '../Popover';
import css from './ContextMenu.module.scss';
import classnames from 'classnames';

export interface ContextMenuProp {
  items: { label: string; icon?: React.ReactElement<HTMLImageElement> }[];
  onMenuItemClick?: (idx: number) => void;
}

export const ContextMenu: React.FC<ContextMenuProp> = (props) => {
  const { items, onMenuItemClick } = props;
  const [visible, setVisible] = React.useState(false);

  const content = (
    <div className={css.contextmenu}>
      {items.map((item, idx) => {
        return (
          <Button
            className={classnames(css.menuItem)}
            key={item.label}
            type="text"
            icon={item.icon}
            onClick={() => onMenuItemClick && onMenuItemClick(idx)}
          >
            {item.label}
          </Button>
        );
      })}
    </div>
  );
  return (
    <Popover visible={visible} content={content}>
      <Button
        className={classnames(css.menuBtn)}
        type={'text'}
        icon={<IconMenu />}
        onClick={() => setVisible(!visible)}
        onBlur={() => setVisible(false)}
      />
    </Popover>
  );
};
