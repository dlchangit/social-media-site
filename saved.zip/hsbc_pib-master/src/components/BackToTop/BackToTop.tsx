import React from 'react';
import cn from 'classnames';
import css from './BackToTop.module.scss';
import { Typography } from '../Typography';
import { IconDirectionUp } from '../Icon';
import { Space } from '../Space';

export interface BackToTopProps {
  className?: string;
  style?: React.CSSProperties;
  label: string;
}

export const BackToTop: React.VFC<BackToTopProps> = (props) => {
  const { className, style, label } = props;
  const cls = cn(css.back, className);

  const scrollTop = () => {
    window.scrollTo({ top: 0, behavior: 'auto' });
  };

  return (
    <button className={cls} style={style} onClick={scrollTop}>
      <Space align={'center'}>
        <IconDirectionUp />
        <Typography size={7} className={css.label}>
          {label}
        </Typography>
      </Space>
    </button>
  );
};
