import React from 'react';
import cn from 'classnames';
import css from './PrimaryTitle.module.scss';
import { Typography, TypographyProps } from '../Typography';

export interface PrimaryTitleProps {
  className?: string;
  style?: React.CSSProperties;
  size?: TypographyProps['size'];
  weight?: TypographyProps['weight'];
}

export const PrimaryTitle: React.FC<PrimaryTitleProps> = (props) => {
  const { className, style, children, size = 4, weight = 'light' } = props;
  const cls = cn(css.redLine, className);
  return (
    <Typography className={cls} style={style} size={size} weight={weight}>
      {children}
    </Typography>
  );
};
