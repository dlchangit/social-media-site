import React, { MutableRefObject, useEffect, useRef, useState } from 'react';
import cn from 'classnames';
import css from './Tooltip.module.scss';
import { Typography } from '../Typography';
import { ResizeObserver } from '@juggle/resize-observer';

export type Direction =
  | 'top-left'
  | 'top-center'
  | 'top-right'
  | 'bottom-left'
  | 'bottom-center'
  | 'bottom-right';

export interface TooltipProp {
  direction: Direction;
  message: string;
  className?: string;
  activeChildren?: React.ReactNode;
}

export const Tooltip: React.FC<TooltipProp> = (props) => {
  const { direction, message, className, children, activeChildren } = props;

  const [internalDirection, setInternalDirection] = useState(direction);

  const classname = cn(css.tooltip, className, css[internalDirection]);
  const msgClassname = cn(css.tooltipMsg, css[internalDirection]);
  const [active, setActive] = useState(false);

  const ref = useRef() as MutableRefObject<HTMLDivElement>;

  const onAlign = () => {
    if (!ref.current) return;
    setInternalDirection(direction);
    let bounding = ref.current.getBoundingClientRect();
    if (bounding.left < 0) {
      if (direction.indexOf('top') !== -1) {
        setInternalDirection('top-right');
      } else {
        setInternalDirection('bottom-right');
      }
    }
    bounding = ref.current.getBoundingClientRect();
    if (bounding.top < 0) {
      if (direction.indexOf('top') !== -1) {
        setInternalDirection((prevState) => {
          return prevState.replace('top', 'bottom') as Direction;
        });
      }
    }

    if (bounding.right > window.innerWidth) {
      if (direction.indexOf('top') !== -1) {
        setInternalDirection('top-left');
      } else {
        setInternalDirection('bottom-left');
      }
    }
  };

  useEffect(() => {
    onAlign();
    let resizeObserver: ResizeObserver;
    const ro = new ResizeObserver((_, observer) => {
      if (!ref.current) return;
      resizeObserver = observer;
      onAlign();
    });
    ro.observe(window.document.body);
    return () => {
      resizeObserver && resizeObserver.disconnect();
    };
  }, [direction]);

  return (
    <div
      className={classname}
      onFocus={() => setActive(true)}
      onMouseOver={() => setActive(true)}
      onBlur={() => setActive(false)}
      onMouseOut={() => setActive(false)}
    >
      {active && (activeChildren || children)}
      {!active && children}
      <Typography size={6} className={msgClassname}>
        <div ref={ref}>{message}</div>
      </Typography>
    </div>
  );
};
