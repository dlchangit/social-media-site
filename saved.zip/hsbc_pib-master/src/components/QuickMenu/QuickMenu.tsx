import React, { MutableRefObject } from 'react';
import cn from 'classnames';
import css from './QuickMenu.module.scss';
import { useComponentVisible } from '../../hook/useComponentVisible';
import { Button } from '../Button';
import { IconMenu } from '../Icon';
import { Space } from '../Space';
import { Divider } from '../Divider';
import { toArray } from '../../utils/dom';

export interface QuickMenuProps {
  defaultVisible?: boolean;
  children: (
    isVisible: boolean,
    setVisible: (isVisible: boolean) => void
  ) => React.ReactElement | React.ReactElement[];
  buttonClass?: string;
}

export const QuickMenu: React.FC<QuickMenuProps> = (props) => {
  const { defaultVisible = false, children, buttonClass } = props;

  const buttonRef = React.useRef() as MutableRefObject<HTMLButtonElement>;

  const { ref, isComponentVisible, setIsComponentVisible } = useComponentVisible(defaultVisible, [
    buttonRef,
  ]);
  const cls = cn(css.popover, { [css.hidden]: !isComponentVisible });

  const kids = toArray(children(isComponentVisible, setIsComponentVisible)).filter(
    (kid) => kid !== null
  );

  return (
    <div className={cls}>
      <Space ref={ref} className={css.contextmenu} split={<Divider />} direction={'vertical'}>
        {kids}
      </Space>
      <Button
        className={buttonClass}
        type={'raw'}
        icon={<IconMenu />}
        onClick={() => setIsComponentVisible(!isComponentVisible)}
        ref={buttonRef}
      />
    </div>
  );
};
