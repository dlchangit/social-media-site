import React, { forwardRef, isValidElement, useEffect, useState } from 'react';
import cn from 'classnames';
import css from './Checkbox.module.scss';
import { Typography } from '../Typography';

export interface CheckboxV3Props extends React.HTMLAttributes<HTMLInputElement> {
  checked?: boolean;
  defaultChecked?: boolean;
  disabled?: boolean;
  intermediate?: boolean;
  size?: 'large';
  children?: string | React.ReactElement;
}

export const Checkbox = forwardRef<HTMLInputElement, CheckboxV3Props>((props, ref) => {
  const {
    className,
    style,
    children,
    defaultChecked = false,
    disabled = false,
    intermediate = false,
    onChange,
    size,
    ...rest
  } = props;

  const [internalState, setInternalState] = useState(props.checked ?? defaultChecked ?? false);

  const cls = cn(className, css.checkbox, 'focus-visible', {
    [css.disabled]: disabled,
  });
  const boxCls = cn(css.box, {
    [css.checked]: internalState,
    [css.intermediate]: intermediate && !internalState,
    [css.large]: size,
  });

  useEffect(() => {
    if ('checked' in props) {
      setInternalState(props.checked ?? false);
    }
  }, [props.checked]);

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (!('checked' in props)) {
      setInternalState(event.target.checked);
    }
    if (typeof onChange === 'function') {
      onChange(event);
    }
  };

  const renderLabel = () => {
    if (isValidElement(children)) {
      return children;
    }
    return (
      <Typography size={5} className={css.label}>
        {children}
      </Typography>
    );
  };

  return (
    <label className={cls} style={style}>
      <input
        {...rest}
        ref={ref}
        type={'checkbox'}
        className={css.input}
        checked={internalState}
        aria-checked={internalState}
        disabled={disabled}
        aria-disabled={disabled}
        onChange={handleChange}
      />
      <div className={boxCls} />
      {renderLabel()}
    </label>
  );
});
