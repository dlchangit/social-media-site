import React from 'react';

import css from './Tag.module.scss';
import cn from 'classnames';
import { Typography, TypographyProps } from '../Typography';

interface TagProps {
  className?: string;
  style?: React.CSSProperties;
  theme?: 'dark' | 'light';
  size?: TypographyProps['size'];
}

export const Tag: React.FC<TagProps> = (props) => {
  const { children, className, style, theme = 'dark', size = 5 } = props;
  return (
    <Typography className={cn(css.tag, [css[`tag-${theme}`]], className)} style={style} size={size}>
      {children}
    </Typography>
  );
};
