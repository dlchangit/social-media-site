import React, { useEffect } from 'react';

import css from './StickyHeader.module.scss';
import { Typography } from '../Typography';
import { Button } from '../Button';
import { IconAlert, IconFilter, IconRefresh } from '../Icon';
import { Grid, Item, Row } from '../Grid';
import { DropdownItem, MultipleDropdown, SingleDropdown } from '../Dropdown';
import { format } from 'date-fns';
import cn from 'classnames';
import { GlobalHeader } from '../GlobalHeader';

export interface StickyHeaderProp {
  onAccountChange?: () => void;
}

const accountList = [
  {
    value: '001-000000',
    label: '001-000000 HSBC Wealth Connect Investment Services',
  },
  {
    value: '002-000000',
    label: '002-000000 HSBC HK Jade Investment Services',
  },
  {
    value: '003-000000-000',
    label: '003-000000-000 HSBC UK Jade Investment Services',
  },
];

const currency = [
  { value: 'usd', label: 'USD' },
  { value: 'hkd', label: 'HKD' },
  { value: 'gbp', label: 'GBP' },
  { value: 'JPY', label: 'JPY' },
  { value: 'eur', label: 'EUR' },
  { value: 'aud', label: 'AUD' },
  { value: 'twd', label: 'TWD' },
];

export const StickyHeader: React.FC<StickyHeaderProp> = () => {
  const [scrolled, setScrolled] = React.useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  const trigger = React.useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const onScroll = () => {
      const triggerRef = trigger.current;
      if (triggerRef != null) {
        const { top } = triggerRef.getBoundingClientRect();
        setScrolled(top <= 50);
      }
    };
    window.addEventListener('scroll', onScroll);
    return () => {
      window.removeEventListener('scroll', onScroll);
    };
  }, []);

  const renderAccountDropdown = () => {
    const def = accountList.filter((_, index) => index !== 1).map((it) => it.value);
    return (
      <MultipleDropdown
        className={css.dropdown}
        placeholder={'SELECT'}
        allOption={'All'}
        defaultValues={def}
      >
        {accountList.map((it, index) => (
          <DropdownItem key={it.value} value={it.value} disabled={index == 1}>
            {it.label}
          </DropdownItem>
        ))}
        <a
          href={'https://www.google.com'}
          target="_blank"
          rel="noreferrer"
          style={{ width: '100%' }}
        >
          Link international accounts
        </a>
      </MultipleDropdown>
    );
  };

  const renderCurrencyDropdown = () => {
    return (
      <SingleDropdown className={css.dropdown} placeholder={''} defaultValue={currency[0].value}>
        {currency.map((it) => (
          <DropdownItem key={it.value} value={it.value}>
            {it.label}
          </DropdownItem>
        ))}
      </SingleDropdown>
    );
  };

  return (
    <div className={css.container}>
      <GlobalHeader />
      <Grid className={cn(css.subHeader, css.tabletPadding, css.mobilePadding)}>
        <Row
          justifyContent={'space-between'}
          alignItems={'center'}
          className={css.bigHeader}
          flush={true}
        >
          <Item>
            <Typography size={2}>My Wealth Dashboard</Typography>
          </Item>
          <Item>
            <Button icon={<IconAlert />} />
          </Item>
        </Row>
      </Grid>
      <div ref={trigger} />
      <div className={cn(css.desktopTablet, css.tabletPadding, { [css.sticky]: scrolled })}>
        <Grid className={cn(css.menu)}>
          <Row alignItems={'flex-end'} justifyContent={'flex-start'} flush={true}>
            <div className={cn(css.account)}>
              <Typography size={6}>Account(s):</Typography>
              {renderAccountDropdown()}
            </div>
            <div className={cn(css.currency)}>
              <Typography size={6}>
                View <br className={css.viewHoldingsBreak} /> holding in:
              </Typography>
              {renderCurrencyDropdown()}
            </div>
            <Button secondary={true}>Apply</Button>
            <div className={css.tabletBreak} />
            <div className={css.lastUpdate}>
              <Typography size={6}>
                Last updated: <br className={css.lastUpdateBreak} />
                {format(Date.now(), 'HH:mm d LLL y')} (HKT)
              </Typography>
              <Button icon={<IconRefresh />} style={{ marginLeft: 8 }} />
            </div>
            {scrolled && <Button icon={<IconAlert />} style={{ marginLeft: 12 }} />}
          </Row>
        </Grid>
      </div>

      <div className={cn(css.mobile, { [css.mobileSticky]: scrolled })}>
        {scrolled && (
          <Grid className={cn(css.mobileHeader, css.mobilePadding)}>
            <Row justifyContent={'space-between'} alignItems={'center'} flush={true}>
              <Button icon={<IconFilter />} onClick={() => setMobileMenuOpen(!mobileMenuOpen)} />
              <Typography size={6}>
                Last updated: {scrolled && <br />}
                {format(Date.now(), 'HH:mm d LLL y')} (HKT)
              </Typography>
              <div style={{ display: 'flex' }}>
                <Button icon={<IconRefresh />} />
                {scrolled && <Button icon={<IconAlert />} style={{ marginLeft: 12 }} />}
              </div>
            </Row>
          </Grid>
        )}
        {(mobileMenuOpen || !scrolled) && (
          <>
            <div className={cn(css.mobileExpandBox, css.mobilePadding)}>
              <Grid>
                <Row flush={true}>
                  <Item lgSize={12}>
                    <Typography size={6}>Account(s):</Typography>
                    {renderAccountDropdown()}
                  </Item>
                </Row>
                <Row alignItems={'flex-end'} style={{ marginTop: 12 }} flush={true}>
                  <div className={css.mobileCurrency}>
                    <Typography size={6}>View holdings in:</Typography>
                    {renderCurrencyDropdown()}
                  </div>
                  <Button secondary={true} style={{ marginLeft: 12 }}>
                    Apply
                  </Button>
                </Row>
              </Grid>
            </div>
          </>
        )}
        {!scrolled && (
          <Grid className={css.mobilePadding}>
            <Row justifyContent={'flex-start'} alignItems={'center'} flush={true}>
              <Typography size={6}>
                Last updated: {scrolled && <br />}
                {format(Date.now(), 'HH:mm d LLL y')} (HKT)
              </Typography>
              <Button icon={<IconRefresh />} style={{ marginLeft: 8 }} />
            </Row>
          </Grid>
        )}
      </div>
    </div>
  );
};
