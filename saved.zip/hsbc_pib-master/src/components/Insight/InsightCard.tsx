import React from 'react';
import css from './InsightCard.module.scss';

export interface CardProps {
  top: React.ReactElement;
  divider: React.ReactElement;
  bottom: React.ReactElement;
  // like: React.ReactNode;
  // share: React.ReactNode;
}

export const InsightCard: React.FC<CardProps> = (props) => {
  const { top, divider, bottom } = props;
  return (
    <div className={css.card}>
      <div className={css.top}>{top}</div>
      {divider}
      <div className={css.bottom}>{bottom}</div>
      {/*<div className="extra">*/}
      {/*  {like}*/}
      {/*  {share}*/}
      {/*</div>*/}
    </div>
  );
};
