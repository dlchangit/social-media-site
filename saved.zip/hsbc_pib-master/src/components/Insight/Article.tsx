import React from 'react';
import cn from 'classnames';
import { Ellipsis } from '../Ellipsis/Ellipsis';
import { Typography } from '../Typography/Typography';

import css from './Article.module.scss';

export interface ArticleProps extends React.HTMLAttributes<HTMLDivElement> {
  title: string;
  content: string;
  anchor: React.ReactElement;
}

export const Article: React.VFC<ArticleProps> = (props) => {
  const { title, content, anchor, className, ...rest } = props;
  const cls = cn(css.article, className);

  return (
    <div className={cls} {...rest}>
      <a href={anchor.props.href}>
        <Typography size={4} weight="light">
          <Ellipsis text={title} lines={2} />
        </Typography>
      </a>
      <Ellipsis className={css.content} text={content} lines={3} />
      <div className={css.anchor}>{anchor}</div>
    </div>
  );
};
