import React, { CSSProperties } from 'react';
import css from './Grid.module.scss';
import cn from 'classnames';

export interface RowProps {
  flush?: boolean;
  flexDirection?: 'row' | 'row-reverse' | 'column' | 'column-reverse' | 'initial' | 'inherit';
  justifyContent?:
    | 'flex-start'
    | 'flex-end'
    | 'center'
    | 'space-between'
    | 'space-around'
    | 'space-evenly'
    | 'initial'
    | 'inherit';
  alignItems?:
    | 'stretch'
    | 'center'
    | 'flex-start'
    | 'flex-end'
    | 'baseline'
    | 'initial'
    | 'inherit';
  className?: string;
  style?: CSSProperties;
  ref?: React.RefObject<HTMLDivElement | null>;
}

export interface ItemProps {
  smSize?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;
  mdSize?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;
  lgSize?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;
  smOffset?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;
  mdOffset?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;
  lgOffset?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;
  className?: string;
  style?: CSSProperties;
  ref?: React.RefObject<HTMLDivElement | null>;
  justifySelf?: 'to-left' | 'to-right';
  last?: ('sm' | 'md' | 'lg')[];
}

export interface GridProps {
  className?: string;
  style?: CSSProperties;
  ref?: React.RefObject<HTMLDivElement> | null;
}

export const Grid: React.FC<GridProps> = (props) => {
  const { children, className, ref } = props;
  return (
    <div ref={ref} className={cn(css.grid, className)}>
      {children}
    </div>
  );
};

export const Row: React.FC<RowProps> = (props) => {
  const { children, flexDirection, justifyContent, alignItems, flush, className, style } = props;

  return (
    <div
      className={cn(css.row, { [css.flush]: flush }, className)}
      style={{ flexDirection, justifyContent, alignItems, ...style }}
    >
      {children}
    </div>
  );
};

export const Item: React.FC<ItemProps> = (props) => {
  const {
    children,
    smSize,
    mdSize,
    lgSize,
    smOffset,
    mdOffset,
    lgOffset,
    className,
    style,
    justifySelf,
    last,
  } = props;
  const lastClasses = last ? last.map((it) => css[`${it}-last`]) : [];
  const classes = cn(
    css.item,
    css[`lg-${lgSize}`],
    css[`md-${mdSize}`],
    css[`sm-${smSize}`],
    css[`lg-offset-${lgOffset}`],
    css[`md-offset-${mdOffset}`],
    css[`sm-offset-${smOffset}`],
    css[`${justifySelf}`],
    ...lastClasses,
    className
  );
  return (
    <div className={classes} style={style}>
      {children}
    </div>
  );
};
