import React from 'react';
import css from './HealthScoreCard.module.scss';
import { Typography } from '../Typography';
import cn from 'classnames';

export interface HealthScoreCardProps {
  className?: string;
  title: string;
  percent?: string;
  description: string;
  img: React.ReactElement;
}

export const HealthScoreCard: React.FC<HealthScoreCardProps> = (props) => {
  const { title, percent, description, img, className } = props;

  return (
    <div className={cn(css.container, className)}>
      <Typography size={5} weight={'light'}>
        {title}
      </Typography>
      <div className={css.content}>
        <div className={css.img}>{img}</div>
        <div className={css.percent}>
          {percent != undefined && <Typography size={2}>{percent}%</Typography>}
        </div>
        <Typography size={5} weight={'light'}>
          {description}
        </Typography>
      </div>
    </div>
  );
};
