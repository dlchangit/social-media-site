import React from 'react';
import { Typography } from '../Typography';
import { Button } from '../Button';
import { IconChevronLeft, IconChevronRight } from '../Icon';
import { DropdownItem, SingleDropdown } from '../Dropdown';

import css from './Pagination.module.scss';
import { useTranslation } from 'react-i18next';
import { Space } from '../Space';
import cn from 'classnames';

export interface PaginationProps {
  className?: string;
  totalPages: number;
  currentPage: number;
  recordsPerPage: number[];
  onPageChange: (page: number) => void;
  onRecordsPerPageChange: (count: number) => void;
}

export const Pagination: React.FC<PaginationProps> = (props) => {
  const {
    className,
    totalPages,
    currentPage,
    recordsPerPage,
    onPageChange,
    onRecordsPerPageChange,
  } = props;

  const [recordsPerPageValue, setRecordsPerPageValue] = React.useState(recordsPerPage[0]);
  const { t } = useTranslation();

  const recordsPerPageOption = recordsPerPage.map((it) => ({
    label: it.toString(),
    value: it.toString(),
  }));

  return (
    <Space className={cn(css.pagination, className)} wrap={true}>
      <Space className={css.controlGroup} align={'center'}>
        <Typography className={css.mr8} size={5}>
          {`${currentPage} ${t('pagination.of')} ${totalPages}`}
        </Typography>
        <Button
          className={css.ml8}
          icon={<IconChevronLeft />}
          onClick={() => onPageChange(currentPage - 1)}
          disabled={currentPage === 1}
        />
        <Button
          className={css.ml8}
          icon={<IconChevronRight />}
          onClick={() => onPageChange(currentPage + 1)}
          disabled={currentPage === totalPages}
        />
      </Space>

      <Space className={cn(css.controlGroup, css.showRecord)} align={'center'}>
        <Typography size={5}>{t('pagination.showRecords')}</Typography>
        <SingleDropdown
          className={css.showRecordDropdown}
          value={recordsPerPageValue.toString()}
          onChange={(value) => setRecordsPerPageValue(parseInt(value as string))}
          placeholder={''}
        >
          {recordsPerPageOption.map((it, index) => {
            return (
              <DropdownItem value={it.value} key={index}>
                {it.label}
              </DropdownItem>
            );
          })}
        </SingleDropdown>
        <Button className={css.ml8} onClick={() => onRecordsPerPageChange(recordsPerPageValue)}>
          {t('pagination.go')}
        </Button>
      </Space>
    </Space>
  );
};
