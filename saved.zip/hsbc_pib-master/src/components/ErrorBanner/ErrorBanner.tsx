import React from 'react';
import classnames from 'classnames';
import css from './ErrorBanner.tsx.module.scss';
import { Space } from '../Space';
import { Typography } from '../Typography';
import { IconError } from '../Icon';

export interface ErrorBannerProps {
  className?: string;
  style?: React.CSSProperties;
  children: string;
}

export const ErrorBanner: React.VFC<ErrorBannerProps> = (props) => {
  const { className, style, children } = props;
  const cls = classnames(css.error, className);

  return (
    <Space align={'center'} className={cls} style={style}>
      <IconError className={css.icon} />
      <Typography size={5} weight={'medium'}>
        System error.&nbsp;
      </Typography>
      <span>{children}</span>
    </Space>
  );
};
