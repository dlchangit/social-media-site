import React, { CSSProperties, MutableRefObject, useEffect, useRef } from 'react';
import cn from 'classnames';
import css from './Modal.module.scss';

import { Button } from '../Button';
import { IconCross } from '../Icon';
import { Typography } from '../Typography';
import { Space } from '../Space';
import { useGlobalKeyboardEvent } from '../../hook/useGlobalKeyboardEvent';

export interface ModalProps {
  visible: boolean;
  onClose: () => void;
  zIndex?: number;
  closable?: boolean;
  header?: string | React.ReactElement;
  closeButtonHeader?: React.ReactElement;
  children: React.ReactNode | React.ReactNodeArray;
  style?: CSSProperties;
  wrapperClass?: string;
  gutterClass?: string;
}

export const Modal: React.FC<ModalProps> = (props) => {
  const {
    visible,
    onClose,
    zIndex = 1000,
    closable = true,
    header,
    closeButtonHeader,
    children,
    style,
    gutterClass,
    wrapperClass,
  } = props;

  const wrapperRef = useRef() as MutableRefObject<HTMLDivElement>;
  const contentRef = useRef() as MutableRefObject<HTMLDivElement>;

  useGlobalKeyboardEvent('Escape', () => {
    closable && onClose();
  });

  useEffect(() => {
    if (visible) {
      window.document.body.classList.add(css.overflowHidden);
    } else {
      window.document.body.classList.remove(css.overflowHidden);
    }
  }, [visible]);

  useEffect(() => {
    if (!wrapperRef.current || !contentRef.current) {
      return;
    }

    wrapperRef.current.style.maxHeight = window.innerHeight - 44 * 2 + 'px';
    let wrapperHeight = wrapperRef.current?.offsetHeight ?? 0;
    wrapperRef.current?.childNodes.forEach((it) => {
      if (it != contentRef.current) {
        wrapperHeight -= (it as HTMLElement).offsetHeight;
      }
    });
    contentRef.current.style.height = wrapperHeight + 'px';
  }, [visible]);

  if (!visible) {
    return null;
  }

  const renderHeader = () => {
    if (typeof header === 'string') {
      return (
        <Typography size={2} weight={'light'}>
          <div className={cn(css.gutter, gutterClass)}>{header}</div>
        </Typography>
      );
    } else {
      return <div className={cn(css.gutter, gutterClass)}>{header}</div>;
    }
  };

  return (
    <div className={css.modal} style={{ ...style, zIndex }}>
      <div className={cn(css.wrapper, wrapperClass)} ref={wrapperRef}>
        <Space justify={'between'} align={'center'}>
          {closeButtonHeader ? closeButtonHeader : <div />}
          {closable && <Button type={'text'} icon={<IconCross />} onClick={onClose} />}
        </Space>
        {renderHeader()}
        <div className={cn(css.gutter, gutterClass)} ref={contentRef}>
          <div className={css.content}>{children}</div>
        </div>
      </div>
    </div>
  );
};
