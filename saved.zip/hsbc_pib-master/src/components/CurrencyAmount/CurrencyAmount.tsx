import React, { CSSProperties, isValidElement } from 'react';

import cn from 'classnames';
import css from './CurrencyAmount.module.scss';

import arrowUp from './icn_position_up_16x8@2x.png';
import arrowDown from './icn_position_down_18x9@2x.png';
import { formatDigits } from '../../utils/math';
import { Typography } from '../Typography';

export interface CurrencyAmountProps {
  label?: React.ReactChild;
  currency: string;
  amount: number | '-';
  percent?: number | '-';
  showSign?: boolean;
  style?: CSSProperties;
  className?: string;
  size?: 'small' | 'large';
  light?: boolean;
}

export const CurrencyAmount: React.FC<CurrencyAmountProps> = (props) => {
  const {
    label,
    currency,
    amount,
    percent,
    style,
    className,
    showSign = false,
    size = 'large',
    light,
  } = props;

  let internalColor: typeof css.green | typeof css.green | null = null;
  if (showSign && amount > 0) {
    internalColor = css.green;
  }
  if (showSign && amount < 0) {
    internalColor = css.red;
  }

  const renderLabel = () => {
    if (!isValidElement(label)) {
      return (
        <Typography size={size === 'large' ? 5 : 6} weight={light ? 'light' : 'regular'}>
          {label}
        </Typography>
      );
    } else {
      return label;
    }
  };

  const prefix = (show: boolean) => {
    if (!show) return;

    if (size === 'small') {
      switch (internalColor) {
        case css.green:
          return '+';
        case css.red:
          return '-';
        default:
          return null;
      }
    }
    switch (internalColor) {
      case css.green:
        return (
          <span className={css.prefix}>
            <img src={arrowUp} alt="" />+
          </span>
        );
      case css.red:
        return (
          <span className={css.prefix}>
            <img src={arrowDown} alt="" />-
          </span>
        );
      default:
        return null;
    }
  };

  const cls = cn(css.currency, className);

  const format = (value: number | '-', prefix = '', suffix = '') => {
    if (typeof value === 'string') {
      return value;
    }
    return prefix + formatDigits(Math.abs(value)) + suffix;
  };

  return (
    <div className={cls} style={style}>
      {renderLabel()}
      <Typography
        className={cn(internalColor, { [css[`spacing-${size}`]]: label })}
        size={size == 'large' ? 4 : 6}
        weight={light ? 'light' : 'medium'}
      >
        <div>
          {prefix(typeof amount !== 'string')}
          {format(amount, currency + ' ')}
        </div>
        {percent !== undefined && (
          <div>
            {size === 'small' && '('}
            {prefix(typeof percent !== 'string')}
            {format(percent, '', '%')}
            {size === 'small' && ')'}
          </div>
        )}
      </Typography>
    </div>
  );
};
