import React, { CSSProperties, ReactElement, useEffect, useReducer, useRef, useState } from 'react';
import { Popover } from '../Popover';
import { InputDate } from '../InputDate';

import css from './InputDateRange.module.scss';
import { useComponentVisible } from '../../hook/useComponentVisible';
import { Space } from '../Space';
import { Typography } from '../Typography';
import { IconChevronDown, IconError } from '../Icon';
import { addDays, addYears, isAfter, isBefore, setDate, setMonth } from 'date-fns';
import cn from 'classnames';
import { setTime } from '../../utils/date';
import { Modal } from '../Modal';
import { ResizeObserver } from '@juggle/resize-observer';
import { breakpoint, VIEW_PORT } from '../../utils/dom';

type SelectedRange = '30d' | '60d' | '90d' | '1y' | '3y' | 'ytd' | 'custom';

interface InputDateRangeError {
  fromError: boolean;
  toError: boolean;
  rangeError: boolean;
}

export interface DateRange {
  from: Date;
  to: Date;
}

export interface InputDateRangeProps {
  value?: DateRange;
  onChange: (range: DateRange) => void;
  formatter?: (range: DateRange) => string | ReactElement;
  className?: string;
  style?: CSSProperties;
  min?: Date;
  max?: Date;
  zIndex?: number;
}

export const InputDateRange: React.FC<InputDateRangeProps> = (props) => {
  const { value, onChange, formatter, className, style, min, max, zIndex = 999 } = props;

  const [selectedRange, setSelectedRange] = useState<SelectedRange>('custom');
  const [state, setState] = useState<Partial<DateRange>>({ ...value });
  const [verifiedState, setVerifiedState] = useState<Partial<DateRange>>({});
  const [errorState, setErrorState] = useState<InputDateRangeError>({
    fromError: false,
    toError: false,
    rangeError: false,
  });
  const buttonRef = useRef(null);
  const buttonRefMobile = useRef(null);
  const contentRefMobile = useRef(null);
  const { ref, isComponentVisible, setIsComponentVisible } = useComponentVisible(false, [
    buttonRef,
    buttonRefMobile,
    contentRefMobile,
  ]);
  const [isModalVisible, setIsModalVisible] = useState(false);

  const chevronClass = cn(css.chevron, { [css.active]: isComponentVisible });
  const [_forceRender, forceUpdate] = useReducer((x) => x + 1, 0);

  const printDateRange = () => {
    const { from, to } = verifiedState;
    if (formatter && from && to) {
      return formatter({ from, to });
    }
    return '';
  };

  useEffect(() => {
    if (selectedRange === 'custom') {
      return;
    }
    let from = setTime(new Date(), 0, 0);
    if (selectedRange === '30d') {
      from = addDays(from, -30);
    } else if (selectedRange === '60d') {
      from = addDays(from, -60);
    } else if (selectedRange === '90d') {
      from = addDays(from, -90);
    } else if (selectedRange === '1y') {
      from = addYears(from, -1);
    } else if (selectedRange === '3y') {
      from = addYears(from, -3);
    } else if (selectedRange === 'ytd') {
      from = setMonth(setDate(from, 1), 0);
    }
    setState({ from, to: new Date() });
    setIsComponentVisible(false);
  }, [selectedRange]);

  useEffect(() => {
    const { from, to } = state;
    const { fromError, toError } = errorState;
    let rangeError = false;
    if (from && to) {
      if (isBefore(to, from)) {
        rangeError = true;
      } else if (min && (isBefore(to, min) || isBefore(from, min))) {
        rangeError = true;
      } else if (max && (isAfter(to, max) || isAfter(from, max))) {
        rangeError = true;
      }
      setErrorState({ ...errorState, rangeError });
      if (!rangeError) {
        if (!fromError && !toError && from && to) {
          setVerifiedState({ from, to });
        }
      }
    }
  }, [state]);

  useEffect(() => {
    if (!isComponentVisible) {
      if (errorState.fromError || errorState.toError || errorState.rangeError) {
        setErrorState({ fromError: false, rangeError: false, toError: false });
        setState(verifiedState);
        forceUpdate();
      }
    }
  }, [isComponentVisible]);

  useEffect(() => {
    const { from, to } = verifiedState;
    if (from && to) {
      onChange({ from, to });
    }
  }, [verifiedState]);

  useEffect(() => {
    if (value && JSON.stringify(value) !== JSON.stringify(state)) {
      setState(value);
    }
  }, [value]);

  useEffect(() => {
    let resizeObserver: ResizeObserver;
    const ro = new ResizeObserver((_, observer) => {
      resizeObserver = observer;
      const width = document.body.offsetWidth;
      if (breakpoint(width) === VIEW_PORT.MOBILE && isComponentVisible && !isModalVisible) {
        setIsComponentVisible(false);
        setIsModalVisible(true);
      }

      if (breakpoint(width) !== VIEW_PORT.MOBILE && !isComponentVisible && isModalVisible) {
        setIsComponentVisible(true);
        setIsModalVisible(false);
      }
    });
    ro.observe(document.body);
    return () => {
      resizeObserver && resizeObserver.disconnect();
    };
  }, [isComponentVisible, isModalVisible]);

  const content = (ref?: React.MutableRefObject<HTMLDivElement | null>) => (
    <div ref={ref} className={css.popupBox}>
      <Space justify={'between'} className={css.dateRange}>
        <div style={{ width: '50%', marginRight: 6 }}>
          <Typography size={6}>From</Typography>
          <InputDate
            className={cn({ [css.error]: errorState.rangeError })}
            onChange={(from, fromError) => {
              setSelectedRange('custom');
              setErrorState({ ...errorState, fromError });
              if (from != null && !fromError) {
                setState({ ...state, from });
              }
            }}
            value={state?.from}
            placeholder={'DD/MM/YYYY'}
            _forceRerender={_forceRender}
          />
        </div>
        <div style={{ width: '50%', marginLeft: 6 }}>
          <Typography size={6}>To</Typography>
          <InputDate
            className={cn({ [css.error]: errorState.rangeError })}
            onChange={(to, toError) => {
              setSelectedRange('custom');
              setErrorState({ ...errorState, toError });
              if (to != null && !toError) {
                setState({ ...state, to });
              }
            }}
            value={state?.to}
            placeholder={'DD/MM/YYYY'}
            onEnterPressed={() => {
              if (!errorState.rangeError && !errorState.toError && !errorState.fromError) {
                setIsComponentVisible(false);
              }
            }}
            _forceRerender={_forceRender}
          />
        </div>
      </Space>
      {(errorState.fromError || errorState.toError || errorState.rangeError) && (
        <Space className={css.errorMsg} align={'center'}>
          <IconError />
          <Typography size={7}>
            {errorState.fromError && "Enter a valid date into the 'From' field."}
            {!errorState.fromError &&
              errorState.toError &&
              "Enter a valid date into the 'To' field."}
            {!errorState.fromError &&
              !errorState.toError &&
              errorState.rangeError &&
              'The input date range is not valid.'}
          </Typography>
        </Space>
      )}
      <div className={css.quickRange}>
        <Typography size={7}>Quick range</Typography>
        <Space>
          <button
            className={cn(css.quickRangeBtn, {
              [css.active]: selectedRange === '30d',
            })}
            onClick={() => {
              setSelectedRange('30d');
              setIsModalVisible(false);
            }}
          >
            30D
          </button>
          <button
            className={cn(css.quickRangeBtn, {
              [css.active]: selectedRange === '60d',
            })}
            onClick={() => {
              setSelectedRange('60d');
              setIsModalVisible(false);
            }}
          >
            60D
          </button>
          <button
            className={cn(css.quickRangeBtn, {
              [css.active]: selectedRange === '90d',
            })}
            onClick={() => {
              setSelectedRange('90d');
              setIsModalVisible(false);
            }}
          >
            90D
          </button>
        </Space>
        <Space>
          <button
            className={cn(css.quickRangeBtn, {
              [css.active]: selectedRange === '1y',
            })}
            onClick={() => {
              setSelectedRange('1y');
              setIsModalVisible(false);
            }}
          >
            1Y
          </button>
          <button
            className={cn(css.quickRangeBtn, {
              [css.active]: selectedRange === '3y',
            })}
            onClick={() => {
              setSelectedRange('3y');
              setIsModalVisible(false);
            }}
          >
            3Y
          </button>
          <button
            className={cn(css.quickRangeBtn, {
              [css.active]: selectedRange === 'ytd',
            })}
            onClick={() => {
              setSelectedRange('ytd');
              setIsModalVisible(false);
            }}
          >
            YTD
          </button>
        </Space>
      </div>
    </div>
  );

  const inputButton = (ref: React.MutableRefObject<HTMLButtonElement | null>) => (
    <button
      ref={ref}
      onClick={() => {
        if (breakpoint(document.body.offsetWidth) === VIEW_PORT.MOBILE) {
          setIsModalVisible(!isModalVisible);
        } else {
          setIsComponentVisible(!isComponentVisible);
        }
      }}
      className={css.input}
    >
      <div className={css.label}>{printDateRange()}</div>
      <div className={css.verticalBar} />
      <IconChevronDown className={chevronClass} />
    </button>
  );

  return (
    <>
      <Popover
        fullWidth={true}
        visible={isComponentVisible}
        className={cn(css.desktopTablet, className)}
        style={style}
        content={content(ref)}
      >
        {inputButton(buttonRef)}
      </Popover>
      <div className={css.mobile}>{inputButton(buttonRefMobile)}</div>
      <Modal
        onClose={() => {
          setIsModalVisible(false);
        }}
        closeButtonHeader={
          <Typography size={5} className={css.modalHeader}>
            Please select a date range
          </Typography>
        }
        visible={isModalVisible}
        gutterClass={css.modalGutter}
        wrapperClass={css.modalWrapper}
        zIndex={zIndex}
      >
        {content(contentRefMobile)}
      </Modal>
    </>
  );
};
