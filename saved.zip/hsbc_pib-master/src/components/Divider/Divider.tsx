import React from 'react';
import cn from 'classnames';
import css from './Divider.module.scss';

export interface DividerProps {
  className?: string;
  style?: React.CSSProperties;
}

export const Divider: React.VFC<DividerProps> = (props) => {
  const { className, style } = props;
  const cls = cn(css.divider, className);
  return <div className={cls} style={style} role="separator" />;
};
