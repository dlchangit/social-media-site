import React, { CSSProperties } from 'react';
import { Space } from '../Space';
import { IconChevronDown } from '../Icon';
import classnames from 'classnames';
import css from './Expand.module.scss';

export interface ExpandProps {
  title: React.ReactElement;
  expanded?: boolean;
  onChange?: (expanded: boolean) => void;
  style?: CSSProperties;
  className?: string;
}

export const Expand: React.FC<ExpandProps> = (props) => {
  const { title, expanded = false, onChange, children, style, className } = props;
  const [state, setState] = React.useState(expanded);

  React.useEffect(() => {
    onChange && onChange(state);
  }, [state]);

  return (
    <div style={style} className={className}>
      <button onClick={() => setState(!state)} className={css.title}>
        <Space align={'center'}>
          <IconChevronDown
            className={classnames(css.icon, { [css.expanded]: state })}
            style={{ marginRight: 8 }}
          />
          {title}
        </Space>
      </button>
      {state && children}
    </div>
  );
};
