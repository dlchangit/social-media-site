import React, { forwardRef, ReactNodeArray } from 'react';
import cn from 'classnames';
import css from './Space.module.scss';

export interface SpaceProps extends React.HTMLAttributes<HTMLDivElement> {
  direction?: 'horizontal' | 'vertical';
  justify?: 'start' | 'end' | 'center' | 'around' | 'between';
  align?: 'start' | 'end' | 'center' | 'baseline' | 'stretch';
  wrap?: boolean;
  split?: React.ReactElement;
  children: React.ReactNode | React.ReactNodeArray;
}

export const Space = forwardRef<HTMLDivElement, SpaceProps>((props, ref) => {
  const {
    className,
    children,
    split,
    direction = 'horizontal',
    // justify = 'start',
    // align = 'stretch',
    justify,
    align,
    wrap = false,
    ...rest
  } = props;

  const cls = cn(
    css.space,
    { [css[`justify-${justify}`]]: justify },
    { [css[`align-${align}`]]: align },
    {
      [css.horizontal]: direction === 'horizontal',
      [css.vertical]: direction === 'vertical',
    },
    { [css.noWrap]: !wrap },
    className
  );

  let kids: ReactNodeArray = [];
  if (Array.isArray(children)) {
    kids = children;
  } else {
    kids = [children];
  }

  return (
    <div ref={ref} className={cls} {...rest}>
      {kids.map((kid, index) => {
        return (
          <React.Fragment key={`space-item-${index}`}>
            {kid} {index < kids.length - 1 && split}
          </React.Fragment>
        );
      })}
    </div>
  );
});
