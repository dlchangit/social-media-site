import { Result } from './Result';
import { EmptyResult } from './EmptyResult';
import { LoadResult } from './LoadResult';

export { Result, EmptyResult, LoadResult };
