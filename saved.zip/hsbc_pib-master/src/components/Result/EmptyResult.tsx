import React from 'react';
import { ImageHoldingEmpty } from '../Image';
import { Result, ResultProps } from './Result';
import css from './Result.module.scss';

type Props = Omit<ResultProps, 'icon'>;

export const EmptyResult: React.VFC<Props> = (props) => {
  return (
    <Result
      {...props}
      icon={
        <div className={css.imageWrapper}>
          <ImageHoldingEmpty />
        </div>
      }
    />
  );
};
