import React, { CSSProperties } from 'react';
import cn from 'classnames';
import css from './Result.module.scss';

export interface ResultProps extends React.HTMLAttributes<HTMLDivElement> {
  label: string;
  icon?: React.ReactElement;
  border?: boolean;
  style?: CSSProperties;
}

export const Result: React.VFC<ResultProps> = (props) => {
  const { label, icon, className, border = false, ...rest } = props;

  const cls = cn(css.result, { [css.border]: border }, className);

  return (
    <div className={cls} {...rest}>
      {icon}
      <span className={css.label}>{label}</span>
    </div>
  );
};
