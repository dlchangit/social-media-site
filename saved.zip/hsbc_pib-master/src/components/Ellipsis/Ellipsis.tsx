import * as React from 'react';
import { useCallback, useEffect, useRef, useState } from 'react';
import { ResizeObserver } from '@juggle/resize-observer';

export interface EllipsisProps {
  text: string;
  render?: (ellipsisText: React.ReactNode | string, isEllipsis: boolean) => React.ReactNode;
  lines?: number;
  className?: string;
  style?: React.CSSProperties;
}

export const Ellipsis: React.FC<EllipsisProps> = (props) => {
  const { lines = 1, text, render, ...rest } = props;
  const suffix = '...';

  const [isEllipsis, setIsEllipsis] = useState<boolean>(false);
  const [ellipsisText, setEllipsisText] = useState<string>('');
  const ellipsisNodeRef = useRef<HTMLDivElement>(null);
  const targetHeight = useRef(0);

  const calculateCurrentHeight = useCallback(() => {
    return (
      ellipsisNodeRef?.current?.offsetHeight ||
      ellipsisNodeRef?.current?.getBoundingClientRect()?.height
    );
  }, []);

  const bisection = useCallback(
    (start: number, end: number) => {
      if (ellipsisNodeRef && ellipsisNodeRef.current) {
        if (start > end) return;
        const index = Math.floor((start + end) / 2);
        const str = text.substring(0, index);
        ellipsisNodeRef.current.innerText = str + suffix;
        const currentHeight = calculateCurrentHeight() ?? 0;
        if (currentHeight < targetHeight.current) bisection(index + 1, end);
        if (currentHeight > targetHeight.current) bisection(start, index - 1);
        if (currentHeight === targetHeight.current && index < end) {
          if (index + 1 === end) {
            const last = text.substring(0, end);
            ellipsisNodeRef.current.innerText = last + suffix;
            if (ellipsisNodeRef.current.offsetHeight > targetHeight.current)
              ellipsisNodeRef.current.innerText = str + suffix;
          } else {
            bisection(index, end);
          }
        }
      }
    },
    [text]
  );

  useEffect(() => {
    let resizeObserver: ResizeObserver;
    const ro = new ResizeObserver((_, observer) => {
      if (!ellipsisNodeRef.current) return;
      resizeObserver = observer;
      const lineHeight = parseInt(
        getComputedStyle(ellipsisNodeRef.current, null).lineHeight || '10',
        10
      );
      const currentHeight = calculateCurrentHeight() ?? 0;
      targetHeight.current = lines * lineHeight;
      const isOk = currentHeight > targetHeight.current;
      if (isOk) bisection(0, text.length - 1);
      if (ellipsisNodeRef.current.innerText !== ellipsisText)
        setEllipsisText(ellipsisNodeRef.current.innerText);
      if (!isEllipsis && isOk) setIsEllipsis(isOk);
    });
    ro.observe(ellipsisNodeRef?.current?.parentNode as Element);
    return () => {
      resizeObserver && resizeObserver.disconnect();
    };
  }, [lines, text]);

  if (render && ellipsisText) {
    return (
      <div ref={ellipsisNodeRef} {...rest}>
        {render(ellipsisText, isEllipsis)}
      </div>
    );
  } else {
    return (
      <div ref={ellipsisNodeRef} {...rest}>
        {text}
      </div>
    );
  }
};
