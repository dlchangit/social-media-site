import config from '../config/HK/common/config/pas';
import { AccountGroupInformation } from '../@types/R18Response';

export enum BundleDEC {
  Empty = '',
  HSBCAdvanceIntegratedAccount = 'HSBC Advance Integrated Account',
  HSBCPersonalIntegratedAccount = 'HSBC Personal Integrated Account',
  HSBCPremierIntegratedAccount = 'HSBC Premier Integrated Account',
  Portfolio = 'Portfolio',
}

export enum IsAllow {
  No = 'NO',
  Yes = 'YES',
}

export interface AccountConfig {
  acctType: string;
  acctProdType: string;
  acctFormat: string;
  isAllowSelect: IsAllow;
  isAllowRebalance: IsAllow;
  bundleDec: BundleDEC;
  tealiumAccountTypeDesc: string;
}

export function mask(mask: string, number: string): string {
  let r = '';
  for (let im = 0, is = 0; im < mask.length && is < number.length; im++) {
    r += mask.charAt(im) == 'N' || mask.charAt(im) == 'C' ? number.charAt(is++) : mask.charAt(im);
  }
  return r;
}

export function accountTypeConfig(
  acctType: string,
  acctProdType: string | null
): AccountConfig | undefined {
  const at = Object.values(config.accountType).find((it) => {
    return (
      it.acctType === acctType &&
      (it.acctProdType === acctProdType || (it.acctProdType === '*' && it.acctProdType === null))
    );
  });
  // if (!at) {
  //   console.log('acctType,acctProdType', acctType, acctProdType);
  // }
  return at as AccountConfig;
}

export function normalizeAccounts(
  arr: AccountGroupInformation[],
  t: (key: string) => string
): { value: string; label: string }[] {
  return arr
    .flatMap((it) => it.accountListInformation)
    .map((it) => {
      return {
        ...it,
        config: accountTypeConfig(it.accountTypeCode, it.accountProductTypeCode),
      };
    })
    .filter((it) => {
      return it.config !== undefined && it.config.isAllowSelect === 'YES';
    })
    .map((it) => {
      const config = it.config as AccountConfig;
      return {
        value: it.accountNumber,
        label:
          mask(config.acctFormat, it.accountNumber) +
          ' ' +
          (it.accountProductTypeCode !== null ? t(it.accountProductTypeCode) : ''),
      };
    })
    .slice(0, 10);
}
