//mock angular.isBlank
export function isBlank(str: string | any[] | null | undefined): boolean {
  return (
    str === null ||
    str === undefined ||
    (typeof str === 'string' && str.trim().length === 0) ||
    (Array.isArray(str) && str.length === 0)
  );
}

export function isNotBlank(str: string | any[] | null | undefined): boolean {
  return !isBlank(str);
}
