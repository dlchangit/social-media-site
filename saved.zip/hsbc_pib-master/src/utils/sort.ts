export enum SortDirection {
  NONE = 'none',
  ASC = 'ascending',
  DESC = 'descending',
}

// export function alphabeticalSort(a: string, b: string): 0 | -1 | 1 {
//   if (a < b) {
//     return -1;
//   }
//   if (a > b) {
//     return 1;
//   }
//   return 0;
// }

export function nextSortDirection(prevDirection: SortDirection): SortDirection {
  if (prevDirection === SortDirection.NONE) {
    return SortDirection.DESC;
  }
  if (prevDirection === SortDirection.DESC) {
    return SortDirection.ASC;
  }
  if (prevDirection === SortDirection.ASC) {
    return SortDirection.NONE;
  }
  return SortDirection.NONE;
}

export function numericSort(
  a: number | null | undefined,
  b: number | null | undefined,
  direction: SortDirection = SortDirection.ASC
): 0 | -1 | 1 {
  if (a === undefined || b === undefined || a === null || b === null) return 0;

  if (direction === SortDirection.ASC) {
    if (a > b) {
      return 1;
    }
    if (a < b) {
      return -1;
    }
    if (a == b) {
      return 0;
    }
  }

  if (direction === SortDirection.DESC) {
    if (a > b) {
      return -1;
    }
    if (a < b) {
      return 1;
    }
    if (a == b) {
      return 0;
    }
  }

  return 0;
}

export function alphabeticalSort(
  a: string | null | undefined,
  b: string | null | undefined,
  direction: SortDirection = SortDirection.ASC
): 0 | -1 | 1 {
  if (a === undefined || b === undefined || a === null || b === null) return 0;

  if (direction === SortDirection.ASC) {
    if (a > b) {
      return 1;
    }
    if (a < b) {
      return -1;
    }
    if (a == b) {
      return 0;
    }
  }

  if (direction === SortDirection.DESC) {
    if (a > b) {
      return -1;
    }
    if (a < b) {
      return 1;
    }
    if (a == b) {
      return 0;
    }
  }

  return 0;
}

export function dateSort(
  a: Date | null | undefined,
  b: Date | null | undefined,
  direction: SortDirection = SortDirection.ASC
): 0 | -1 | 1 {
  if (a === undefined || b === undefined || a === null || b === null) return 0;

  if (direction === SortDirection.ASC) {
    if (a.getTime() > b.getTime()) {
      return 1;
    }
    if (a.getTime() < b.getTime()) {
      return -1;
    }
    if (a.getTime() == b.getTime()) {
      return 0;
    }
  }

  if (direction === SortDirection.DESC) {
    if (a.getTime() > b.getTime()) {
      return -1;
    }
    if (a.getTime() < b.getTime()) {
      return 1;
    }
    if (a.getTime() == b.getTime()) {
      return 0;
    }
  }

  return 0;
}

type Period = { digit: number; unit: 'D' | 'W' | 'M' | 'Y' };

function toDay(p: Period) {
  switch (p.unit) {
    case 'D':
      return p.digit;
    case 'W':
      return p.digit * 7;
    case 'M':
      return p.digit * 30;
    case 'Y':
      return p.digit * 365;
  }
}

export function periodSort(
  a: Period | null | undefined,
  b: Period | null | undefined,
  direction: SortDirection = SortDirection.ASC
): 0 | -1 | 1 {
  if (a === undefined || b === undefined || a === null || b === null) return 0;

  if (direction === SortDirection.ASC) {
    if (toDay(a) > toDay(b)) {
      return 1;
    }
    if (toDay(a) < toDay(b)) {
      return -1;
    }
    if (toDay(a) == toDay(b)) {
      return 0;
    }
  }

  if (direction === SortDirection.DESC) {
    if (toDay(a) > toDay(b)) {
      return -1;
    }
    if (toDay(a) < toDay(b)) {
      return 1;
    }
    if (toDay(a) == toDay(b)) {
      return 0;
    }
  }

  return 0;
}
