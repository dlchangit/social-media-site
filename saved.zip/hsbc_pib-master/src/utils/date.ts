import { format, setHours, setMilliseconds, setMinutes, setSeconds } from 'date-fns';

export function setTime(
  date: Date | number,
  hours: number,
  minutes: number,
  seconds = 0,
  milliseconds = 0
): Date {
  return setMilliseconds(
    setSeconds(setMinutes(setHours(date, hours), minutes), seconds),
    milliseconds
  );
}

export function formatDateTime(date: Date, locale: string): string {
  if (locale === 'US') {
    return format(date, 'HH:mm LLL d y') + ' ' + locale;
  }
  return format(date, 'HH:mm d LLL y') + ' ' + locale;
}

export function formatDate(date: Date, config?: 'US' | string): string {
  if (config === 'US') {
    return format(date, 'LLL d y');
  }
  return format(date, 'd LLL y');
}

export function textToPeriod(
  period?: string
):
  | {
      digit: number;
      unit: 'D' | 'W' | 'M' | 'Y';
    }
  | undefined {
  if (typeof period !== 'string') {
    return undefined;
  }
  const digit = period.match(/^[0-9]+/);
  if (digit === null) {
    return undefined;
  }
  const unit = period.replace(digit[0], '');
  if (unit !== 'D' && unit !== 'W' && unit !== 'M' && unit !== 'Y') {
    return undefined;
  }
  return {
    digit: parseInt(digit[0]),
    unit,
  };
}
