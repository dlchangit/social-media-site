import React, { ReactElement, ReactFragment } from 'react';
import { isFragment } from 'react-is';

export function toArray(
  children?: ReactElement | ReactElement[] | ReactFragment
): React.ReactElement[] {
  let ret: ReactElement[] = [];
  if (children === undefined) {
    return ret;
  }

  if (Array.isArray(children)) {
    ret = ret.concat((children as ReactElement[]).flatMap((it) => toArray(it)));
  } else if (isFragment(children) && children.props) {
    ret = ret.concat(toArray(children.props.children));
  } else {
    React.Children.forEach(children as ReactElement, (child) => {
      ret.push(child);
    });
  }

  return ret;
}

export enum VIEW_PORT {
  MOBILE,
  TABLET,
  DESKTOP,
}

export function breakpoint(width: number): VIEW_PORT {
  if (width <= 960 - 1) {
    return VIEW_PORT.MOBILE;
  }
  if (width <= 1280 - 1) {
    return VIEW_PORT.TABLET;
  }
  return VIEW_PORT.DESKTOP;
}
