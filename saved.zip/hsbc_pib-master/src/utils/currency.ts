export enum CurrencyCodeType {
  PRODUCT = 'PRODUCT',
  ACCOUNT = 'ACCOUNT',
  LOCAL = 'LOCAL',
}
