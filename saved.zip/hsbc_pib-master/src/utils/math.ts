export function formatDigits(
  num: number,
  minimumFractionDigits = 2,
  maximumFractionDigits = 2
): string {
  return new Intl.NumberFormat('en-UK', {
    style: 'decimal',
    minimumFractionDigits,
    maximumFractionDigits,
  }).format(num);
}

// export function splitThousands(num: number | string): string {
//   return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
// }
