//TODO move to config
import { WealthDashboardPresConstants } from './WealthDashboardPresConstants';
import { isBlank, isNotBlank } from './check';

enum WealthDashboardPresUtil {
  ALLOW_INDICATOR_VALUE = 'Y',
  NOT_ALLOW_INDICATOR_VALUE = 'N',
}

function isAllowIndicator(indicator: string): boolean {
  return indicator === WealthDashboardPresUtil.ALLOW_INDICATOR_VALUE;
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
function getKeyListWithComma(config: any, keyWithComma: string): string[] | null {
  if (config == null || keyWithComma == null) {
    return null;
  }
  let keyStr = config[keyWithComma];
  if (keyStr == null) {
    return null;
  }
  const lastPos = keyStr.length - 1;
  if (',' === keyStr.slice(lastPos)) {
    keyStr = keyStr.slice(0, keyStr.length - 1);
  }
  return keyStr.split(',');
}

function checkWhetherTradableProduct(
  //wdConfig
  // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
  wealthDashboardConfigMessageSource: any,
  wpcProductType: string,
  wpcProductSubType: string
): boolean {
  let tradable = true;
  const notTradableProducts = getKeyListWithComma(
    wealthDashboardConfigMessageSource,
    WealthDashboardPresConstants.NOT_TRADABLE_PRODUCTS
  );
  if (
    notTradableProducts?.includes(wpcProductType + '|' + wpcProductSubType) ||
    notTradableProducts?.includes(wpcProductType)
  ) {
    tradable = false;
  }
  return tradable;
}

function getProductTypeMappingCode(
  config: Record<string, string>,
  dashboardType: string,
  dashboardSubType: string,
  wpcSubType: string
): string | null {
  let mappingKey;
  let mappingProductType = null;
  if (null == config || isBlank(dashboardType)) {
    // isDebug&&console.error(logName,methodName,"feProductType return null",arguments);
    return mappingProductType;
  } else {
    if (isNotBlank(dashboardSubType) && isNotBlank(wpcSubType)) {
      mappingKey = dashboardType;
      mappingKey = mappingKey + '_' + dashboardSubType + '_' + wpcSubType;
      mappingProductType = config[mappingKey];
    }
    if (isBlank(mappingProductType) && isNotBlank(dashboardSubType)) {
      mappingKey = dashboardType;
      mappingKey = mappingKey + '_' + dashboardSubType;
      mappingProductType = config[mappingKey];
    }
    if (isBlank(mappingProductType) && isNotBlank(wpcSubType)) {
      mappingKey = dashboardType;
      mappingKey = mappingKey + '_' + wpcSubType;
      mappingProductType = config[mappingKey];
    }
    if (isBlank(mappingProductType)) {
      mappingProductType = config[dashboardType];
      if (isBlank(mappingProductType)) {
        mappingProductType = dashboardType;
        // isDebug&&console.error(logName,methodName,dashboardType," can't find any config from productTypeMapping.","[config, dashboardType, dashboardSubType, wpcSubType]",arguments);
      }
    }
  }
  //	        console.log("mappingProductType9",mappingProductType);
  return mappingProductType;
}

export default {
  isAllowIndicator,
  checkWhetherTradableProduct,
  getKeyListWithComma,
  getProductTypeMappingCode,
};
