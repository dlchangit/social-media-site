import axios, { AxiosResponse } from 'axios';

export function fetchWrapper<T>(url: string): Promise<AxiosResponse<T>> {
  return axios.get(url);
}
