//TODO default dummy config for UT, amh-uat.aws didn't override this

export const WealthDashboardPresConstants = {
  /**
   * Used as processor return value to indicate a wire is needed in
   * subsequent event.
   */
  WIRE: 'WIRE',

  /**
   * Used as processor return value to indicate a redirect is needed in
   * subsequent event.
   */
  REDIRECT: 'redirect',

  /** Static values for portlet wiring **/

  PRODUCT_TYPE: 'PRODUCT_TYPE',

  ACCOUNT_GROUP: 'ACCOUNT_GROUP',

  HOLDING_RECORD_INDEX: 'HOLDING_RECORD_INDEX',

  SELECTED_ACCOUNT_GROUP: 'SELECTED_ACCOUNT_GROUP',

  SELECTED_ACCOUNT_HASHCODE: 'SELECTED_ACCOUNT_HASHCODE',

  SELECTED_ADVICE_OPTION: 'SELECTED_ADVICE_OPTION',

  PRODUCT_TYPE_CODE: 'PRODUCT_TYPE_CODE',

  PRODUCT_CODE_ALT_CLASS_CODE: 'PRODUCT_CODE_ALT_CLASS_CODE',

  DEFAULT_PRODUCT_CODE_ALT_CLASS_CODE: 'DEFAULT_PRODUCT_CODE_ALT_CLASS_CODE',

  PRODUCT_COUNTRY_TRADABLE_CODE: 'PRODUCT_COUNTRY_TRADABLE_CODE',

  LOT_INIT_COST_VALUE: 'LOT_INIT_COST_VALUE',

  LOT_INIT_COST_CCY: 'LOT_INIT_COST_CCY',

  ACCT_LIST: 'ACCT_LIST',

  ACCOUNT: 'ACCOUNT',

  ACCOUNT_NUMBER: 'accountNumber',

  ACCOUNT_MAPPING_ENABLE: 'ACCOUNT_MAPPING_ENABLE',

  _ACCOUNT: '_ACCOUNT',

  ACCOUNT_SUFFIX: '_ACCOUNT',

  SELECTED_ACCOUNT_LIST: 'SELECTED_ACCOUNT_LIST',

  ACCOUNT_SEPARATOR: '|',

  /** product path. */
  PATH_SUFFIX: '_PATH',

  _PATH: '_PATH',

  REF_ID_KEY: 'REFID',

  HOLDINGS: 'holdings',

  REFRESH_ACTION: 'Refresh',

  TARGET_NAME: 'TARGET_NAME',

  SELECTED_ACCOUNT_INDEX: 'SELECTED_ACCOUNT_INDEX',

  SELECTED_LOT_INDEX: 'SELECTED_LOT_INDEX',

  SELECTED_LOT_INDEX_ARRAY: 'SELECTED_LOT_INDEX_ARRAY',

  PREV_INDEX: 'PREV_INDEX',

  PRODUCT_TYPE_PATH: 'group.secwealth.perfmtrack.common.nls.product-type',

  /* for aggregation */

  DATE_MAPPING_FORMAT: 'group.secwealth.perfmtrack.holdingdetail.nls.date-mapping-format',

  // The constant is for trade date timeZone properties
  TIME_ZONE_SUFFIX: '_TimeZone',

  /**
   * Key denoting the home currency
   */
  HOME_CURRENCY: 'HOME_CURRENCY',

  /**
   * Key denoting the denominated currency
   */
  DENOMINATED_CURRENCY: 'DENOMINATED_CURRENCY',

  /**
   * Default xval error message for invalid date period
   */
  DEFAULT_INVALID_DATE_PERIOD_ERROR_MESSAGE:
    'DatePeriodXValidator Error Message. ' +
    'Please configure datePeriodInvalidKey message properly',

  /**
   * Default xval error message for invalid date period
   */
  DEFAULT_INVALID_TO_DATE_ERROR_MESSAGE:
    'DatePeriodXValidator Error Message. ' + 'Please configure toDateInvalidKey message properly',

  /**
   * Default xval error message for max back date period
   */
  DEFAULT_MAX_FROM_DATE_ERROR_MESSAGE:
    'DatePeriodXValidator Error Message. ' +
    'Please configure maxFromDateInvalidKey message properly',

  DEFAULT_NO_ACCOUNT_SELECTED_ERROR_MESSAGE:
    'AccountListFilterValidator Error Message. ' +
    'Please select at least an option of the account list.',

  DEFAULT_NO_ORDER_STATUS_SELECTED_ERROR_MESSAGE:
    'OrderStatusFilterValidator Error Message. ' +
    'Please select  at least an option of the order status.',

  /**
   * Key denoting the From Date should not be earlier than X months. X is
   * configurable by site
   */
  MAX_BACK_DATE_MONTHS: 'MAX_BACK_DATE_MONTHS',

  /*for perfermance chart*/
  LAST_5_DAYS_OPTION: 'Last_5_Days',

  LAST_30_DAYS_OPTION: 'Last_30_Days',

  /*for perfermance chart*/
  LAST_3_MONTHS_OPTION: 'Last_3_Months',

  /*for perfermance chart*/
  LAST_6_MONTHS_OPTION: 'Last_6_Months',

  LAST_60_DAYS_OPTION: 'Last_60_Days',

  LAST_90_DAYS_OPTION: 'Last_90_Days',

  LAST_365_DAYS_OPTION: 'Last_Year',

  LAST_730_DAYS_OPTION: 'Last_2_Year',

  LAST_1095_DAYS_OPTION: 'Last_3_Year',

  /*for perfermance chart*/
  LAST_1825_DAYS_OPTION: 'Last_5_Year',

  LAST_2555_DAYS_OPTION: 'Last_7_Year',

  CURRENT_YEAR_OPTION: 'Current_Year_To_Date',

  CURRENT_YEAR_FROM_DATE: 'CURRENT_YEAR_FROM_DATE',

  CURRENT_TAX_YEAR_OPTION: 'Current_Tax_year',

  PREV_TAX_YEAR_OPTION: 'Prev_Tax_year',

  CUSTOM_DATE_OPTION: 'Custom_Date_Range',

  CURRENT_TAX_YEAR_FROM_DATE: 'CURRENT_TAX_YEAR_FROM_DATE',

  PREV_TAX_YEAR_FROM_DATE: 'PREV_TAX_YEAR_FROM_DATE',

  PREV_TAX_YEAR_TO_DATE: 'PREV_TAX_YEAR_TO_DATE',

  DEFAULT_DATE_FILTER_SELECTION: 'DEFAULT_DATE_FILTER_SELECTION',

  DEFAULT_DATE_FILTER_SELECTION_PASTHOLDINGS: 'DEFAULT_DATE_FILTER_SELECTION_PASTHOLDINGS',

  BACK_DATE_DAYS: 'BACK_DATE_DAYS',

  DATE_FORMAT_PATTERNKEY: 'DATE_FORMAT_PATTERNKEY',

  SHORT_DATE_FORMAT_PATTERNKEY: 'SHORT_DATE_FORMAT_PATTERNKEY',

  DATE_RANGE_DISPLAY_FORMAT_PATTERNKEY: 'DATE_RANGE_DISPLAY_FORMAT_PATTERNKEY',

  DATE_FORMAT_LINK: 'DATE_FORMAT_LINK',

  DATETIME_FORMAT_PATTERNKEY: 'DATETIME_FORMAT_PATTERNKEY',

  THIRTY_DAYS: 30,

  SIXTY_DAYS: 60,

  NINETY_DAYS: 90,

  ONE_YEAR_IN_DAYS: 365,

  TWO_YEARS_IN_DAYS: 730,

  /** Product type radio button selection for transaction history BEG **/
  SELECT_PRODUCT_TYPE_OPTION: 'SELECT_PRODUCT_TYPE_OPTION',

  SPECIFIC_HOLDING_OPTION: 'SPECIFIC_HOLDING_OPTION',
  /** Product type radio button selection for transaction history END **/

  NULL_DISPLAY_LABEL: 'L_null_display',

  /**
   * The param key for wiring data
   */
  PRODUCT_NAME: 'PRODUCT_NAME',

  PRODUCT_DASHBOARD_SUB_TYPE: 'PRODUCT_DASHBOARD_SUB_TYPE',

  PRODUCT_DASHBOARD_TYPE: 'PRODUCT_DASHBOARD_TYPE',

  PRODUCT_INVESTMENT_DATA_STORE_NUMBER: 'PRODUCT_INVESTMENT_DATA_STORE_NUMBER',

  PRODUCT_ALT_NUMBER: 'PRODUCT_ALT_NUMBER',

  PRODUCT_DISPLAY_ALT_NUMBER: 'PRODUCT_DISPLAY_ALT_NUMBER',

  PRODUCT_SHORT_NAME: 'PRODUCT_SHORT_NAME',

  PRODUCT_LONG_NAME: 'PRODUCT_LONG_NAME',

  PRODUCT_CODE: 'PRODUCT_CODE',

  /**
   * wire value to indicate current holdings was the origin page
   */
  CURRENT_HOLDINGS: 'CURRENT_HOLDINGS',

  ORDER_STATAS: 'ORDER_STATUS',

  GOAL_TRACKING_HOLDING: 'GOAL_TRACKING_HOLDINGS',

  ORIGIN_WATCH_LIST: 'WATCH_LIST',

  /**
   * wire value to indicate realised gain/loss was the origin page
   */
  REALISED_GAIN_LOSS: 'REALISED_GAIN_LOSS',

  TRANSACTION_HISTORY: 'TRANSACTION_HISTORY',

  /**
   * wire value to indicate realised gain/loss was the origin page
   */
  ACCOUNT_BREAKDOWN: 'ACCOUNT_BREAKDOWN',

  ACCOUNT_VIEW: 'ACCOUNT_VIEW',

  /**
   * The page we came from.
   */
  ORIGIN_PAGE: 'ORIGIN_PAGE',

  /** Constants used to retrieve the FE Txn Type to display - BEG **/
  TRANSACTION_TYPE: 'TRANSACTION_TYPE',

  BUY: 'BUY',

  SELL: 'SELL',

  SWITCH: 'SWITCH',

  TRADE: 'TRADE',

  DIVIDEND_INTEREST: 'DIVIDEND_INTEREST',

  /** The Constant OTHERS. changne to value to OTHER from EUR */
  OTHERS: 'OTHER',
  /** Constants used to retrieve the FE Txn Type to display - END **/

  BOOLEAN_TRUE_STRING: true,

  PAGING_DIRECTION_CODE: '+',

  NUMBER_OF_PER_RECORD: 'NUM_OF_PER_REC',

  NUM_REC_DISPLAY: 'NUM_REC_DISPLAY',

  DEFAULT_NUM_OF_PER_RECORD: 20,

  DEFAULT_PAGINATION_START_DETAIL: '1',

  DEFAULT_ORDER_STATUS_PAGINATION_START_DETAIL: '11',

  TAX_LOT_DETAILS_COLUMNS: 'TAX_LOT_DETAILS_COLUMNS',

  ACCOUNT_DESCRIPTION_COLSPAN: 'ACCOUNT_DESCRIPTION_COLSPAN',

  DEFAULT_TAX_LOT_DETAILS_COLUMNS: '8',

  DEFAULT_ACCOUNT_DESCRIPTION_COLSPAN: '3',

  // scwd
  ALLOW_INDICATOR_VALUE: 'Y',
  NOT_ALLOW_INDICATOR_VALUE: 'N',

  PRODUCT_TYPE_LIST: 'COMMA_SEPARATED_PRODUCT_KEY_LIST',
  CASH_HISTORY_PRODUCT_KEY_LIST: 'CASH_HISTORY_PRODUCT_KEY_LIST',

  INV_PRODUCT_TYPE_LIST: 'INV_PRODUCT_KEY_LIST',

  CASH_PRODUCT_TYPE_LIST: 'CASH_PRODUCT_KEY_LIST',

  OTHERS_PRODUCT_KEY_TAB_LIST: 'OTHERS_PRODUCT_KEY_TAB_LIST',

  OTHERS_PRODUCT_TYPE_LIST: 'OTHERS_PRODUCT_KEY_LIST',

  INSURANCE_PRODUCT_TYPE_LIST: 'INSURANCE_PRODUCT_KEY_LIST',

  OTHER_LIABILITY_PRODUCT_KEY_LIST: 'OTHER_LIABILITY_PRODUCT_KEY_LIST',

  LIABILITY_PRODUCT_KEY_LIST: 'LIABILITY_PRODUCT_KEY_LIST',

  OTHER_PROTECTION_PRODUCT_KEY_LIST: 'OTHER_PROTECTION_PRODUCT_KEY_LIST',

  ORDER_STATUS_GROUP_LIST: 'ORDER_STATUS_GROUP_KEY_LIST',

  ORDER_STATUS_HIDDEN_PRODUCT_TYPES: 'ORDER_STATUS_HIDDEN_PRODUCT_TYPES',

  HIDE_VIEW_ORDER_DETAILS_LINK_SUFFIX: '_viewOrderDetail_link',

  HIDE_CANCEL_BUTTON_SUFFIX: '_cancel_button',

  HIDE_MODIFY_BUTTON_SUFFIX: '_modify_button',

  HIDE_EXECUTION_DATE: '_execution_date',

  HIDE_NET_AMOUNT: '_net_amount',

  HIDDEN_PRODUCT_TYPES_KEY: 'HIDDEN_PRODUCT_TYPES',

  IS_POPUP_SUFFIX: '_ISPOPUP',

  WINDOW_NAME_SUFFIX: '_WINDOWNAME',

  PRODUCT_TYPE_INV_CLASS: 'INV',

  PRODUCT_TYPE_INV_FOLDER_PATH: 'inv',

  PRODUCT_TYPE_CASH_CLASS: 'CASH',

  PRODUCT_TYPE_CASH_FOLDER_PATH: 'cash',

  PRODUCT_TYPE_INSURANCE_CLASS: 'INSURANCE',

  PRODUCT_TYPE_INSURANCE_FOLDER_PATH: 'insurance',

  PRODUCT_TYPE_OTHER_ASSET_CLASS: 'OTHERASSET',

  PRODUCT_TYPE_OTHER_ASSET_FOLDER_PATH: 'otherasset',

  PRODUCT_TYPE_OTHER_LIABILITY_CLASS: 'OTHER_LIABILITY',

  PRODUCT_TYPE_OTHER_LIABILITY_FOLDER_PATH: 'otherliability',

  PRODUCT_TYPE_LIABILITIES_CLASS: 'LIABILITIES',

  PRODUCT_TYPE_LIABILITIES_FOLDER_PATH: 'liability',

  PRODUCT_TYPE_OTHER_PROTECTION_CLASS: 'OTHER_PROTECTION',

  PRODUCT_TYPE_OTHER_PROTECTION_FOLDER_PATH: 'otherprotection',

  PRODUCT_TYPE_ORDER_CLASS: 'ORDER',

  PRODUCT_TYPE_ORDER_FOLDER_PATH: 'order',

  PRODUCT_TYPE_COLOR_SUFFIX: '_COLOR',

  PRODUCT_TYPE_BORDER_SUFFIX: '_BORDER',

  PRODUCT_TYPE_BORDERTEXT_SUFFIX: '_BORDER_TEXT',

  PRODUCT_TYPE_BORDER_COLOR: '_BORDER_COLOR',

  DATE_LABEL_SUFFIX: '_DATE_LABEL',

  BUY_LABEL_REF_SUFFIX: '_BUY_LABEL_REF',

  DEFAULT_BUY_LABEL_REF: 'DEFAULT_BUY_LABEL_REF',

  DASHBOARD_PRODUCT_TYPE_SUFFIX: '_DASHBOARD_PRODUCT_TYPE',

  DENOMINATION_CURRENCY: 'PROD_CCY',

  PORTFOLIO_TOTAL_INFO_TYPE_TOTAL: 'TOTAL',

  PORTFOLIO_TOTAL_INFO_TYPE_INVT: 'INVT',

  PORTFOLIO_TOTAL_INFO_TYPE_CASH: 'CASH',

  PORTFOLIO_TOTAL_INFO_TYPE_INSURANCE: 'INSURANCE',

  PORTFOLIO_TOTAL_INFO_TYPE_OTHERS: 'OTHERASSET',

  PORTFOLIO_TOTAL_INFO_TYPE_OTHER_LIAB: 'OTHER_LIAB',

  PORTFOLIO_TOTAL_INFO_TYPE_LIABILITIES: 'LIABILITIES',

  PORTFOLIO_TOTAL_INFO_TYPE_OTHER_PROT: 'OTHER_PROT',

  LOCAL_BASE_CURRCNCY: 'LOCL_CCY',

  ORDER_STATUS_ALL_TRADES: 'ALL_TRADES',

  ORDER_STATUS_KEY_LIST: 'COMMA_SEPARATED_ORDER_STATUS_KEY_LIST',

  ORDER_STATUS_SUFFIX: '_STATUS',

  ORDER_STATUS_CRNT_HOLD: 'CRHD_STATUS',
  ORDER_STATUS_PENDING_TRADE: 'PEND_STATUS',

  ORDER_STATUS_CANCELLED: 'CANC_STATUS',
  SUB_CATEGORY_KEY_LIST_PRIFIX: 'SUB_CAT_',

  IS_ENABLED_SUB_CATEGORY_PRIFIX: 'SUB_CAT_ENABLED_',

  INV_HISTORY_REQ_TYPE_CRNT: 'CURR',

  INV_HISTORY_REQ_TYPE_PAST: 'PAST',

  INV_HISTORY_REQ_TYPE_ACCT: 'ACCT',

  PRODUCT_DESCRIPTOR_SUFFIX: '_PRODUCT_DESCRIPTOR',

  IDS_PRODUCT_TYPE_MAPPING_SUFFIX: '_IDS_MAPPING',

  // UNITS_EXECUTED_SUFFIX: "_UNITS_EXECUTED",

  PARTIAL_UNITS_SUFFIX: '_PARTIAL_UNITS',

  /**
   * indicate the holding record
   */
  RESP_REC_TYPE_HOLDINGS: 'HLDNG',

  /**
   * indicate the pending record
   */
  RESP_REC_TYPE_ORDER: 'ORDER',

  PRODUCT_TYPE_FUND_CODE: 'UT',

  STRUCTURED_INV_ELI_PRODUCT_TYPE_CODE: 'ELI',

  STRUCTURED_INV_ELN_PRODUCT_TYPE_CODE: 'ELN',

  STRUCTURED_INV_SID_PRODUCT_TYPE_CODE: 'SID',

  STRUCTURED_INV_DCD_PRODUCT_TYPE_CODE: 'DPS',

  STRUCTURED_INV_SN_PRODUCT_TYPE_CODE: 'SN',

  ALTERNATIVE_ETF_PRODUCT_TYPE_CODE: 'ETF',

  ALTERNATIVE_WARRANTS_PRODUCT_TYPE_CODE: 'WRTS',

  ALTERNATIVE_OPTIONS_PRODUCT_TYPE_CODE: 'OPTS',

  ALTERNATIVE_COMMODITIES_PRODUCT_TYPE_CODE: 'COMMODITIES',

  ALTERNATIVE_MAP_PRODUCT_TYPE_CODE: 'MAP',

  ALTERNATIVE_CBBC_PRODUCT_TYPE_CODE: 'LCBB',

  ALTERNATIVE_ADR_PRODUCT_TYPE_CODE: 'ADR',

  STRUCTURED_INVESTMENT_PRODUCT_TYPE_CODE_LIST: 'STRUCTURED_INVESTMENT_PRODUCT_KEY_LIST',

  ORDER_PENDING_TRADE: 'ORDER_PENDING_TRADE',

  ORDER_CANCELLED_EXPIRED: 'ORDER_CANCELLED_EXPIRED',

  ORDER_COMPLETED: 'ORDER_COMPLETED',

  PENDING_ORDER_STATUS_GROUP_ID: 'PENDING',

  COMPLETED_ORDER_STATUS_GROUP_ID: 'COMPLETED',

  EXPIRED_ORDER_STATUS_GROUP_ID: 'EXPIRED',

  ORDER_STATUS_CATEGORY_TYPES: 'ORDER_STATUS_CATEGORIES',

  ORDER_PENDING_DATABLOCK_KEY: 'orderstatus_pending_rec_dataBlock',
  ORDER_COMPLETED_DATABLOCK_KEY: 'orderstatus_completed_rec_dataBlock',
  ORDER_EXPIRED_DATABLOCK_KEY: 'orderstatus_expired_rec_dataBlock',

  SUSPECTED_PRICE_CHARGE: 'SPC',

  /**
   * Place order by unit
   */
  // PLACE_ORDER_BY_UNIT: "R,U,C",
  /**
   * Place order by amount
   */
  // PLACE_ORDER_BY_AMOUNT: "O,S,N",
  // ORDER_TYPE_NEED_APPEND_REFERENCE_TYPE =
  // "D,L,M",
  /**
   * Code used to indicate that ALL assets were selected in the search filter
   */
  ALL_ASSETS: 'ALL_ASSETS',

  /**
   * Key denoting which menu action has been selected
   */
  MENU_ACTION: 'MENU_ACTION',

  /**
   * Code used to indicate a friendly url
   */
  CUN: 'CUN',

  /**
   * Code used to indicate a public website
   */
  PWS: 'PWS',

  /**
   * Key used to determine whether a wire is required
   */
  ISWIRE: 'ISWIRE',

  /**
   * Key used to retrieve the wire step id
   */
  WIRESTEPID: 'WIRESTEPID',

  /**
   * Key used to retrieve the 'wire from'
   */
  WIREFROM: 'WIREFROM',

  /**
   * Key used to determine whether current locale is in primary language
   */
  PRIMARY_LANG: 'PRIMARY_LANG',

  /** Key used to configure which product types to display to the user - BEG **/

  BOND_PROD_TYPE: 'BOND',

  FUND_PROD_TYPE: 'FUND',

  STRUCTURED_INV: 'STRUCTURED_INV',

  EQUITY_PROD_TYPE: 'EQUITY',

  EQUITY_LINKED_INV: 'EQUITY_LINKED_INV',

  STRUCTURE_NOTE: 'STRUCTURE_NOTE',

  STRUCTURED_INV_DEPOSIT: 'STRUCTURED_INV_DEPOSIT',

  DCD: 'DCD',

  OPTIONS_PROD_TYPE: 'OPTIONS',

  WARRANTS: 'WARRANTS',

  LOCAL_CBBC: 'LOCAL_CBBC',

  EXCHANGE_TRADED_FUNDS: 'EXCHANGE_TRADED_FUNDS',

  MARKET_ACCESS_PLATFROM: 'MARKET_ACCESS_PLATFROM',

  AMERICAN_DEPOSITARY_RECEIPT: 'AMERICAN_DEPOSITARY_RECEIPT',

  MISCELLANEOUS: 'MISCELLANEOUS',

  /** Key used to configure which product types to display to the user - END **/

  /**
   * Used to determine the key to retrieve the transaction type codes for a
   * particular product - BEG
   **/
  UNIT_CASH_TXN: 'UNIT_CASH_TXN',

  UNIT_TXN: 'UNIT_TXN',

  CASH_TXN: 'CASH_TXN',

  PERIODIC_FEE_TXN: 'PERIODIC_FEE_TXN',
  /**
   * Used to determine the key to retrieve the transaction type codes for a
   * particular product - END
   **/

  GAINLOSS_GAIN: '1',

  GAINLOSS_LOSS: '-1',

  GAINLOSS_ZERO: '0',

  TAX_LOTS_SUPPORTED: 'TAX_LOTS_SUPPORTED',

  TAX_LOTS_SUPPORTED_SUFFIX: '_TAX_LOTS_SUPPORTED',

  LOT_REF: 'LOT_REF',

  NO_OPENED_ACCOUNT_INDEX: -1,

  WDS_SORTING_ORDER_ASCE: '+',
  WDS_SORTING_ORDER_DES: '-',
  WDS_PAGINATION_ORDER_ASCE: '+',
  WDS_PAGINATION_ORDER_DES: '-',

  /**
   * receive the keys for the passed parameters.
   */
  PASSED_PARAM_PRODUCT_TYPE: 'productType',
  PASSED_PARAM_ORDER_STATUS: 'orderStatus',
  PASSED_PARAM_HISTORY_REQ_TYPE: 'historyReqType',
  PASSED_PARAM_OPENED_PRODUCT_TYPE_CURRENT: 'openedProductTypeCurrent',
  PASSED_PARAM_SELECTED_CURRENCY_CURRENT: 'selectedCurrencyCurrent',
  PASSED_PARAM_SHOWING_VIEW_CURRENT: 'showingViewCurrent',
  PASSED_PARAM_OPENED_PRODUCT_TYPE_PAST: 'openedProductTypePast',
  PASSED_PARAM_OPENED_FLAG: 'openedFlag',
  PASSED_PARAM_SELECTED_CURRENCY_PAST: 'selectedCurrencyPast',
  PASSED_PARAM_OPENED_FLAG_PAST: 'openedFlagPast',
  PASSED_PARAM_SELECTED_CURRENCY_TXNHISTORY: 'selectedCurrencyTxnHistory',
  PASSED_PARAM_SELECTED_CURRENCY_TAXLOT: 'selectedCurrencyTaxLot',
  PASSED_PARAM_SELECTED_PRODUCT_TYPE: 'productTypeSelection',
  PASSED_PARAM_PRODUCT_CODE: 'productCode',
  PASSED_PARAM_PRODUCT_TYPE_OPTION: 'productTypeOption',
  PASSED_PARAM_ORDER_STATUS_CATEGORY: 'orderStatusCategory',
  PASSED_PARAM_END_DETAIL: 'endDetail',
  PASSED_PARAM_SELECTED_CURRENCY_ACCTVIEW: 'selectedCurrencyAcctView',

  /**
   * need grouping or not for product type
   */

  NO_GROUPING_FOR_PRODUCT_TYPE: 'NO_GROUPING',
  NO_SUB_CATEGORY_TYPE: 'NO_SUB_CATEGORY_TYPE',

  /**
   * product type show Maturity / Expiry Date
   */
  PRODUCT_TYPE_SHOW_MATURITY_DATE: 'UT,BOND,SI,LCY,FCY',

  /**
   * product type show Tenor
   */
  PRODUCT_TYPE_SHOW_TENOR: 'SI,LCY,FCY',

  /**
   * product type show product code
   */
  PRODUCT_TYPE_SHOW_PRODUCT_CODE: 'EQ,UT',

  SEPARATED_COMMA: ',',

  /**
   * Any number of these characters are considered delimiters between multiple context config paths in a single String value.
   * Use Function: "Performance Chart","Cash History","TxnHistory"
   */
  CONFIG_LOCATION_DELIMITERS: ',; \t\n',

  /**
   * filter type param key
   */
  FILTER_TYPE_KEY: 'FILTER_TYPE',

  FILTER_TYPE_ACCOUNT: 'ACCOUNT',

  FILTER_TYPE_ORDER_STATUS: 'ORDER_STATUS',

  FCY_PRODUCT_TYPE_CODE: 'FCYDEP',

  LCY_PRODUCT_TYPE_CODE: 'LCYDEP',

  // FCYDEP_TIME_DEP: "FCYDEP_TIME_DEP",
  //
  // FCYDEP_CASH_SAV: "FCYDEP_CASH_SAV",
  //
  // LCYDEP_CASH_SAV: "LCYDEP_CASH_SAV",
  //
  // LCYDEP_TIME_DEP: "LCYDEP_TIME_DEP",

  CASH_SVING_TYPE: 'CASH_SAV',

  TIME_DEP_TYPE: 'TIME_DEP',

  STRUCTURE_INVESTMENT_PRODUCT_TYPE_CODE: 'SI',

  BOND_PRODUCT_TYPE_CODE: 'BOND',

  FUND_PRODUCT_TYPE_CODE: 'UT',

  EQUITY_PRODUCT_TYPE_CODE: 'EQ',

  FX_PRODUCT_TYPE_CODE: 'FX',

  INDEX_PRODUCT_TYPE_CODE: 'INDEX',

  COMMODITY_PRODUCT_TYPE_CODE: 'COMMODITY',

  COMMODITIES_PRODUCT_TYPE_CODE: 'COMMODITIES',

  COMMODITIES_TEMPLATE_TYPE_CODE: 'COMMODITIES',

  DEFAULT_TEMPLATE: 'DEFAULT',

  FXPAIR: 'FXPAIR',

  FX_USD: 'USD',

  FX_SHORT_DESCRIPTOR: 'FX_shortDescriptor',

  FX_LONG_DESCRIPTOR: 'FX_longDescriptor',
  // fx ends

  ALTERNATIVE_PRODUCT_TYPE_CODE: 'ALT',

  EQUITY_WPC_PRODUCT_TYPE_CODE: 'SEC',

  COMMODITIES_WPC_PRODUCT_TYPE_CODE: 'COMM',

  /** Tenor **/
  /** The Constant TENOR_DATE. */
  TENOR_DAY: 'D',

  /** The Constant TENOR_MONTH. */
  TENOR_MONTH: 'M',

  /** The Constant TENOR_YEAR. */
  TENOR_YEAR: 'Y',

  /** The Constant TENOR_WEEK. */
  TENOR_WEEK: 'W',

  /** Filter subtitle **/

  ACCOUNT_FILTER_SUBTITLE: 'L_account_filter_subtitle',

  ACCOUNT_FILTER_LONG_SUBTITLE: 'L_account_filter_long_subtitle',

  CUSTOM_DATE_SUBTITLE: 'L_custome_date_filter_subtitle',

  ALL_PRODUCTS_SUBTITLE: 'L_all_products_selected',

  LABEL_PREFIX: 'L_',

  /** The wiring params. */

  ORDER_ACCOUNT_NUMBER: 'ORDER_ACCOUNT_NUMBER',

  ORDER_FUND_COUNTRY_PRODUCT_TRADABLE_CODE: 'ORDER_FUND_COUNTRY_PRODUCT_TRADABLE_CODE',

  ORDER_REFERENCE_NUMBER: 'ORDER_REF_NUM',

  ORDER_REFERENCE_TYPE: 'ORDER_REF_TYPE',

  ORDER_PROCESS_DATE: 'ORDER_PROCESS_DATE',

  ORDER_TXN_REFERENCE_ID: 'ORDER_TXN_REF_ID',

  ORDER_TRADE_DATE: 'ORDER_TRADE_DATE',

  STORY_ID: 'STORY_ID',

  NO_RECORDS_FOUND_LABEL: 'L_no_records_found',

  NO_INVESTMENT_ACCOUNT_LABEL: 'L_no_investment_account',

  NO_ACCOUNT_LIST_ERROR_MESS: 'NO_ACCOUNT_LIST_ERROR_KEY',

  NO_ACCOUNT_LIST_DEFAULT_ERROR_MESS: 'NO_ACCOUNT_LIST_DEFAULT_ERROR_MSG',

  /** Account List filter value **/
  ALL_INVESTMENT: 'ALL_INVESTMENT',

  ALL_SETTLEMENT: 'ALL_SETTLEMENT',

  /** list of segments to set for order status */
  ORDER_STATUS_SEGMENT_FILTERS: 'HLDORDRINF',

  /** Step id **/
  STEP_ID: 'stepId',

  /** Menu ation type */
  MENU_ACTION_ORDER_CANCEL: 'ORDCANC',

  MENU_ACTION_ORDER_DETAILS: 'ORDERDETAILS',

  MENU_ACTION_ORDER_MODIFY: 'MODIFY',

  ENABLE_CASH_ACCOUNTS_FLAG: 'ENABLE_CASH_ACCOUNTS',

  ENABLE_CASH_ACCOUNTS_FLAG_PASTHOLDING: 'ENABLE_CASH_ACCOUNTS_PASTHOLDING',

  ALL_CASH_ACCOUNT_SELECTION: 'ALL_INV_ACC',

  ALL_INVESTMENT_ACCOUNT_SELECTION: 'ALL_CASH_ACC',

  SUS: 'SUS',

  //
  ACS: 'ACS',

  TENURE_UNIT_SUFFIX: '_tenor_unit',

  MSG_CODE_NO_PORTFOLIO_DATA_INV: 'NO_PORTFOLIO_DATA_INV',
  MSG_CODE_NO_PORTFOLIO_DATA_SET: 'NO_PORTFOLIO_DATA_SET',

  SORT_FIELD_SUFFIX: '_SORT_FIELD',

  SORT_ORDER_SUFFIX: '_SORT_ORDER',

  WARNING_REASON_CODES: 'WARNING_REASON_CODES',

  DEFAULT_SELECTED_CURRENCY: 'denominatedCurrency',
  DEFAULT_SELECTED_SETTLE_CURRENCY: 'settledCurrency',

  DEFAULT_SELECTED_CURRENCY_PASHHOLDINGS: 'DEFAULT_CURRENCY_TOGGLE_PASHHOLDINGS',

  DEFAULT_SHOWING_VIEW: 'listView',

  DEFAULT_SELECTION_OF_ORDER_STATUS: 'DEFAULT_SELECTION_OF_ORDER_STATUS',

  INV_SUB_GROUP: 'INV_SUB_GROUP',

  CASH_SUB_GROUP: 'CASH_SUB_GROUP',

  DECIMAL_PALCE_OF_PIE_CHART_PERCENT: 'percent_decimal_place',

  DEFAULT_CURRENCY_TOGGLE: 'DEFAULT_CURRENCY_TOGGLE',

  CHECK_RBP_ACCOUNT_SUFFIX: '_CHECK_RBP_ACCOUNT',

  CHECK_RBP_ACCOUNT: 'CHECK_RBP_ACCOUNT',

  NO_TRANSACTION_PRODUCT_TYPES: 'NO_TRANSACTION_PRODUCT_TYPES',

  EBABLE_GAIN_LOSS_CHART: 'EBABLE_GAIN_LOSS_CHART',

  MAX_CHART_DATE_RANGE: 'MAX_CHART_DATE_RANGE',

  OPERATION_ADD: '+',
  OPERATION_SUBSTRACT: '-',
  // Order type key list
  SUPPORTED_ORDER_TYPE_LIST: 'SUPPORTED_ORDER_TYPE_LIST',
  MARKET_ORDER_TYPE: 'MARKET',
  LIMIT_Or_AUCTION_ORDER_TYPE: 'LIMIT_OR_AUCTION',
  STOP_LOSS_ORDER_TYPE: 'STOP_LOSS',
  TWO_WAY_LIMIT_ORDER_TYPE: 'TWO_WAY_LIMIT',
  TARGET_BUY_SELL_ORDER_TYPE: 'TARGET_BUY_SELL',
  ORDER_UNIT_ONLY_ORDER_TYPE: 'ORDER_UNIT_ONLY',
  ORDER_AMOUNT_ONLY_ORDER_TYPE: 'ORDER_AMOUNT_ONLY',
  LABEL_MARKET_PRICE: 'L_market_price',

  // amount convertor
  AMOUNT_CONVERTOR_PARAM_DISPALY_FORMAT: 'DisplayFormatResolve',
  AMOUNT_CONVERTOR_PARAM_CURRENCY_CODE: 'CurrencyCode',
  AMOUNT_CONVERTOR_PRRAM_SIGN_PREFIX: 'SignPrefix',
  AMOUNT_CONVERTOR_PARAM_SIGN_SUFFIX: 'SignSuffix',
  AMOUNT_CONVERTOR_PARAM_SHOW_CURRENCY: 'ShowCurrency',
  AMOUNT_CONVERTOR_PARAM_DEFAULT_DISPLAY_AS_STRING: 'DefaultDisplayAsString',
  AMOUNT_CONVERTOR_PARAM_CONVERTER_ID: 'converterId',
  CONVERTOR_PARAM_NUMBER_NULL_DISPLAY: 'NullDisplay',
  CONVERTOR_PARAM_NULL_DISPLAY: 'NullDisplayResolve',
  NUMBER_CONVERTER_PARAM_PATTERN: 'Pattern',
  NUMBER_CONVERTER_PATTERN: 'UNIT_FORMAT_PATTERNKEY',

  LABEL_NULL_DISPLAY: 'L_null_display',

  OTHERS_PRODUCT_TYPE_CODE: 'OTHERS',

  OTHERS_FUND_PRODUCT_TYPE_CODE: 'UT',

  OTHERS_BOND_PRODUCT_TYPE_CODE: 'BOND',

  OTHERS_EQUITY_PRODUCT_TYPE_CODE: 'SEC',

  OTHERS_OTHERS_PRODUCT_TYPE_CODE: 'OTHERS',

  OTHER_LIAB_PRODUCT_TYPE_CODE: 'OTHER_LIAB',

  SELECTED_CURRENCY: 'SELECTED_CURRENCY',

  ALLOW_EDIT_BOOK_COST: 'Allow_Edit_Book_Cost',

  SUS_VAL_SUS: 'SUS',

  SUS_VAL_ADS: 'ADS',

  SUS_VAL_AMD: 'AMD',

  NO_BOOK_COST_LIST_KEY: 'No_Edit_Book_Cost_List',

  TR_CODE_RETRIEVAL: 'T',

  TR_CODE_DISPLAY: 'M',

  FCY_GOLD_CCY: 'GLD',

  CCY_EUR: 'EUR',

  TR_STORY_ID: 'STORY_ID',

  TARGET_PREFIX: 'TARGET_PREFIX',
  NEWS_DETAILS: 'NEWS_DETAILS',

  DEFAULT_TR_QUERY: 'defaultTRQuery',

  BLANK_TR_QUERY: 'BLK_QUERY',

  NEWS_INSIGHT: 'NEWS_INSIGHT',

  PRODUCT_VIEW: 'PRODUCT_VIEW',

  ASSET_ALLOCATION: 'ASSET_ALLOCATION',

  REGIONS: 'REGIONS',

  SECTORS: 'SECTORS',

  REALISED_GL: 'REALISED_GL',

  WATCH_LIST: 'WATCH_LIST',

  ORDER_STATUS: 'ORDER_STATUS',

  PERFORMANCE_CHART: 'PERFORMANCE_CHART',

  EVENT_NEWS_DETAILS: 'news_details',

  EVENT_NEWS_INSIGHT: 'news_insight',

  /** Left bracket. */
  LEFT_BRACKET: '(',

  /** Right bracket. */
  RIGHT_BRACKET: ')',

  LOGIC_AND: ' AND ',

  /** Token connector. */
  WD_TOKEN_CONNECTOR: '~~',

  /** Key store file. */
  WD_TOKEN_KEY_STORE_FILE: 'WD_TOKEN_KEY_STORE_FILE',

  /** Key store password file. */
  WD_TOKEN_KEY_STORE_PWD_FILE: 'WD_TOKEN_KEY_STORE_PWD_FILE',

  /** Key store ivParam. */
  WD_TOKEN_IVPARAM_FILE: 'WD_TOKEN_IVPARAM_FILE',

  WD_TOKEN_IVPARAM: 'token_ivParam',

  /** Token time stamp format. */
  WD_TOKEN_TIMESTAMP_FORMAT: 'YYYYMMDDHHmmss',

  /** Mkd dateText time zone */
  WD_DATA_TEXT_TIMEZONE: 'GMT',

  /** The underscore */
  UNDERSORE_SIGN: '_',

  /** EQ */
  EQ_SING: 'EQ',

  /** Predictive Search call back */
  PREDICTIVE_SEARCH_CALL_BACK: 'predictiveSearch',

  /** Predictive Search url */
  PREDICTIVE_SEARCH_URL: 'MKD_URL',

  /** Predictive search request searchFields key */
  KEY_SEARCH_FIELDS: 'SEARCH_FIELDS',

  /** Predictive search request sortingFields key */
  KEY_SORTING_FIELDS: 'SORTING_FIELDS',

  /** Predictive search request topNum key */
  KEY_TOP_NUMBER: 'TOP_NUMBER',

  /** Predictive search request top key */
  KEY_DOUBLE_SUBMIT_FLAG: 'DOUBLE_SUBMIT_FLAG',

  /** BASE Application Code key */
  BASE_APPLICATION_CODE: 'APPLICATION_CODE',

  /** BASE_TOKEN_KEY_STORE_FILE */
  BASE_TOKEN_KEY_STORE_FILE: 'TOKEN_KEY_STORE_FILE',

  /** BASE_TOKEN_IVPARAM_FILE */
  BASE_TOKEN_IVPARAM_FILE: 'TOKEN_IVPARAM_FILE',

  /** BASE_TOKEN_KEY_STORE_PWD_FILE */
  BASE_TOKEN_KEY_STORE_PWD_FILE: 'TOKEN_KEY_STORE_PWD_FILE',

  /** FX RATE Application Code key */
  PRED_SEAR: 'PRED_SEAR',

  /** FX RATE Application Code key */
  FX_RATE: 'FX_RATE',

  /** TOP_10 Application Code key */
  TOP_10: 'TOP_10',

  /** TR_TOKEN CODE KEY. */
  TR_TOKEN: 'TR_TOKEN',

  PREDICTIVE_SEACH_TOKEN_VALUE_ID: 'PREDICTIVE_SEACH_TOKEN_VALUE_ID',

  FX_RATE_TOKEN_VALUE_ID: 'FX_RATE_TOKEN_VALUE_ID',

  TOP_10_TOKEN_VALUE_ID: 'TOP_10_TOKEN_VALUE_ID',

  /** customerSegment in global state. */
  GS_CUSTOMER_SEGMENT: 'customerSegment',

  /** CONTENT TYPE TEXT */
  CONTENT_TYPE_TEXT: 'text/plain',

  /** The Constant CONTENT_TYPE_JSON_UTF8. */
  CONTENT_TYPE_JSON_UTF8: 'application/json; charset=utf-8',

  /** YES FLAG */
  YES_FLAG: 'Y',

  /** The Constant PARAM_WIRE_COMPARE_TR_SUBJECT. */
  PARAM_WIRE_COMPARE_TR_SUBJECT: 'TR_SUBJECT', // trSubject

  /** The Constant PARAM_WIRE_COMPARE_HSBC_SUBJECT. */
  PARAM_WIRE_COMPARE_HSBC_SUBJECT: 'HSBC_SUBJECT', // hsbcSubject

  PARAM_WIRE_COMPARE_COUNTRY_PRODUCT_TRADABLECODE: 'COUNTRY_PRODUCT_TRADABLECODE',

  /** The Constant PARAM_WIRE_COMPARE_SHORT_DES. */
  PARAM_WIRE_COMPARE_SHORT_DES: 'SHORT_DESCRIPTOR', // shortDescriptor

  /** The Constant PARAM_WIRE_COMPARE_LOGN_DES. */
  PARAM_WIRE_COMPARE_LOGN_DES: 'LONG_DESCRIPTOR', // longDescriptor
  PASSED_PARAM_TR_SUBJECT: 'trSubject',

  COMMA_SEPARATED_COLORKEY_PRODUCTS: 'COMMA_SEPARATED_COLORKEY_PRODUCTS',

  PRODUCT_KEY_LIST: 'PRODUCT_KEY_LIST',

  WPC_ATTRIBUTE_LIST: 'WPC_ATTRIBUTE_LIST',

  /** The Constant PARAM_WIRE_COMPARE_TR_TEMP. */
  PARAM_WIRE_COMPARE_TR_TEMP: 'TR_TEMPLATE', // trTemplate

  /** The Constant PARAM_WIRE_COMPARE_LOGN_DES. */
  PARAM_WIRE_COMPARE_PRODUCT_TYPE: 'PRODUCT_TYPE', // feProductType
  WPC_PRODUCT_SUBTYPE_CODE_ATTRKEY: 'prodSubtpCde',

  /** The ctryProdTrade1Cde. */
  WPC_CTRYPRODTRADE1CDE_ATTRKEY: 'ctryProdTrade1Cde',

  WPC_PRODUCT_MARKET_CODE_ATTRKEY: 'mktInvstCde',
  Asset_Volatility_Class_Code: 'asetVoltlClass_Cde',

  WPC_PRODUCT_NAME_ATTRKEY: 'prodName',

  WPC_PRODUCT_SHORTNAME_ATTRKEY: 'prodShrtName',

  WPC_PRODUCT_ALLOWBUY_ATTRKEY: 'allowBuyProdInd',

  /** The WPC prodStatCde. */
  WPC_PRODUCT_STATUS_CODE: 'prodStatCde',

  /** The WPC product status "T"erminated. */
  WPC_PRODUCT_STATUS_TERMINATED: 'T',

  /** The WPC product status "D"elisted. */
  WPC_PRODUCT_STATUS_DELISTED: 'D',

  /** The WPC product status "E"xpired. */
  WPC_PRODUCT_STATUS_EXPIRED: 'E',

  PRODUCTTYPECODE: 'productTypeCode',
  PRODUCTCODE: 'productCode',
  TABADDWATCHLISTINDICATOR: 'tabAddWatchListIndicator',
  CURRENCYFROMCODE: 'currencyFromCode',
  CURRENCYTOCODE: 'currencyToCode',

  QUICKQUOTE_FX_FROM: 'quickQuote_fx_from',
  QUICKQUOTE_FX_TO: 'quickQuote_fx_to',

  ENTITY_MarketCriteria_groupMemberRecordCode: 'ENTITY_MarketCriteria_groupMemberRecordCode',
  VALUE_MarketCriteria_groupMemberRecordCode: 'VALUE_MarketCriteria_groupMemberRecordCode',

  /** The Constant DEFAULT_HSBC_SUBJECT. */
  DEFAULT_HSBC_SUBJECT: '>',

  /** The Constant DEFAULT_TR_SUBJECT. */
  DEFAULT_TR_SUBJECT: 'x',

  /** The Constant HSBC_SUBJECT_KEY. */
  HSBC_SUBJECT_KEY: 'To_Performance_hsbcsubject',

  /** The Constant TR_SUBJECT_KEY. */
  TR_SUBJECT_KEY: 'To_Performance_trsubject',

  /** The Constant TEMPLATE_KEY. */
  TEMPLATE_KEY: 'To_Performance_template',

  /** The Constant SHORT_DESC_KEY. */
  SHORT_DESC_KEY: 'To_Performance_shortDesc_Fx',

  /** The Constant LONG_DESC_KEY. */
  LONG_DESC_KEY: 'To_Performance_longDesc_Fx',

  /** The Constant DEFAULT_DESC. */
  DEFAULT_DESC: 'DEFALT DESCRIPTION FOR FX',

  /** The Constant LOCAL_CCY_KEY. */
  LOCAL_CCY_KEY: 'LOCAL_CCY_CODE',

  /** WPC valid result code */
  VALID_RESULT_CODE: '000',

  /** The Constant WPC_CODE. */
  WPC_CODE: 'W',

  /** The Constant ISIN CODE. */
  ISIN_CODE: 'I',

  /** The Constant FX_PAIR_PRO_TYPE. */
  FX_PAIR_PRO_TYPE: 'FXPAIR',

  /** The Constant R_CODE R. */
  R_CODE: 'R',
  /** The Constant T_CODE T. */
  T_CODE: 'T',

  MAINTIAN_OTHER_ASSET_UNAVAILABLE_DEFAULT_MESS: 'Maintain other asset is temporarily unavailable.',

  MAINTIAN_OTHER_ASSET_UNAVAILABLE: 'MAINTIAN_OTHER_ASSET_UNAVAILABLE',

  NO_VALUE_INPUT_PRODUCT_CODE_DEFAULT_MESS:
    'Input area is empty, please enter the product name or product code.',

  NO_VALUE_INPUT_PRODUCT_CODE: 'NO_VALUE_INPUT_PRODUCT_CODE',

  NO_VALUE_INPUT_NUMBER_OF_UNIT_DEFAULT_MESS:
    'Input area is empty, please enter the number of units.',

  NO_VALUE_INPUT_NUMBER_OF_UNIT: 'NO_VALUE_INPUT_NUMBER_OF_UNIT',

  INVALID_NUMBER_VALUE_DEFAULT_MESS:
    'Please enter a valid value with correct decimal points for the number of unit.',

  INVALID_NUMBER_VALUE: 'INVALID_NUMBER_VALUE',

  INVALID_NUMBER_DECIMAL_VALUE: 'INVALID_NUMBER_DECIMAL_VALUE',

  NO_VALUE_INPUT_BOOK_COST_DEFAULT_MESS:
    'Input area of the denominated currency book cost is empty, please enter a currency amount.',

  NO_VALUE_INPUT_AMOUNT_VALUE: 'NO_VALUE_INPUT_AMOUNT_VALUE',

  INVALID_BOOK_COST_AMOUNT_VALUE_DEFAULT_MESS:
    'Please enter a valid value with correct decimal points for this currency.',

  INVALID_AMOUNT_VALUE_NUMBER: 'INVALID_AMOUNT_VALUE_NUMBER',

  NO_VALUE_INPUT_BOOK_COST_LOCAL_DEFAULT_MESS:
    'Input area of the local currency book cost is empty, please enter a currency amount.',

  INVALID_BOOK_COST_LOCAL_AMOUNT_VALUE_DEFAULT_MESS:
    'Please enter a valid value with correct decimal points for this currency.',

  NO_VALUE_ASSET_PRODUCT_NAME_DEFAULT_MESS: 'Please enter an Asset identifier.',

  NO_VALUE_ASSET_PRODUCT_NAME: 'NO_VALUE_ASSET_PRODUCT_NAME',

  INVALID_ASSET_PRODUCT_NAME: 'INVALID_ASSET_PRODUCT_NAME',

  INVALID_ASSET_PRODUCT_NAME_DEFAULT_MESS:
    'Please enter a valid Asset identifier (alphabetics and numerics only).',

  NO_VALUE_INPUT_MARKET_VALUE_DEFAULT_MESS:
    'Input area of the market value is empty, please enter a currency amount.',

  INVALID_MARKET_VALUE_DEFAULT_MESS:
    'Please enter a valid value with correct decimal points for this currency for market value.',

  PRODUCT_NAME_VALIDATION_PATTERN: 'PRODUCT_NAME_VALIDATION_PATTERN',

  /** The Constant CIPHER_MD5. */
  CIPHER_SHA2: 'SHA-256',

  /** The Constant STATUS_CURRENT_IND. */
  STATUS_CURRENT_IND: 'STATUS_CURRENT_IND',

  // below constants are added by wealth 2.
  CACHE_FLAG_GOAL_SUMMARY: 'CACHE_FLAG_GOAL_SUMMARY',
  CACHE_FLAG_Y: 'Y',
  CACHE_FLAG_N: 'N',

  FLOW_ID: 'flowId',

  /** wire value to indicate goal holding was the origin page. */
  GOAL_HOLDINGS: 'goalholdings',
  PASSED_PARAM_SELECTED_CURRENCY_GOALHOLDING: 'selectedCurrencyGoalHolding',
  PASSED_PARAM_OPENED_PRODUCT_TYPE_GOALHOLDING: 'openedProductTypeGoalHolding',
  PASSED_PARAM_SHOWING_VIEW_GOALHOLDING: 'showingViewGoalHolding',
  PASSED_PARAM_OPENED_FLAG_GOAL_HOLDING: 'openedFlagGoalHolding',
  /**
   * product descriptor for insurance products.
   */
  PRODUCT_DESCRIPTOR_INSURANCE: 'INSURANCE',
  /**
   * product descriptor for investment products.
   */
  PRODUCT_DESCRIPTOR_INV: 'INV',
  /**
   * product descriptor for cash deposit products.
   */
  PRODUCT_DESCRIPTOR_CASH_DEPOSIT: 'CASH_DEPOSIT',

  // plan id.
  REQ_PAR_PLAN_ID: 'REQ_PAR_PLAN_ID',
  // goal id.
  REQ_PAR_GOAL_ID: 'REQ_PAR_GOAL_ID',
  // goal index.
  REQ_PAR_INDEX_ID: 'REQ_PAR_INDEX_ID',
  // goal id.
  REQ_PAR_PROJECTION_ENABLE_FLAG: 'REQ_PAR_PROJECTION_ENABLE_FLAG',

  RETRIEVE_GOAL_SUMMARY_RESPONSE: 'RETRIEVE_GOAL_SUMMARY_RESPONSE',

  /** The Constant SIGN_PERCENTAGE. */
  SIGN_PERCENTAGE: '%',

  /** Lead Id */
  LEAD_ID: 'LEAD_ID',

  /** Channel App Id */
  CHANNEL_APP_ID: 'APP_ID',

  /** Channel App Id for SFP */
  CHANNEL_APP_ID_SFP: 'SFP',

  /** Channel App Id for RMP */
  CHANNEL_APP_ID_RMP: 'RMP',

  /**
   * product dashbosrd type and sub type code key, map formatting for price
   * pattern
   */
  PRICE_DASHBOARDTYPE_SUBTYPE_CODE_KEY: 'PRICE_DASHBOARDTYPE_SUBTYPE',

  /**
   * product dashbosrd type and sub type code key, map formatting for NO. of
   * unit pattern
   */
  NUMOFUNIT_DASHBOARDTYPE_SUBTYPE_CODE_KEY: 'NUMOFUNIT_DASHBOARDTYPE_SUBTYPE',

  /** display amount or nominal based on currency, default key */
  DEFAULT_CURRENCY_DISPLAY: 'DEFAULT_CCY',

  /** target screen id key */
  TARGET_SCREEN_ID: 'target_screen_id',

  /** target screen id key */
  WIRE_FROM: 'wireFrom',

  /**
   * Supported_RealTime_Quote_FE_Product_Types define in
   * content/group/wealthdashboard/common/wealthdashboard-config.properties
   */
  SUPPORTED_REALTIME_QUOTE_FE_PRODUCT_TYPES: 'Supported_RealTime_Quote_FE_Product_Types',

  /** Indicator for whether to show real-time refresh button in drawer. */
  SHOW_DRAWER_REALTIME_REFRESH_BUTTON: 'showDrawerRealtimeRefreshButton',

  /** The Constant PRICE_QUOTE_TYPE_CODE_DL. */
  PRICE_QUOTE_TYPE_CODE_DL: 'Delay',

  /** The Constant PRICE_QUOTE_TYPE_CODE_RT. */
  PRICE_QUOTE_TYPE_CODE_RT: 'RealTime',

  /** unsignedAgreementId in request scope. */
  UNSIGNED_AGREEMENT_ID: 'unsignedAgreementId',

  /** FE's ProductType Equity, internal use in FrontEnd. */
  FE_PRODUCTTYPE_EQUITY: 'SEC',
  /** FE's ProductType fund, internal use in FrontEnd. */
  FE_PRODUCTTYPE_FUND: 'UT',
  /** FE's ProductType bond, internal use in FrontEnd. */
  FE_PRODUCTTYPE_BOND: 'BOND',
  /** FE's ProductType ALTERNATIVE, internal use in FrontEnd. */
  FE_PRODUCTTYPE_ALTERNATIVE: 'ALT',
  /** FE's ProductType COMMODITIES, internal use in FrontEnd. */
  FE_PRODUCTTYPE_COMMODITIES: 'COMMODITIES',
  /** FE's ProductType FXPAIR, internal use in FrontEnd. */
  FE_PRODUCTTYPE_FXPAIR: 'FXPAIR',
  /** FE's ProductType INDEX, internal use in FrontEnd. */
  FE_PRODUCTTYPE_INDEX: 'INDEX',
  /** The suffix for price display in amount */
  PRICE_DISPLAY_NORMAL_FORMAT: 'NORMAL_FORMAT',
  /** The suffix for price display in percentage */
  PRICE_DISPLAY_IN_PERCENTAGE: 'IN_PERCENTAGE',
  /** The suffix ifor 100 digdecimal */
  ONE_HUNDRED_DIGITAL: 100,
  /**
   * The suffix for the price of the holding which is not the mark to market.
   */
  NOT_MARK_TO_MARKET_PRICE_DISPLAY: 'NOT_MTM_PRICE_FORMAT',
  /** The suffix for the holding description. */
  HIDE_SHOW_HOLDING_DESC_SUFFIX: 'holding_desc_omitted',

  KEY_ACT_DROP_DOWN_LIST: 'ACT_DROP_DOWN_LIST',

  KEY_ACT_TYPE_DROP_DOWN_LIST: 'ACT_TYPE_DROP_DOWN_LIST',

  KEY_PROD_TYPE_DROP_DOWN_LIST: 'PROD_TYPE_DROP_DOWN_LIST',

  KEY_LIABILITY_DROP_DOWN_LIST: 'LIABILITY_DROP_DOWN_LIST',

  KEY_LIABILITY_SUB_DROP_DOWN_LIST: 'DEFAULT_LIABILITY_SUB_DROP_DOWN_LIST',

  KEY_RESIDENTIAL_DROP_DOWN_LIST: 'RESIDENTIAL_DROP_DOWN_LIST',

  KEY_SOLE_JOINT_DOWN_LIST: 'SOLE_JOINT_DOWN_LIST',

  KEY_PROTECTION_DROP_DOWN_LIST: 'PROTECTION_DROP_DOWN_LIST',

  OTHER_PRODUCT_TYPE_CODE_PREFIX: 'OTHER_',

  OTHER_SUB_DROP_DOWN_LIST_SUBFIX: '_SUB_DROP_DOWN_LIST',

  DASHBOARDTYPECODE_AND_DASHBOARDSUBTYPECODE_SEPARATOR: '|',

  OTHER_ASSETS_TYPE: 'OTHER_ASSETS_TYPE',

  HSBC_LIAB_SUBTYPE_PRIFIX: 'LIAB_SUBTYPE_',

  HSBC_LIAB_RESIDENTIAL_KEY: 'RESIDENTIAL',

  HSBC_LIAB_NON_RESIDENTIAL_KEY: 'NON_RESIDENTIAL',

  OTHER_ASSETS_FUNCTION_KEY: 'maintain_other_asset_function',

  /**
   * These constants are introduced in 'Update as common configuration for
   * INDEX, FX currency and Commodity'. begin
   */
  COMMODITY_LIST: 'COMMODITY_LIST',
  FX_CURRENCY_LIST: 'FX_CURRENCY_LIST',
  INDEX_LIST: 'INDEX_LIST',
  TRSUBJECT: '_trSubject',
  HSBCSUBJECT: '_hsbcSubject',
  COUNTRYTRADEABLECODE: '_countryTradeableCode',
  SHORTDESCRIPTION: '_shortDescription',
  LONGDESCRIPTION: '_longDescription',
  DESCRIPTION: '_description',
  MN_DESCRIPTION: '_MN_description',
  CURRENCY: '_CURRENCY',
  MN_DEFUALT_KEY_CURRENCIES: 'MN_DEFUALT_KEY_CURRENCIES',
  MN_DEFUALT_KEY_INDICES: 'MN_DEFUALT_KEY_INDICES',
  INDICES: '_INDICES',
  FLAG_CSS: 'FLAG_CSS_',
  /**
   * These constants are introduced in 'Update as common configuration for
   * INDEX, FX currency and Commodity'. end
   */

  // FunctionMessageTriggerDescription

  /** wiring to SRBP Date format. */
  WD_SRBP_DATE_FORMAT: 'YYYYMMDD',
  /** additionalHoldingKey for End of detention date. */
  DETENTION_END_DATE: 'DETENTION-END-DATE',
  /** additionalHoldingKey for Nantissement flag. */
  NANTISSEMENT_FLAG: 'NANTISSEMENT-FLAG',
  /** additionalHoldingKey for Number of units with Nantissement. */
  NUMBER_OF_UNITS_WITH_NANTISSEMENT: 'NUMBER-OF-UNITS-WITH-NANTISSEMENT',
  /** additionalHoldingKey for Multi-detention flag. */
  MULTI_DETENTION_FLAG: 'MULTI-DETENTION-FLAG',
  /** additionalHoldingKey for Kind of property owner. */
  ASSET_TEXT: 'ASSET-TEXT',

  /** The Constant COUNTRY_PROD_TRAD_CODE. */
  COUNTRY_PROD_TRAD_CODE: 'COUNTRY_PROD_TRAD_CODE',
  /**
   * key NOT_TRADABLE_PRODUCTS in
   * content/group/wealthdashboard/common/wealthdashboardConfig.properties
   */
  NOT_TRADABLE_PRODUCTS: 'NOT_TRADABLE_PRODUCTS',

  NOT_RELATED_NEWS_PRODUCTS: 'NOT_RELATED_NEWS_PRODUCTS',
  /** this key is used for JSP submit parameter and wiring parameter. */
  TRADABLE: 'tradable',
  /** this key is used for SFP->WD or WD->SFP parameter name for plan id. */
  PLAN_ID: 'PLAN_ID',
  /** this key is used for SFP->WD or WD->SFP parameter name for goal id. */
  GOAL_ID: 'GOAL_ID',

  JOINT_INDICATOR: 'JOINT',

  SOLE_INDICATOR: 'SOLE',

  ACCOUNT_PRODUCT_TYPE_CODE: 'ACCOUNT_PRODUCT_TYPE_CODE',

  CURRENCY_ACCOUNT_CODE: 'CURRENCY_ACCOUNT_CODE',

  GROUP_MEMBER_INVESTMENT_ACCOUNT: 'GROUP_MEMBER_INVESTMENT_ACCOUNT',

  COUNTRY_INVESTMENT_ACCOUNT_CODE: 'COUNTRY_INVESTMENT_ACCOUNT_CODE',

  ACCOUNT_TYPE_CODE: 'ACCOUNT_TYPE_CODE',

  SOURCE_TYPE: 'SOURCE_TYPE',

  ACCOUNT_SOURCE: 'account_source',

  SUPPORT_SUB_TAB: 'SUPPORT_SUB_TAB',

  SUPPORT_ACCOUNT_LIST: 'SUPPORT_ACCOUNT_LIST',

  SUB_TABS: 'SUB_TABS',

  DEFAULT_ACTIVE_TAB: 'DEFAULT_ACTIVE_TAB_NAME',

  CH_SUB_TAB_NAME: 'CH_SUB_TAB_NAME',

  ADVISED: 'ADVISED',

  DISCRETIONARY: 'DISCRETIONARY',

  ACCOUNT_PREFIX_INVALID: 'ACCOUNT_PREFIX_INVALID',

  /** additionalHoldingKey for Insurance Number for France local integration. */
  INSURANCE_NUMBER: 'INSURANCE-NUMBER',
  /** additionalHoldingKey for Contract Type (WPC product type code) for France local integration. */
  CONTRACT_TYPE: 'CONTRACT-TYPE',

  COUNTRYPRODUCTTRADABLECODE: '_COUNTRY_CODE',

  //AOC YTB
  BENEFICIARYNAMES: 'BeneficiaryName',
  NEXTPAYMENTDATE: 'NextPaymentDate',
  ANNUITYOPTIONS: 'AnnuityOptions',
  ANNUITYINCOMEAMOUNTCCYCODE: 'AnnuityIncomeAmountCcyCode',
  ANNUITYINCOMEAMOUNT: 'AnnuityIncomeAmount',
  PAYMENTTERM: 'PaymentTerm',
  PAYMENTTERMREMAINING: 'PaymentTermRemaining',
  INSURANCECOMPANYID: 'InsuranceCompanyId',
  ORDERTRADEDATE: 'orderTradeDate',
  ACCOUNTOPENDATE: 'accountOpenDate',
  ORDERTRADENUMBER: 'orderTradeNumber',

  //AOC EYI
  ORDERTRADEID: 'orderTradeId',
  DEBITACCOUNTNUMBER: 'debitAccountNumber',
  CREDITACCOUNTNUMBER: 'creditAccountNumber',
  CALLPUTREFERENCE: 'callPutReference',

  //AOC CPI
  PAYOFFTYPECDE: 'payoffTypeCde',
  PRODNAME: 'prodName',
  PRODUCTALTERNATIVENUMBER: 'productAlternativeNumber',
  SPTRDDT: 'spTrdDt',
  SPSTRKDT: 'spStrkDt',
  SPSTARTDT: 'spStartDt',
  PRODMTURDT: 'prodMturDt',
  PRDPRODNUM: 'prdProdNum',
  PRDPRODCDE: 'prdProdCde',
  UNDL_PRODALTPRIMNUM_P: 'undl_prodAltPrimNum_P',
  CCYPRODCDE: 'ccyProdCde',
  CPTLPROTCPCT: 'cptlProtcPct',
  SIDNAVPRICE: 'sidNavPrice',
  BARRIERPRCPCT: 'barrierPrcPct',
  PARTICIPATIONRATEPCT: 'participationRatePct',
  POTENTCOUPNPCT: 'potentCoupnPct',
  MINCOUPNPCT: 'minCoupnPct',
  KNOCKOUTPRCPCT: 'knockOutPrcPct',
  KNOCKINPRCPCT: 'knockInPrcPct',
  CAPLVLPCT: 'capLvlPct',
  FLOORLVLPCT: 'floorLvlPct',
  MAXACCRUPAYOUTPCT: 'maxAccruPayoutPct',
  RAINBOWWEIGHT: 'rainbowWeight',
  FINDOCURL: 'finDocURL_SID-DOC10',
  PORTFOLIOORDERREFERENCECODE: 'portfolioOrderReferenceCode',
  SETTLEMENTACCOUNT: 'settlementAccount',
  MASTERPORTFOLIOORDERREFERENCECODE: 'masterPortfolioOrderReferenceCode',
  CHILDPORTFOLIOORDERREFERENCECODE: 'childPortfolioOrderReferenceCode',
  ORDERCHANNEL: 'orderChannel',
  TARGETPRODUCT: 'targetProduct',
  MKTMOVEMENT: 'mktMovement',
};
