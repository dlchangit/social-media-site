//pollyfill
import 'intersection-observer';
import 'focus-visible';

import React from 'react';
import ReactDOM from 'react-dom';
import { HashRouter, Route, Switch } from 'react-router-dom';
import { Provider } from 'react-redux';
import reportWebVitals from './reportWebVitals';
import './i18n/config';

import './global.scss';
// import { store } from './store';
import store from './store';
import Drawer from './pages/drawer/Drawer';
import Dashboard from './pages/Dashboard/Dashboard';
import NoMatch from './pages/NoMatch/NoMatch';
import TransactionHistory from './pages/TransactionHistory/TransactionHistory';
import RealisedGainLoss from './pages/RealisedGainLoss/RealisedGainLoss';
import MyHoldings from './pages/MyHoldings/MyHoldings';
import * as am4core from '@amcharts/amcharts4/core';
import am4themes_animated from '@amcharts/amcharts4/themes/animated';

am4core.useTheme(am4themes_animated);

ReactDOM.render(
  <React.StrictMode>
    <Provider store={store}>
      <HashRouter>
        <div>
          <Drawer />
          <div className="main-container">
            <Switch>
              <Route exact path="/">
                <Dashboard />
              </Route>
              <Route path="/transaction-history">
                <TransactionHistory />
              </Route>
              <Route path="/realised-gain-loss">
                <RealisedGainLoss />
              </Route>
              <Route path="/my-holdings">
                <MyHoldings />
              </Route>
              <Route path="*">
                <NoMatch />
              </Route>
            </Switch>
          </div>
        </div>
      </HashRouter>
    </Provider>
  </React.StrictMode>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
