import { applyMiddleware, combineReducers, compose, createStore } from 'redux';
import createSagaMiddleware from 'redux-saga';

import transactionReducer from './pages/TransactionHistory/reducer';
import transactionSaga from './pages/TransactionHistory/saga';

import holdingReducer from './pages/MyHoldings/reducer';
import holdingSaga from './pages/MyHoldings/saga';

import realisedGainLossReducer from './pages/RealisedGainLoss/reducer';
import realisedGainLossSaga from './pages/RealisedGainLoss/saga';

import systemReducer from './pages/common/reducer';
import systemSaga from './pages/common/saga';
import { all, fork } from 'redux-saga/effects';

const rootReducer = combineReducers({
  system: systemReducer,
  holding: holdingReducer,
  transaction: transactionReducer,
  realisedGainLoss: realisedGainLossReducer,
});

const composeEnhancers = (window as any).__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
const sagaMiddleware = createSagaMiddleware();

const store = createStore(rootReducer, composeEnhancers(applyMiddleware(sagaMiddleware)));
sagaMiddleware.run(function* () {
  yield all([
    fork(systemSaga),
    fork(holdingSaga),
    fork(transactionSaga),
    fork(realisedGainLossSaga),
  ]);
});

export type RootState = ReturnType<typeof rootReducer>;
export default store;
