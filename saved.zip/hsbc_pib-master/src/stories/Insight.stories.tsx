import '../global.scss';

import React from 'react';
import { Meta, Story } from '@storybook/react/types-6-0';
import { ArticleHolding, GenericNews } from '../demo/InsightDemo';
import { InsightCard } from '../components';

export default {
  title: 'Insight',
  component: InsightCard,
  argTypes: { onClick: { action: 'clicked button' }, onApply: { action: '' } },
} as Meta;

export const UnitTrustOfferDemo: Story = (args) => <GenericNews {...args} />;
export const ArticleHoldingDemo: Story = (args) => <ArticleHolding {...args} />;
