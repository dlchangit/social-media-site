import '../global.scss';

import React, { useState } from 'react';
import { Meta, Story } from '@storybook/react/types-6-0';

import { Button, Checkbox, CheckboxV3Props } from '../components';
import styled from 'styled-components';

const Wrapper = styled.div`
  display: flex;
  flex-flow: column wrap;
  justify-content: flex-start;
  align-items: flex-start;
`;
export default {
  title: 'Checkbox',
  component: Checkbox,
  args: {
    style: { margin: '8px' },
  },
} as Meta;

const Template: Story<CheckboxV3Props> = (args) => (
  <Wrapper style={{ width: 200 }}>
    <Checkbox {...args} />
    <Checkbox {...args} />
    <Checkbox {...args} />
    <Checkbox {...args}>Option label over two or more lines</Checkbox>
    <Checkbox {...args} />
    <Checkbox {...args} />
    <Checkbox {...args} size={'large'} />
  </Wrapper>
);

export const SimpleCheckbox = Template.bind({});
SimpleCheckbox.args = {
  children: 'All',
};

export const DefaultChecked = Template.bind({});
DefaultChecked.args = {
  children: 'All',
  defaultChecked: true,
};

const Template2: Story<CheckboxV3Props> = (args) => {
  const [state, setState] = useState(false);
  const onClick = () => {
    setState((prevState) => !prevState);
  };

  return (
    <Wrapper style={{ width: 200 }}>
      <Checkbox {...args} checked={state} />
      <Checkbox
        {...args}
        checked={state}
        onChange={(event) =>
          setState((event as React.ChangeEvent<HTMLInputElement>).target.checked)
        }
      >
        data binding
      </Checkbox>
      <Checkbox {...args} checked={state} />
      <Checkbox {...args} checked={state}>
        Option label over two or more lines
      </Checkbox>
      <Checkbox {...args} checked={state} />
      <Checkbox {...args} checked={state} />
      <Checkbox {...args} checked={state} size={'large'} />
      <Button onClick={onClick}>toggle</Button>
    </Wrapper>
  );
};

export const DataBinding = Template2.bind({});
DataBinding.args = {
  children: 'All',
};
