import React from 'react';
import { Meta, Story } from '@storybook/react/types-6-0';
import * as am4core from '@amcharts/amcharts4/core';
import { DataItem } from '@amcharts/amcharts4/core';
import am4themes_animated from '@amcharts/amcharts4/themes/animated';
import {
  DateChart,
  DateChartProps,
  EmptyResult,
  LoadResult,
  Space,
  Typography,
} from '../components';
import faker from 'faker';
import { formatDigits } from '../utils/math';
import ReactDOMServer from 'react-dom/server';

am4core.useTheme(am4themes_animated);

const data = Array.from({ length: 12 }).map((_, i) => {
  const amount = faker.finance.amount(0, 20000, 5);
  return {
    date: new Date(2020, i, faker.random.number({ min: 1, max: 20 })),
    value: faker.random.boolean() ? amount : amount,
    tooltipFormatter(item: DataItem) {
      return ReactDOMServer.renderToString(
        <Space align={'start'}>
          <Typography weight={'light'} size={5}>
            Income:&nbsp;
          </Typography>
          <Typography size={5}>HKD {formatDigits(item.values.valueY.value)}</Typography>
        </Space>
      );
    },
  };
});

export default {
  title: 'DateChart',
  component: DateChart,
  argTypes: {
    size: {
      control: {
        type: 'range',
        min: 0,
        max: data.length,
        step: 1,
      },
      defaultValue: data.length,
    },
    loading: {
      control: {
        type: 'boolean',
      },
    },
  },
  args: {
    data,
  },
} as Meta;

const Template: Story<DateChartProps & { size: number; loading: boolean }> = ({
  size,
  loading,
  ...args
}) => (
  <DateChart
    {...args}
    data={args.data.slice(0, size)}
    style={{ minHeight: 400 }}
    {...(!loading && { loadingResult: undefined })}
  />
);

export const Demo = Template.bind({});

const resultStyle = { minWidth: 820, minHeight: 400 };

Demo.args = {
  id: 'bar-chart-0',
  valueTitle: 'HKD',
  loadingResult: <LoadResult style={resultStyle} label={'loading content'} border={true} />,
  emptyResult: (
    <EmptyResult
      style={resultStyle}
      label={'You do not have any investment products'}
      border={true}
    />
  ),
};
