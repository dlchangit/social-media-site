import React from 'react';
import { Meta, Story } from '@storybook/react/types-6-0';
import * as am4core from '@amcharts/amcharts4/core';
import { DataItem, Label } from '@amcharts/amcharts4/core';
import am4themes_animated from '@amcharts/amcharts4/themes/animated';
import {
  CategoryChartProps,
  CategoryData,
  createTooltipLabel,
  DonutChart,
  EmptyResult,
  LoadResult,
} from '../components';
import faker from 'faker';
import { formatDigits } from '../utils/math';
import { LegendDataItem } from '@amcharts/amcharts4/charts';

am4core.useTheme(am4themes_animated);

const data: CategoryData[] = [
  'Unit Trusts',
  'FlexInvest',
  'Stocks',
  'Capital Protected Investment',
  'Deposit Plus',
  'ELI & Structure Notes',
  'Cash',
  'Time Deposits',
  'Others',
].map((name) => {
  return {
    category: name,
    value: faker.finance.amount(1000, 10000, 2) as never,
    tooltipFormatter(item: DataItem) {
      const container = new am4core.Container();
      container.layout = 'vertical';
      container.horizontalCenter = 'middle';
      const label = createTooltipLabel();
      // label.text = '{category}' + ' ' + "({value.percent.formatNumber('#.0')}%)";
      const l = ((item as unknown) as {
        legendDataItem: LegendDataItem;
      }).legendDataItem;
      label.text = (l.sprites[2] as Label).currentText + ' ' + (l.sprites[3] as Label).currentText;
      label.parent = container;

      const label2 = createTooltipLabel({ bold: true });
      label2.text = 'HKD' + ' ' + formatDigits(item.values?.value?.value);
      label2.marginTop = 4;
      label2.parent = container;

      return container;
    },
  };
});

// data.push({
//   category: 'very little',
//   value: 300.0 as never,
// });

export default {
  title: 'DonutChart',
  component: DonutChart,
  argTypes: {
    size: {
      control: {
        type: 'range',
        min: 0,
        max: data.length,
        step: 1,
      },
      defaultValue: data.length,
    },
    loading: {
      control: {
        type: 'boolean',
      },
    },
  },
  args: {
    data,
  },
} as Meta;

const Template: Story<CategoryChartProps & { size: number; loading: boolean }> = ({
  size,
  loading,
  ...args
}) => (
  // <div style={{ backgroundColor: 'green', height: '1000px' }}>
  <div>
    <DonutChart
      {...args}
      data={args.data.slice(0, size)}
      // data={[]}
      // style={{ minWidth: 820, minHeight: 400 }}
      // style={{ backgroundColor: 'red', maxWidth: 740, minHeight: 400 }}
      style={{ maxWidth: 740, minHeight: 400 }}
      {...(!loading && { loadingResult: undefined })}
    />
  </div>
);

export const DonutChartDemo = Template.bind({});

const resultStyle = { minWidth: 820, minHeight: 400 };

DonutChartDemo.args = {
  id: 'chart-0',
  valueTitle: 'Product Type:',
  loadingResult: <LoadResult style={resultStyle} label={'loading content'} border={true} />,
  emptyResult: <EmptyResult label={'You do not have any investment products'} border={true} />,
};
