import React from 'react';
import { Meta, Story } from '@storybook/react/types-6-0';

import { Grid, Item, Row } from '../components';
export default {
  title: 'Grid',
  parameters: {
    layout: 'fullscreen',
  },
} as Meta;

const style = {
  border: '#333 1px solid',
  padding: 15,
  marginBottom: 10,
};

const Template: Story = () => (
  <Grid>
    <Row flush={true}>
      <Item lgSize={12}>
        <div style={style}>lg-12 flush</div>
      </Item>
    </Row>
    <Row flush={true}>
      <Item lgSize={6}>
        <div style={style}>lg-6 flush</div>
      </Item>
      <Item lgSize={6}>
        <div style={style}>lg-6 flush</div>
      </Item>
    </Row>
    <Row>
      <Item lgSize={6}>
        <div style={style}>lg-6</div>
      </Item>
      <Item lgSize={6}>
        <div style={style}>lg-6</div>
      </Item>
    </Row>
    <Row>
      <Item lgSize={3} mdSize={6} smSize={12} last={['sm']}>
        <div style={style}>lg-3 md-6 sm-12</div>
      </Item>
      <Item lgSize={5} mdSize={3} smSize={12} last={['sm']}>
        <div style={style}>lg-5 md-3 sm-12</div>
      </Item>
      <Item lgSize={4} mdSize={3} smSize={12} last={['sm']}>
        <div style={style}>lg-4 md-3 sm-12</div>
      </Item>
    </Row>
    <Row>
      <Item lgSize={3} mdSize={3} smSize={6}>
        <div style={style}>lg-3 md-3 sm-6</div>
      </Item>
      <Item lgSize={9} mdSize={9} smSize={6} last={['lg', 'md', 'sm']}>
        <div style={style}>lg-9 md-9 sm-6</div>
      </Item>
      <Item lgSize={6} lgOffset={1}>
        <div style={style}>lg-6 offset-1</div>
      </Item>
      <Item lgSize={4} lgOffset={1}>
        <div style={style}>lg-4 offset-1</div>
      </Item>
    </Row>
  </Grid>
);
export const Demo = Template.bind({});
