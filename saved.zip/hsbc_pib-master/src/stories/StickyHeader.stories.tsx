import '../global.scss';

import React from 'react';
import { Meta, Story } from '@storybook/react/types-6-0';
import { StickyHeader, StickyHeaderProp } from '../components';

export default {
  title: 'StickyHeader',
  component: StickyHeader,
  parameters: {
    layout: 'fullscreen',
  },
} as Meta;

const Template: Story<StickyHeaderProp> = (args) => (
  <div>
    <StickyHeader {...args} />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
  </div>
);

export const Demo = Template.bind({});
Demo.args = {};
