import '../global.scss';

import React from 'react';
import { Meta, Story } from '@storybook/react/types-6-0';
import { Accordion, AccordionProps, Panel } from '../components';

export default {
  title: 'Accordion',
  component: Accordion,
  argTypes: {
    args: {
      activeKey: '1',
    },
  },
} as Meta;

const Template: Story<AccordionProps> = (args) => (
  <Accordion {...args} style={{ padding: '0 24px' }} />
);

export const WithoutKey = Template.bind({});
WithoutKey.args = {
  children: (
    <>
      <Panel header={'i am header'}>
        <h1>hello</h1>
      </Panel>
      <Panel header={'i am disabled'} disabled>
        <div style={{ backgroundColor: 'red', height: 300 }}>red</div>
      </Panel>
      <Panel header={'i am header 2'}>
        <div style={{ backgroundColor: 'green', height: 300 }}>green</div>
      </Panel>
    </>
  ),
};

export const WithKey = Template.bind({});
WithKey.argTypes = {
  activeKey: {
    control: {
      type: 'range',
      min: 0,
      max: 3,
      step: 1,
    },
    defaultValue: 1,
  },
};
WithKey.args = {
  children: (
    <>
      <Panel header={'i am header'} panelKey={0}>
        <h1>hello</h1>
      </Panel>
      <Panel header={'i am disabled'} disabled panelKey={1}>
        <div style={{ backgroundColor: 'red', height: 300 }}>red</div>
      </Panel>
      <Panel header={'i am header 2'} panelKey={2}>
        <div style={{ backgroundColor: 'green', height: 300 }}>green</div>
      </Panel>
    </>
  ),
};
export const WithStringKey = Template.bind({});
WithStringKey.argTypes = {
  activeKey: {
    control: {
      type: 'inline-radio',
      options: ['a', 'b', 'c', undefined],
    },
    defaultValue: undefined,
  },
};
WithStringKey.args = {
  children: (
    <>
      <Panel header={'i am header'} panelKey={'a'}>
        <h1>hello</h1>
      </Panel>
      <Panel header={'i am disabled'} disabled panelKey={'b'}>
        <div style={{ backgroundColor: 'red', height: 300 }}>red</div>
      </Panel>
      <Panel header={'i am header 2'} panelKey={'c'}>
        <div style={{ backgroundColor: 'green', height: 300 }}>green</div>
      </Panel>
    </>
  ),
};
