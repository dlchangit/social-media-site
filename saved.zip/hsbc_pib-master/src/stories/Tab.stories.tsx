import '../global.scss';

import React from 'react';
import { Meta, Story } from '@storybook/react/types-6-0';
import { Tab, TabPane } from '../components';

export default {
  title: 'Tab',
  component: Tab,
} as Meta;

const Template: Story = () => (
  <Tab defaultKey={'a'}>
    <TabPane title={'Tab A'} key={'a'}>
      This this the content of tab A
    </TabPane>
    <TabPane title={'Tab B'} key={'b'}>
      This this the content of tab B
    </TabPane>
  </Tab>
);

export const DefaultKey = Template.bind({});
DefaultKey.args = {};
