import '../global.scss';

import React from 'react';
import { Meta, Story } from '@storybook/react/types-6-0';

import { HealthScoreCard, HealthScoreCardProps, ImageInvestment } from '../components';

export default {
  title: 'HealthScoreCards',
  component: HealthScoreCard,
} as Meta;
const Template: Story<HealthScoreCardProps> = (args) => <HealthScoreCard {...args} />;

export const AssetAllocation = Template.bind({});

AssetAllocation.args = {
  title: 'Asset Allocation',
  percent: '35',
  description: 'Your Concentration of Global Equities',
  img: <ImageInvestment alt={''} />,
};
