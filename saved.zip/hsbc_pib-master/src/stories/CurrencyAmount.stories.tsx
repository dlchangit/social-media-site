import '../global.scss';

import React from 'react';
import { Meta, Story } from '@storybook/react/types-6-0';

import { IconAnchor, CurrencyAmount, CurrencyAmountProps } from '../components';
import styled from 'styled-components';

const Wrapper = styled.div`
  display: flex;
  flex-flow: row nowrap;
  justify-content: flex-start;
  align-items: flex-start;

  > div:not(:first-child) {
    margin-left: 32px;
  }
`;

export default {
  title: 'CurrencyAmount',
  component: CurrencyAmount,
  argTypes: {
    amount: {
      control: {
        type: 'range',
        min: -1000000,
        step: 500000,
        max: 1000000,
      },
      defaultValue: 999001.0,
    },
    showSign: {
      control: {
        type: 'boolean',
      },
      defaultValue: true,
    },
  },
} as Meta;

const Template: Story<CurrencyAmountProps> = (args) => (
  <Wrapper>
    <CurrencyAmount {...args} amount={120000} showSign={false} />
    <CurrencyAmount {...args} label={'Total unrealised gain / loss'} />
    <CurrencyAmount {...args} label={'Dummy'} amount={'-'} percent={'-'} />
    <CurrencyAmount
      {...args}
      label={
        <IconAnchor href={'/?path=/story/currencyamount--currency-amount-demo'}>
          Dividend / cash income in past 12 moths
        </IconAnchor>
      }
      amount={120000}
      showSign={false}
    />
  </Wrapper>
);

export const CurrencyAmountDemo = Template.bind({});
CurrencyAmountDemo.args = {
  label: 'Total market value',
  currency: 'HKD',
};
