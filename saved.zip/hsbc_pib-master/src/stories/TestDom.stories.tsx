import '../global.scss';

import React, { ReactElement } from 'react';
import { Meta, Story } from '@storybook/react/types-6-0';
import { IconAnchorProps } from '../components';
import { toArray } from '../utils/dom';

type Nested = ReactElement | ReactElement[] | Array<Nested>;

interface MyComponentProps {
  children?: Nested | Array<Nested>;
}

const MyComponent: React.FC<MyComponentProps> = (props) => {
  const kids = toArray(props.children);

  return (
    <div className={'component-wrapper'}>
      {kids.map((it, index) => {
        return (
          <div style={{ margin: 20, background: '#eee' }} key={index}>
            {it}
          </div>
        );
      })}
    </div>
  );
};

export default {
  title: 'TestDom',
  component: MyComponent,
} as Meta;

const list = ['hello', 'world'];
const Template: Story<IconAnchorProps> = (args) => (
  <MyComponent {...args}>
    {list.map((it, index) => {
      return <span key={index}>{it}</span>;
    })}
    <>
      {list.map((it, index) => {
        return <span key={index}>{it}</span>;
      })}
      <a href="/">google.com</a>
    </>
    <a href={'/'}>extra outside fragment</a>
    <>
      <a href={'/'}>extra inside fragment</a>
    </>
    <div>
      <>
        <a href={'/'}>extra inside fragment inside div</a>
      </>
    </div>
    <>
      <>
        <a href="/">two layer fragment</a>
      </>
    </>
  </MyComponent>
);
export const ToArray = Template.bind({});
ToArray.args = {};
