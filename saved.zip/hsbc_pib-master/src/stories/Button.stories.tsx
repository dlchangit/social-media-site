import '../global.scss';

import React from 'react';
import { Meta, Story } from '@storybook/react/types-6-0';

import { IconRefresh, Button, ButtonProps } from '../components';

export default {
  title: 'Button',
  component: Button,
  argTypes: {
    type: {
      control: {
        type: 'inline-radio',
        options: ['default', 'text'],
      },
    },
    size: {
      control: {
        type: 'inline-radio',
        options: ['small', 'middle'],
      },
      defaultValue: 'middle',
    },
    onClick: { action: 'clicked button' },
  },
} as Meta;

const Template: Story<ButtonProps> = (args) => <Button {...args}>{args.children}</Button>;

export const Text = Template.bind({});
Text.args = {
  children: 'button',
};

export const IconText = Template.bind({});
IconText.args = {
  children: 'refresh',
  icon: <IconRefresh />,
};

export const Icon = Template.bind({});
Icon.args = {
  children: undefined,
  icon: <IconRefresh />,
};

export const Dom = Template.bind({});
Dom.args = {
  children: <div style={{ color: 'red', margin: 20 }}>hello</div>,
};
