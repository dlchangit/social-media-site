import '../global.scss';

import React from 'react';
import { Meta, Story } from '@storybook/react/types-6-0';
import styled from 'styled-components';
import { IconTooltip, ChevronAnchor, ChevronAnchorProps } from '../components';

const Wrapper = styled.div`
  width: 200px;
  display: flex;
  flex-flow: column wrap;
`;
const Row = styled.div`
  margin: 8px;
`;
export default {
  title: 'ChevronAnchor',
  component: ChevronAnchor,
  argTypes: {
    direction: {
      control: {
        type: 'inline-radio',
        options: ['forward', 'backward', undefined, false],
      },
    },
  },
} as Meta;

const Template: Story<ChevronAnchorProps> = (args) => (
  <Wrapper>
    <Row>
      <ChevronAnchor {...args} />
    </Row>
    <Row>
      <ChevronAnchor {...args}>
        <span style={{ background: 'gray' }}>{args.children as string}</span>
      </ChevronAnchor>
    </Row>
    <Row>
      <ChevronAnchor {...args}>
        {args.children as string}
        <IconTooltip style={{ display: 'inline', marginLeft: 4, marginRight: 6 }} />
      </ChevronAnchor>
    </Row>
    <Row>
      <ChevronAnchor {...args}>Example link over two lines or more</ChevronAnchor>
    </Row>
    <Row>
      <ChevronAnchor {...args}>
        <span>Example link over two lines or more</span>
        <IconTooltip style={{ display: 'inline', marginLeft: 4, marginRight: 6 }} />
      </ChevronAnchor>
    </Row>
  </Wrapper>
);

export const Chevron = Template.bind({});
Chevron.args = {
  children: 'View all',
  href: '/',
};

// export const IconText = Template.bind({});
// IconText.args = {
//   children: 'Analyze my profile',
//   href: '/?path=/story/anchor--text',
//   left: <IconChart />,
// };
