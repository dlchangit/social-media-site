import '../global.scss';

import React from 'react';
import { Meta, Story } from '@storybook/react/types-6-0';
import { Button, Typography, TypographyProps } from '../components';

export default {
  title: 'Typography',
  component: Typography,
  argTypes: {
    size: {
      control: {
        type: 'range',
        min: 1,
        max: 7,
        step: 1,
      },
      defaultValue: 5,
    },
  },
} as Meta;

const Template: Story<TypographyProps> = (args) => (
  <Typography {...args}>{args.children}</Typography>
);

export const PlainText = Template.bind({});
export const DivDom = Template.bind({});
export const Fragment = Template.bind({});

PlainText.args = {
  children: 'Together we thrive',
};

DivDom.args = {
  children: (
    <div className={'my-class'}>
      <a key={0} href={'/'}>
        I am anchor
      </a>
      I am div Text
      <Button key={1}>I am Hello</Button>
    </div>
  ),
};

Fragment.args = {
  children: (
    <>
      <a key={0} href={'/'} className={'my-class'}>
        I am anchor
      </a>
      I am div Text
      <Button key={1}>I am Hello</Button>
    </>
  ),
};

const TemplateList: Story<TypographyProps> = (args) => (
  <Typography {...args}>
    <a key={0} href={'/'} className={'my-class'}>
      I am anchor
    </a>
    <div>I am div Text</div>
    <Button key={1}>I am Hello</Button>
  </Typography>
);
export const ListDom = TemplateList.bind({});
