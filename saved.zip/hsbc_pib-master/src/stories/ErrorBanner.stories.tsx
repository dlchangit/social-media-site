import '../global.scss';

import React from 'react';
import { Meta, Story } from '@storybook/react/types-6-0';
import { ErrorBanner, ErrorBannerProps } from '../components';

export default {
  title: 'ErrorBanner',
  component: ErrorBanner,
} as Meta;

// noinspection RequiredAttributes
const Template: Story<ErrorBannerProps> = (args) => <ErrorBanner {...args} />;

export const Error = Template.bind({});

Error.args = {
  children: 'We are unable to display your content at this moment. Please try again later.',
};
