import '../global.scss';

import React from 'react';
import { Meta, Story } from '@storybook/react/types-6-0';
import { Tooltip, TooltipProp, IconSell, Space } from '../components';

export default {
  title: 'Tooltip',
  component: Tooltip,
  argTypes: {
    direction: {
      control: {
        type: 'select',
        options: [
          'top-left',
          'top-center',
          'top-right',
          'bottom-left',
          'bottom-center',
          'bottom-right',
        ],
      },
      defaultValue: 'top-center',
    },
  },
} as Meta;

const Template: Story<TooltipProp> = (args) => (
  <Space direction={'vertical'}>
    <div>
      <Tooltip {...args}>
        <div>top</div>
      </Tooltip>
    </div>
    <div style={{ marginTop: '50px', marginLeft: '10%' }}>
      <Tooltip {...args}>
        <div>Left</div>
      </Tooltip>
    </div>
    <div style={{ marginTop: '50px', marginLeft: 200 }}>
      <Tooltip {...args}>
        <div>center</div>
      </Tooltip>
    </div>
    <div style={{ marginTop: '50px', alignSelf: 'flex-end', marginRight: '5%' }}>
      <Tooltip {...args}>
        <div>Right</div>
      </Tooltip>
    </div>
    <div style={{ marginTop: '50px', alignSelf: 'flex-end', marginRight: '15%' }}>
      <Tooltip {...args}>
        <div>Right 2</div>
      </Tooltip>
    </div>
  </Space>
);

const Template2: Story<TooltipProp> = (args) => (
  <div style={{ display: 'flex', height: '100vh', alignItems: 'center', justifyContent: 'center' }}>
    <Tooltip {...args}>
      <IconSell />
    </Tooltip>
  </div>
);

export const Text = Template.bind({});
export const Icon = Template2.bind({});
Text.args = {
  message: "Top 3 gainers and losers' information are calculated from unrealised gain/loss",
};
Icon.args = {
  message: "Top 3 gainers and losers' information are calculated from unrealised gain/loss",
};
