import '../global.scss';

import React from 'react';
import { Meta, Story } from '@storybook/react/types-6-0';

import { Holding, HoldingProps, Divider, Space, EmptyResult } from '../components';

export default {
  title: 'Holding',
  component: Holding,
  argTypes: {
    percentage: {
      control: {
        type: 'range',
        min: -100,
        max: 100,
        step: 25.1,
      },
      defaultValue: 17.5,
    },
    size: {
      control: {
        type: 'range',
        min: 0,
        max: 3,
        step: 1,
      },
      defaultValue: 1,
    },
  },
} as Meta;

const generateChild = (args: HoldingProps, size: number): React.ReactElement[] => {
  return Array.from({ length: size }).map((_, i) => {
    return <Holding {...args} key={i} />;
  });
};

const Template: Story<HoldingProps & { size: number }> = (args) => (
  <Space>
    <Space
      direction={'vertical'}
      split={<Divider style={{ marginBottom: 12 }} />}
      style={{ width: 400, marginRight: 20 }}
    >
      <Holding {...args} percentage={75.0} />
      <Holding {...args} stock="General Electric Company" symbol="GE" />
      <Holding {...args} />
    </Space>
    <Space direction={'vertical'} split={<Divider />} style={{ width: 400 }}>
      {args.size > 0 ? (
        generateChild({ ...args, percentage: -15.0 }, args.size)
      ) : (
        <EmptyResult label={'No top losers at the moment.'} border={false} />
      )}
    </Space>
  </Space>
);

export const HoldingDemo = Template.bind({});
HoldingDemo.args = {
  stock: 'Apple Inc.',
  symbol: 'AAPL',
  currency: 'HKD',
  amount: 100000.0,
};
