import React from 'react';
import { Meta, Story } from '@storybook/react/types-6-0';
import * as am4core from '@amcharts/amcharts4/core';
import am4themes_animated from '@amcharts/amcharts4/themes/animated';
import { CategoryChartProps, EmptyResult, HorizontalBarChart, LoadResult } from '../components';
import faker from 'faker';

am4core.useTheme(am4themes_animated);

const data = [
  'Unit Trusts',
  'FlexInvest',
  'Stocks',
  'Capital Protected Investment',
  'Deposit Plus',
  'ELI & Structure Notes',
  'Cash',
  'Time Deposits',
  'Others',
].map((name) => {
  return {
    category: name,
    value: faker.finance.amount(100, 20000, 2),
  };
});

export default {
  title: 'HorizontalBarChart',
  component: HorizontalBarChart,
  argTypes: {
    size: {
      control: {
        type: 'range',
        min: 0,
        max: data.length,
        step: 1,
      },
      defaultValue: data.length,
    },
    loading: {
      control: {
        type: 'boolean',
      },
    },
  },
  args: {
    data,
  },
} as Meta;

const Template: Story<CategoryChartProps & { size: number; loading: boolean }> = ({
  size,
  loading,
  ...args
}) => (
  <HorizontalBarChart
    {...args}
    data={args.data.slice(0, size)}
    style={{ minWidth: 820 }}
    {...(!loading && { loadingResult: undefined })}
  />
);

export const HorizontalBarChartDemo = Template.bind({});

const resultStyle = { minWidth: 820, minHeight: 400 };
HorizontalBarChartDemo.args = {
  id: 'bar-chart-0',
  valueTitle: 'HKD',
  loadingResult: <LoadResult style={resultStyle} label={'loading content'} border={true} />,
  emptyResult: (
    <EmptyResult
      style={resultStyle}
      label={'You do not have any investment products'}
      border={true}
    />
  ),
};
