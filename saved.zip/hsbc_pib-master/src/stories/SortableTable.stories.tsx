import '../global.scss';

import React from 'react';
import { Meta, Story } from '@storybook/react/types-6-0';

import {
  Column,
  EmptyView,
  ErrorView,
  LoadingView,
  SortableTable,
  ContextMenu,
  CurrencyAmount,
  SortableTableProp,
} from '../components';
import { formatDigits } from '../utils/math';

export default {
  title: 'SortableTable',
  component: SortableTable,
} as Meta;

interface Transaction {
  name: string;
  fundContextualItem: string[];
  marketValueAmount: number;
  marketValueCurrency: string;
  unrealizedGainLossAmount: number;
  unrealizedGainLossCurrency: string;
  unrealizedGainLossPercent: number;
  investmentAmountAmount: number;
  investmentAmountCurrency: string;
  navAmount: number;
  navCurrency: string;
  unit: number;
}

const Template: Story<SortableTableProp<Transaction>> = (args) => (
  <SortableTable<Transaction> {...args} />
);

export const TransactionHistory = Template.bind({});
export const Error = Template.bind({});
export const Empty = Template.bind({});
export const Loading = Template.bind({});

const columns: Column<Transaction>[] = [
  {
    key: 'name',
    label: 'Fund',
    formatter(row: Transaction) {
      if (row.fundContextualItem.length > 0) {
        const items = row.fundContextualItem.map((it) => ({ label: it }));
        return (
          <div
            style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}
          >
            {row.name}
            <ContextMenu items={items} />
          </div>
        );
      } else {
        return row.name;
      }
    },
  },
  {
    key: 'marketValueAmount',
    label: 'Market Value',
    bold: true,
    sortable: true,
    align: 'right',
    formatter(row: Transaction) {
      return `${row.marketValueCurrency} ${formatDigits(row.marketValueAmount)}`;
    },
  },
  {
    key: 'unrealizedGainLossAmount',
    label: 'Unrealized gain/loss',
    sortable: true,
    align: 'right',
    formatter(row: Transaction) {
      return (
        <CurrencyAmount
          currency={row.unrealizedGainLossCurrency}
          amount={row.unrealizedGainLossAmount}
          percent={row.unrealizedGainLossPercent}
          size={'small'}
          showSign={true}
        />
      );
    },
  },
  {
    key: 'investmentAmountAmount',
    label: 'Investment amount',
    sortable: true,
    align: 'right',
    formatter(row: Transaction) {
      return `${row.investmentAmountCurrency} ${formatDigits(row.investmentAmountAmount)}`;
    },
  },
  {
    key: 'navAmount',
    label: 'NAV',
    sortable: true,
    align: 'right',
    formatter(row: Transaction) {
      return `${row.navCurrency} ${formatDigits(row.navAmount)}`;
    },
  },
  {
    key: 'unit',
    label: 'Unit',
    sortable: true,
    align: 'right',
    formatter(row: Transaction) {
      return formatDigits(row.unit);
    },
  },
  {
    key: 'name',
    label: 'Fund 2',
    formatter(row: Transaction) {
      if (row.fundContextualItem.length > 0) {
        const items = row.fundContextualItem.map((it) => ({ label: it }));
        return (
          <div
            style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}
          >
            {row.name}
            <ContextMenu items={items} />
          </div>
        );
      } else {
        return row.name;
      }
    },
  },
];
Error.args = {
  errorView: (
    <ErrorView
      message={'We are unable to display your holdings at this moment, please try again later'}
      refresh={() => console.log('refresh')}
    />
  ),
  data: [],
  columns: columns,
};
Loading.args = {
  loadingView: <LoadingView message={'Loading your holdings details'} />,
  data: [],
  columns,
};
Empty.args = {
  data: [],
  emptyView: <EmptyView message={"You don't have any investment products"} />,
  columns,
};

TransactionHistory.args = {
  columns,
  data: [
    {
      name: 'Fund A',
      fundContextualItem: ['Buy', 'Sell'],
      marketValueAmount: 1000,
      marketValueCurrency: 'EUR',
      unrealizedGainLossAmount: 1287.4,
      unrealizedGainLossCurrency: 'EUR',
      unrealizedGainLossPercent: 16.15,
      investmentAmountAmount: 100000,
      investmentAmountCurrency: 'EUR',
      navAmount: 200,
      navCurrency: 'EUR',
      unit: 20000,
    },
    {
      name: 'Fund B',
      fundContextualItem: ['Buy', 'Sell'],
      marketValueAmount: 1000,
      marketValueCurrency: 'JPY',
      unrealizedGainLossAmount: 3221.29,
      unrealizedGainLossCurrency: 'JPY',
      unrealizedGainLossPercent: 38.23,
      investmentAmountAmount: 5000,
      investmentAmountCurrency: 'JPY',
      navAmount: 30,
      navCurrency: 'JPY',
      unit: 1000,
    },
    {
      name: 'Fund C',
      fundContextualItem: [],
      marketValueAmount: 300,
      marketValueCurrency: 'USD',
      unrealizedGainLossAmount: -220.56,
      unrealizedGainLossCurrency: 'USD',
      unrealizedGainLossPercent: -23.5,
      investmentAmountAmount: 30000,
      investmentAmountCurrency: 'USD',
      navAmount: 500,
      navCurrency: 'USD',
      unit: 4000,
    },
    {
      name: 'Fund D',
      fundContextualItem: [],
      marketValueAmount: 5000,
      marketValueCurrency: 'HKD',
      unrealizedGainLossAmount: -125.23,
      unrealizedGainLossCurrency: 'HKD',
      unrealizedGainLossPercent: -10.59,
      investmentAmountAmount: 80000,
      investmentAmountCurrency: 'HKD',
      navAmount: 700,
      navCurrency: 'HKD',
      unit: 200,
    },
  ],
};
