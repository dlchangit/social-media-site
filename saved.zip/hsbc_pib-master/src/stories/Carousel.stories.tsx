import '../global.scss';

import React from 'react';
import { Meta, Story } from '@storybook/react/types-6-0';
import { IconAnchor, Carousel, CarouselProps } from '../components';
import { ArticleHolding, GenericNews } from '../demo/InsightDemo';

export default {
  title: 'Carousel',
  component: Carousel,
  argTypes: {},
} as Meta;

const Template: Story<CarouselProps> = (args) => (
  <Carousel {...args} style={{ width: 380 }}>
    <GenericNews />
    <ArticleHolding />
    <GenericNews />
    <ArticleHolding />
  </Carousel>
);

export const Demo = Template.bind({});
Demo.args = {
  anchorOfAll: <IconAnchor href={'/'}>View all</IconAnchor>,
};
