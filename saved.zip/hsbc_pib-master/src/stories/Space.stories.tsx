import '../global.scss';

import React from 'react';
import { Meta, Story } from '@storybook/react/types-6-0';
import { Space, SpaceProps } from '../components';

export default {
  title: 'Space',
  component: Space,
} as Meta;

const Template: Story<SpaceProps> = (args) => (
  <Space {...args} style={{ width: '100%', backgroundColor: 'gray' }} wrap={true}>
    <div style={{ backgroundColor: 'red', width: '500px' }}>hello</div>
    <div style={{ backgroundColor: 'green', width: '500px' }}>world</div>
    <div style={{ backgroundColor: 'yellow', width: '500px' }}>hello world</div>
    <div style={{ backgroundColor: 'blue', width: '100%' }}>Where am i</div>
  </Space>
);

export const SpaceDemo = Template.bind({});
SpaceDemo.args = {};
