import '../global.scss';

import React from 'react';
import { Meta, Story } from '@storybook/react/types-6-0';

import {
  Button,
  ChevronAnchor,
  DropdownItem,
  SingleDropdown,
  SingleDropdownProps,
} from '../components';
import faker from 'faker';

const accountList = [
  {
    value: '001-000000',
    label: '001-000000 HSBC Wealth Connect Investment Services',
  },
  {
    value: '002-000000',
    label: '002-000000 HSBC HK Jade Investment Services',
  },
  {
    value: '003-000000-000',
    label: '003-000000-000 HSBC UK Jade Investment Services',
  },
];

export default {
  title: 'SingleDropdown',
  component: SingleDropdown,
} as Meta;

const Template: Story<SingleDropdownProps> = (args) => {
  return <SingleDropdown {...args} />;
};

export const DefaultValue = Template.bind({});
DefaultValue.args = {
  placeholder: 'SELECT',
  defaultValue: accountList[0].value,
  children: (
    <>
      {accountList.map((it, index) => (
        <DropdownItem key={it.value} value={it.value} disabled={index == 0}>
          {it.label}
        </DropdownItem>
      ))}
      <DropdownItem value={'extra'}>extra testing</DropdownItem>

      <ChevronAnchor href={'/'} direction={false} style={{ width: '100%' }}>
        Link international accounts
      </ChevronAnchor>
    </>
  ),
};

const Template2: Story<SingleDropdownProps> = (args) => {
  const [account, setAccount] = React.useState<string | undefined>(
    accountList[accountList.length - 1].value
  );

  const onClick = () => {
    setAccount(faker.random.arrayElement([...accountList.map((it) => it.value), undefined]));
  };

  return (
    <div>
      <SingleDropdown {...args} value={account} onChange={setAccount} />
      <Button onClick={onClick}>random</Button>
    </div>
  );
};

export const DataBinding = Template2.bind({});
DataBinding.args = {
  placeholder: 'SELECT',
  children: (
    <>
      {accountList.map((it, index) => (
        <DropdownItem key={it.value} value={it.value} disabled={index == 1}>
          {it.label}
        </DropdownItem>
      ))}
      <DropdownItem value={'extra'}>extra testing</DropdownItem>

      <ChevronAnchor href={'/'} direction={false} style={{ width: '100%' }}>
        Link international accounts
      </ChevronAnchor>
    </>
  ),
};
