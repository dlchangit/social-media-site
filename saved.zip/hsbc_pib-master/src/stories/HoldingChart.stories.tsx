import React from 'react';
import { Meta, Story } from '@storybook/react/types-6-0';
import * as am4core from '@amcharts/amcharts4/core';
import am4themes_animated from '@amcharts/amcharts4/themes/animated';
import { HoldingChart, ChartProps } from '../components';

am4core.useTheme(am4themes_animated);

export default {
  title: 'HoldingChart',
  component: HoldingChart,
} as Meta;

const labels = [
  {
    id: 'unit_trusts',
    label: 'Unit Trusts',
  },
  {
    id: 'stock',
    label: 'Stock',
  },
  {
    id: 'bond_and_cds',
    label: 'Bond and CDs',
  },
  {
    id: 'eli_and_structured_notes',
    label: 'ELI and Structured Notes',
  },
  {
    id: 'capital_protected_investments',
    label: 'Capital Protected Investments',
  },
  {
    id: 'deposit_plus',
    label: 'Deposit Plus',
  },
  {
    id: 'cash',
    label: 'Cash',
  },
];

const data = [
  {
    id: 'unit_trusts',
    value: '0.32',
  },
  {
    id: 'stock',
    value: '0.2',
  },
  {
    id: 'bond_and_cds',
    value: '0.16',
  },
  {
    id: 'eli_and_structured_notes',
    value: '0.12',
  },
  {
    id: 'capital_protected_investments',
    value: '0.1',
  },
  {
    id: 'deposit_plus',
    value: '0.05',
  },
  {
    id: 'cash',
    value: '0.05',
  },
];
const Template: Story<ChartProps> = (args) => <HoldingChart {...args} />;

export const HoldingChartPlain = Template.bind({});
export const HoldingChartWithLabel = Template.bind({});
export const HoldingChartWithLegendFormatter = Template.bind({});
export const HoldingChartWithColor = Template.bind({});
export const HoldingChartComplete = Template.bind({});

HoldingChartPlain.args = {
  id: 'holding-chart-0',
  style: {
    height: '200px',
  },
  data,
};
HoldingChartWithLabel.args = {
  id: 'holding-chart-1',
  style: {
    height: '200px',
  },
  data,
  labels,
};
HoldingChartWithLegendFormatter.args = {
  id: 'holding-chart-2',
  style: {
    height: '200px',
  },
  legendFormatter: (label, value) => {
    return `${label} (${parseFloat(value) * 100}%)`;
  },
  data,
  labels,
};

HoldingChartWithColor.args = {
  id: 'holding-chart-3',
  style: {
    height: '200px',
  },
  legendFormatter: (label, value) => {
    return `${label} (${parseFloat(value) * 100}%)`;
  },
  data,
};

HoldingChartComplete.args = {
  id: 'holding-chart-4',
  style: {
    height: '200px',
  },
  legendFormatter: (label, value) => {
    return `${label} (${parseFloat(value) * 100}%)`;
  },
  data,
  labels,
};
