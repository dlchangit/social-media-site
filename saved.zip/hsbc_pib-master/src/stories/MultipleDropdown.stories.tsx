import '../global.scss';

import React from 'react';
import { Meta, Story } from '@storybook/react/types-6-0';
import { Button, DropdownItem, MultipleDropdown, MultipleDropdownProps } from '../components';
import faker from 'faker';

const accountList = [
  {
    value: '001-000000',
    label: '001-000000 HSBC Wealth Connect Investment Services',
  },
  {
    value: '002-000000',
    label: '002-000000 HSBC HK Jade Investment Services',
  },
  {
    value: '003-000000-000',
    label: '003-000000-000 HSBC UK Jade Investment Services',
  },
  {
    value: '004-000000-000',
    label: '004-000000-000 HSBC China Jade Investment Services',
  },
];

export default {
  title: 'MultipleDropdown',
  component: MultipleDropdown,
  // argTypes: {
  //   values: {
  //     control: {
  //       type: 'array',
  //     },
  //     defaultValue: [accountList[0].value, accountList[2].value],
  //   },
  // },
  args: {
    allOption: 'All',
  },
} as Meta;

const Template: Story<MultipleDropdownProps> = (args) => {
  return <MultipleDropdown {...args}>{args.children}</MultipleDropdown>;
};

export const DefaultValue = Template.bind({});
DefaultValue.args = {
  placeholder: 'SELECT',
  defaultValues: [accountList[2].value],
  children: (
    <>
      {accountList.map((it, index) => (
        <DropdownItem key={it.value} value={it.value} disabled={index == 1}>
          {it.label}
        </DropdownItem>
      ))}
      <DropdownItem value={'extra'}>extra testing</DropdownItem>
      <a href={'https://www.google.com'} target="_blank" rel="noreferrer" style={{ width: '100%' }}>
        Link international accounts
      </a>
    </>
  ),
};

const Template2: Story<MultipleDropdownProps> = (args) => {
  const [accounts, setAccounts] = React.useState<string[]>([]);

  const onClick = () => {
    setAccounts(faker.random.arrayElements(accountList, 2).map((it) => it.value));
  };

  return (
    <div>
      <MultipleDropdown {...args} values={accounts} onChange={setAccounts}>
        {args.children}
      </MultipleDropdown>
      <Button onClick={onClick}>random</Button>
    </div>
  );
};

export const DataBinding = Template2.bind({});
DataBinding.args = {
  placeholder: 'SELECT',
  children: (
    <>
      {accountList.map((it, index) => (
        <DropdownItem key={it.value} value={it.value} disabled={index == 1}>
          {it.label}
        </DropdownItem>
      ))}
      <DropdownItem value={'extra'}>extra testing</DropdownItem>
      <a href={'https://www.google.com'} target="_blank" rel="noreferrer" style={{ width: '100%' }}>
        Link international accounts
      </a>
    </>
  ),
};
