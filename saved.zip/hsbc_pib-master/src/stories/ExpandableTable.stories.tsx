import '../global.scss';

import React from 'react';
import { Meta, Story } from '@storybook/react/types-6-0';

import {
  ExpandableTable,
  ExpandableTableProps,
  TableCol,
  TableRow,
  EmptyView,
  ErrorView,
  LoadingView,
} from '../components';

export default {
  title: 'ExpandableTable',
  component: ExpandableTable,
} as Meta;

// noinspection RequiredAttributes
const Template: Story<ExpandableTableProps> = (args) => (
  <ExpandableTable
    {...args}
    header={
      <TableRow header={true}>
        <TableCol style={{ flex: '1 1 315px' }}>Product</TableCol>
        <TableCol style={{ flex: '1 1 190px' }} align={'right'}>
          Dividend/cash income
        </TableCol>
      </TableRow>
    }
  />
);

export const Error = Template.bind({});
export const Empty = Template.bind({});
export const Loading = Template.bind({});

Error.args = {
  errorView: (
    <ErrorView
      message={'We are unable to display your holdings at this moment, please try again later'}
      refresh={() => console.log('refresh')}
    />
  ),
};
Loading.args = {
  loadingView: <LoadingView message={'Loading your holdings details'} />,
};

Empty.args = {
  emptyView: <EmptyView message={"You don't have any investment products"} />,
};
