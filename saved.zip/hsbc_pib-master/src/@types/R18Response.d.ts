export interface R18Response {
  accountFilterInformation: AccountFilterInformation[];
  accountGroupInformation: AccountGroupInformation[];
  accountOverviewInformation: AccountOverviewInformation[];
  additionalScreenInformation: AdditionalScreenInformation;
  aggregateXRaySummary: AggregateXRaySummary[];
  customerDetailInformation: CustomerDetailInformation | null;
  customerTotalHoldingInformation: CustomerTotalHoldingInformation[];
  holdingOrderInformation: HoldingOrderInformation[];
  holdingSummary: HoldingSummary[];
  modelPortfolioInformation: ModelPortfolioInformation | null;
  monthlyRealizedGainLossInformation: MonthlyRealizedGainLossInformation[];
  otherHoldingAdditionalInformation: OtherHoldingAdditionalInformation;
  paginationResponse: PaginationResponse[];
  portfolioAnalysisHoldingDetailsInformation: PortfolioAnalysisHoldingDetailsInformation[];
  portfolioAnalysisInformation: PortfolioAnalysisInformation[];
  portfolioDetailInformation: PortfolioDetailInformation[];
  portfolioTotalInformation: PortfolioTotalInformation[];
  reasonCodes: ReasonCode[];
  responseCode: string;
  sessionInformation: SessionInformation;
  sortingCriteria: SortingCriterion[];
  subPortfolioDetailInformation: SubPortfolioDetailInformation[];
  watchlistDetailInformation: WatchlistDetailInformation[];
}

export interface AccountFilterInformation {
  accountBenchmarkCodes: string[];
  accountControlNumber: string | null;
  accountFilterMultipleCurrencyInformation: AccountFilterMultipleCurrencyInformation[];
  accountGroupIdentifier: string | null;
  accountListInformation: AccountFilterInformationAccountListInformation[];
  accountModelTypeCode: string | null;
  accountNickName: string;
  accountNumber: string;
  accountOwnerInformation: AccountOwnerInformation[];
  accountProductTypeCode: string | null;
  accountSegmentText: string | null;
  accountStatusCode: string;
  accountTypeCode: string;
  countryInvestmentAccountCode: string | null;
  currencyAccountCode: string;
  groupMemberInvestmentAccountCode: string | null;
  isGbaAccount: string;
  jointAccountIndicator: string | null;
  jointRequestCustomerIndicator: string | null;
  srdOptionIndicator: string | null;
}

export interface AccountFilterMultipleCurrencyInformation {
  accountMarketValueAmount: number;
  currencyAccountMarketValueCode: string;
  currencyTypeCode: string;
}

export interface AccountFilterInformationAccountListInformation {
  accountControlNumber: string | null;
  accountGroupIdentifier: string | null;
  accountNickName: string;
  accountNumber: string;
  accountOwnerInformations?: AccountOwnerInformation[];
  accountProductTypeCode: string | null;
  accountTypeCode: string;
  countryInvestmentAccountCode: string | null;
  currencyAccountCode: string;
  groupMemberInvestmentAccountCode: string | null;
  jointAccountIndicator: string | null;
  jointRequestCustomerIndicator: string | null;
}

export interface AccountOwnerInformation {
  customerAccountOwnerFirstName: string;
  customerAccountOwnerFirstSecondaryNationalLanguageSupportName: string;
  customerAccountOwnerFullName: string;
  customerAccountOwnerFullSecondaryNationalLanguageSupportName: string;
  customerAccountOwnerLastName: string;
  customerAccountOwnerLastSecondaryNationalLanguageSupportName: string;
  customerAccountOwnerTitleSecondaryNationalLanguageSupportText: string;
  customerAccountOwnerTitleText: string;
}

export interface AccountGroupInformation {
  accountGroupMultipleCurrencyInformation: AccountGroupMultipleCurrencyInformation[];
  accountListInformation: AccountGroupInformationAccountListInformation[];
  cardAccountInformation: CardAccountInformation[];
  dashboardaccountGroupIdentifier?: string;
  dashboardAccountParentSubGroupIdentifier: string | null;
  dashboardAccountSubGroupIdentifier: string;
  insuranceAccountInformation: InsuranceAccountInformation[];
  loanMortgageAccountInformation: LoanMortgageAccountInformation[];
}

export interface AccountGroupMultipleCurrencyInformation {
  accountCashMarketValueAmount: number | null;
  accountInvestmentMarketValueAmount: number | null;
  accountMarketValueAmount: number;
  currencyAccountCashMarketValueCode: string | null;
  currencyAccountInvestmentMarketValueCode: string | null;
  currencyAccountMarketValueCode: string;
  currencyProductHoldingBookValueAmountCode: string | null;
  currencyProfitLossUnrealizedAmountCode: string | null;
  currencyTypeCode: string;
  productHoldingBookValueAmount: number | null;
  profitLossUnrealizedAmount: number | null;
  profitLossUnrealizedPercent: number | null;
}

export interface AccountGroupInformationAccountListInformation {
  accountControlNumber: string | null;
  accountGroupIdentifier: string | null;
  accountNickName: string;
  accountNumber: string;
  accountOwnerInformations?: AccountOwnerInformation[];
  accountProductTypeCode: string | null;
  accountTypeCode: string;
  countryInvestmentAccountCode: string | null;
  currencyAccountCode: string;
  groupMemberInvestmentAccountCode: string | null;
  jointAccountIndicator: string | null;
  jointRequestCustomerIndicator: string | null;
}

export interface CardAccountInformation {
  cardAccountMultipleCurrencyInformation: CardAccountMultipleCurrencyInformation[];
}

export interface CardAccountMultipleCurrencyInformation {
  balanceOutstandingAmount: number;
  creditLimitAmount: number;
  currencyBalanceOutstandingCode: string;
  currencyCreditLimitCode: string;
  currencyTypeCode: string;
}

export interface InsuranceAccountInformation {
  insuranceAccountMultipleCurrencyInformation: MultipleCurrencyInformation[];
}

export interface MultipleCurrencyInformation {
  currencyGuaranteedValueInsuranceAccountCode: string;
  currencyPolicyValueCode: string;
  currencyPremiumTotalPaidCode: string;
  currencySumInsuredCode: string;
  currencyTypeCode: string;
  guaranteedValueInsuranceAccountAmount: number;
  policyValueAmount: number;
  premiumTotalPaidAmount: number;
  sumInsuredAmount: number;
}

export interface LoanMortgageAccountInformation {
  loanMortgageAccountMultipleCurrencyInformation: LoanMortgageAccountMultipleCurrencyInformation[];
}

export interface LoanMortgageAccountMultipleCurrencyInformation {
  balanceOutstandingAmount: number;
  currencyBalanceOutstandingCode: string;
  currencyTypeCode: string;
}

export interface AccountOverviewInformation {
  accountBenchmarkCodes: string[];
  accountCardLiabilityInformation: AccountCardLiabilityInformation[];
  accountCashHoldingInformation: AccountCashHoldingInformation[];
  accountControlNumber: string | null;
  accountGroupIdentifier: string | null;
  accountHoldingUnderlyingProdInformation: AccountHoldingUnderlyingProdInformation[];
  accountInsuranceHoldingInformation: AccountInsuranceHoldingInformation[];
  accountLoanMortgageLiabilityInformation: AccountLoanMortgageLiabilityInformation[];
  accountModelTypeCode: string | null;
  accountNickName: string;
  accountNumber: string;
  accountOverviewMultipleCurrencyInformation: AccountOverviewMultipleCurrencyInformation[];
  accountOwnerInformation: AccountOwnerInformation[];
  accountOwnershipTypeCode: string;
  accountProductTypeCode: string | null;
  accountSegmentText: string | null;
  accountShortNationalLanguageSupportName: string;
  accountTypeCode: string;
  accountValidationDateTime: string;
  additionalAccountInformation: AdditionalAccountInformation[];
  containValidationDateTimeIndicator: boolean;
  contributionIndividualSavingAccountAmount: number;
  countryInvestmentAccountCode: string | null;
  currencyAccountCode: string;
  currencyContributionIndividualSavingAccountCode: string;
  groupMemberInvestmentAccountCode: string | null;
  jointAccountIndicator: string | null;
  jointRequestCustomerIndicator: string | null;
  reasonCodes: ReasonCode[];
  responseCode: string;
  rrspPlanAccountInformation: RrspPlanInformation[];
  timeZoneDisplayCode: string;
}

export interface AccountCardLiabilityInformation {
  accountCardLiabilityMultipleCurrencyInformation: CardLiabilityMultipleCurrencyInformation[];
  paymentDueNextDate: string;
}

export interface CardLiabilityMultipleCurrencyInformation {
  balanceOutstandingAmount: number;
  billedStatementLastAmount: number;
  creditLimitAmount: number;
  currencyBalanceOutstandingCode: string;
  currencyBilledStatementLastCode: string;
  currencyCreditLimitCode: string;
  currencyTypeCode: string;
}

export interface AccountCashHoldingInformation {
  allowNewDepositIndicator: string;
  countryISOCode: string;
  curencyMaturityValueCode: string;
  currencyInterestAccruedMaturityCode: string;
  currencyProductCode: string;
  exchangeSpotRate: number;
  instructionForeignLocalTimeDepositMaturityCode: string;
  interestAccruedMaturityAmount: number;
  interestRate: number;
  interestUpperBoundRate: number;
  lcyExchgRateList: LcyExchgRateList[];
  periodicityForeignLocalTimeDepositInterestPaymentCode: string;
  productDashboardSubTypeCode: string;
  productDashboardTypeCode: string;
  productMaturityDate: string;
  productPeriodText: string;
  productSubtypeCode: string;
  productTypeCode: string;
  valueForeignLocalTimeDepositMaturityAmount: number;
}

export interface LcyExchgRateList {
  currencyFromCode: string;
  currencyToCode: string;
  exchangeSpotRate: number;
}

export interface AccountHoldingUnderlyingProdInformation {
  countryISOCode: string;
  countryProductTradableCode: string;
  currencyEquityLinkIndexCallPriceCode: string;
  currencyEquityLinkIndexKnockInCode: string;
  currencyEquityLinkIndexStrikePriceCode: string;
  currencyInstrumentUnderlyingMarketPriceCode: string;
  currencyInstrumentUnderlyingMarketValueCode: string;
  currencyProductCode: string;
  currencyProductExercisePriceCode: string;
  currencyProductExpiryAmountCode: string;
  equityLinkIndexCallPriceAmount: number;
  equityLinkIndexCallPricePercent: number;
  equityLinkIndexKnockInAmount: number;
  equityLinkIndexKnockInPercent: number;
  equityLinkIndexStrikePriceAmount: number;
  equityLinkIndexStrikePricePercent: number;
  groupMemberCode: string;
  instrumentUnderlyingCode: string;
  instrumentUnderlyingMarketPriceAmount: number;
  instrumentUnderlyingMarketValueAmount: number;
  instrumentUnderlyingName: string;
  instrumentUnderlyingShortName: string;
  priceQuoteTypeCode: string;
  productAlternativeNumber: string;
  productCodeAlternativeClassificationCode: string;
  productExercisePriceAmount: number;
  productExpiryAmount: number;
  productIdInformation: ProductIDInformation[];
  productStatusCode: string;
  productSubtypeCode: string;
  productTypeCode: string;
  unitsHoldNumber: number;
}

export interface ProductIDInformation {
  countryProductTradableCode: string;
  productAlternativeNumber: string;
  productCodeAlternativeClassificationCode: string;
}

export interface AccountInsuranceHoldingInformation {
  accountInsuranceHoldingDeferredInformation: DeferredInformation[];
  accountInsuranceHoldingMultipleCurrencyInformation: AccountInsuranceHoldingMultipleCurrencyInformation[];
  arrangementIdentifierInsurancePolicy: string;
  cashValueGuaranteedToDateAmount: number;
  currencyCashValueGuaranteedToDateCode: string;
  currencyPaymentBenefitRegularCode: string;
  currencyPaymentDividendIncomeToDateCode: string;
  currencyPolicyCode: string;
  currencyPremiumAnnualCode: string;
  currencyPremiumPaymentCode: string;
  insurancePolicyArrangementType: string;
  paymentBenefitOptionCode: string;
  paymentBenefitRegularAmount: number;
  paymentDividendIncomeToDateAmount: number;
  paymentDividendOptionCode: string;
  paymentPeriodicityCode: string;
  personInsuredInformation: PersonInsuredInformation[];
  policyExpiryDate: string;
  policyStartDate: string;
  policyStatusCode: string;
  policyTermText: number;
  premiumAnnualAmount: number;
  premiumPaymentAmount: number;
  productPriceUpdateDate: string;
  trustInvestmentIndicator: boolean;
}

export interface DeferredInformation {
  currencyProductHoldingDeferredCode: string;
  periodDeferredNumber: number;
  productHoldingDeferredAmount: number;
}

export interface AccountInsuranceHoldingMultipleCurrencyInformation {
  currencyGuaranteedValueInsuranceAccountCode: string;
  currencyPaymentBenefitRegularCode: string;
  currencyPolicyValueCode: string;
  currencyPremiumPaymentCode: string;
  currencyPremiumTotalPaidCode: string;
  currencySumInsuredCode: string;
  currencyTypeCode: string;
  guaranteedValueInsuranceAccountAmount: number;
  paymentBenefitRegularAmount: number;
  policyValueAmount: number;
  premiumPaymentAmount: number;
  premiumTotalPaidAmount: number;
  sumInsuredAmount: number;
}

export interface PersonInsuredInformation {
  insuredName: string;
}

export interface AccountLoanMortgageLiabilityInformation {
  accountLoanMortgageLiabilityMultipleCurrencyInformation: LoanMortgageLiabilityMultipleCurrencyInformation[];
  interestCalculationPreferenceCode: string;
  interestRate: number;
  interestRateTypeCode: string;
  interestSpreadRate: number;
  loanDueDate: string;
  mortgagePaymentTypeCode: string;
  paymentNextDate: string;
  periodicityRepaymentCode: string;
  policyStartDate: string;
  policyTermText: number;
  policyTermTypeCode: string;
  residentialTypeCode: string;
}

export interface LoanMortgageLiabilityMultipleCurrencyInformation {
  balanceOutstandingAmount: number;
  currencyBalanceOutstandingCode: string;
  currencyLoanOriginalCode: string;
  currencyPaymentNextCode: string;
  currencyTypeCode: string;
  loanOriginalAmount: number;
  paymentNextAmount: number;
}

export interface AccountOverviewMultipleCurrencyInformation {
  accountCashMarketValueAmount: number | null;
  accountHoldingBookValueAmount: number;
  accountInvestmentMarketValueAmount: number | null;
  accountMarketValueAmount: number;
  accountprofitLossUnrealizedAmount: number | null;
  accountprofitLossUnrealizedPercent: number | null;
  balanceMarginAvailableAmount: number | null;
  currencyAccountCashMarketValueCode: string | null;
  currencyAccountHoldingBookValueCode: string;
  currencyAccountInvestmentMarketValueCode: string | null;
  currencyAccountMarketValueCode: string;
  currencyAccountProfitLossUnrealizedCode: string;
  currencyBalanceMarginAvailableAmountCode: string | null;
  currencyTypeCode: string;
}

export interface AdditionalAccountInformation {
  additionalAccountKey: string;
  additionalAccountValue: unknown;
}

export interface ReasonCode {
  reasonCode: string;
  trackingNumber: string;
}

export interface RrspPlanInformation {
  beneficiary: string;
  pensionActJurisdiction: string;
  planNarrative: string;
  planNumber: string;
  planRestriction: string;
  planStatus: string;
  planType: string;
}

export interface AdditionalScreenInformation {
  customerAgreementNotSignNumber: string;
}

export interface AggregateXRaySummary {
  dashboardAnalysisTypeCode: string;
  dashboardProductHoldingSubTypeCode: string;
  dashboardProductHoldingTypeCode: string;
}

export interface CustomerDetailInformation {
  customerName: string;
  customerNumber: string;
}

export interface CustomerTotalHoldingInformation {
  customerTotalHoldingMultipleCurrencyInformation: CustomerTotalHoldingMultipleCurrencyInformation[];
  marginAccountIndicator: boolean;
}

export interface CustomerTotalHoldingMultipleCurrencyInformation {
  assetMarketValueAmount: number | null;
  balanceMarginAvailableAmount: number | null;
  currencyAssetMarketValueCode: string | null;
  currencyBalanceMarginAvailableAmountCode: string | null;
  currencyCustomerHoldingMarketValueTotalCode: string;
  currencyLiabilityMarketValueCode: string | null;
  currencyTypeCode: string;
  customerHoldingMarketValueTotalAmount: number;
  liabilityMarketValueAmount: number | null;
}

export interface HoldingOrderInformation {
  accountProductTypeCode: string | null;
  accountTypeCode: string;
  additionalHoldingInformation: AdditionalHoldingInformation[];
  allowShowTransactionIndicator: string;
  countryISOCode: string;
  countryProductTradableCode: string;
  countryProductTradableMarket: string;
  currencyProductCode: string;
  groupMemberCode: string;
  holdingBondProdInformation: HoldingBondProdInformation[];
  holdingCardLiabilityInformation: HoldingCardLiabilityInformation[];
  holdingDetailInformation: HoldingDetailInformation[];
  holdingELIProdInformation: HoldingELIProdInformation[];
  holdingFYILCYProdInformation: HoldingFYILCYProdInformation[];
  holdingFundProdInformation: HoldingFundProdInformation[];
  holdingInsuranceProdInformation: HoldingInsuranceProdInformation[];
  holdingLoanMortgageLiabilityInformation: HoldingLoanMortgageLiabilityInformation[];
  holdingMaturityInformation: HoldingMaturityInformation[];
  holdingOtherAssetInformation: HoldingOtherAssetInformation[];
  holdingOtherLiabilityInformation: HoldingOtherLiabilityInformation[];
  holdingOtherProtectionInformation: HoldingOtherProtectionInformation[];
  holdingSNProdInformation: HoldingSNProdInformation[];
  holdingSummaryInformation: HoldingSummaryInformation[];
  holdingUnderlyingProdInformation: HoldingUnderlyingProdInformation[];
  lcyExchgRateList: LcyExchgRateList[];
  orderInformation: OrderInformation[];
  personInsuredInformation: PersonInsuredInformation[];
  productAlternativeNumber: string;
  productClassificationCode: string;
  productCode: string;
  productCodeAlternativeClassificationCode: string;
  productDashboardSubTypeCode: string;
  productDashboardTypeCode: string;
  productIdInformation: ProductIDInformation[] | null;
  productInvestmentDataStoreNumber: string | null;
  productName: string;
  productPriceDivisorAmount: number;
  productShortName: string;
  productStatusCode: string;
  productSubtypeCode: string;
  productTypeCode: string;
  responseRecordTypeCode: string;
  rrspPlanHoldingOrderInformation: RrspPlanInformation[];
  timeZoneDisplayCode: string;
  uniformResourceLocatorProductFactSheetText: string;
}

export interface AdditionalHoldingInformation {
  additionalHoldingKey: string;
  additionalHoldingValue: unknown;
}

export interface HoldingBondProdInformation {
  bondOfTheMonthIndicator: string;
  bondTopSellIndicator: string;
  couponBondRate: number;
}

export interface HoldingCardLiabilityInformation {
  holdingCardLiabilityMultipleCurrencyInformation: CardLiabilityMultipleCurrencyInformation[];
  paymentDueNextDate: string;
}

export interface HoldingDetailInformation {
  allowBuyAmountProductIndicator: string;
  allowBuyProductIndicator: string;
  allowBuyUnitProductIndicator: string;
  allowRolloverIndicator: string;
  allowSellAmountProductIndicator: string;
  allowSellMonthlyInvestmentProgramAmountProductIndicator: string;
  allowSellMonthlyInvestmentProgramUnitProductIndicator: string;
  allowSellProductIndicator: string;
  allowSellUnitProductIndicator: string;
  allowStopLossOrderIndicator: boolean;
  allowSwitchInAmountProductIndicator: string;
  allowSwitchInProductIndicator: string;
  allowSwitchInUnitProductIndicator: string;
  allowSwitchOutAmountProductIndicator: string;
  allowSwitchOutProductIndicator: string;
  allowSwitchOutUnitProductIndicator: string;
  allowTargetBuySellOrderIndicator: boolean;
  allowTradeMonthlyInvestmentProgramProductIndicator: string;
  allowTwoWayLimitOrderIndicator: boolean;
  averagePurchasePriceAmount: number;
  currencyAveragePurchasePriceCode: string;
  currencyIncomeCurrentPurchasePeriodCode: string | null;
  currencyInterestAccrueUnitAmountCode: string;
  currencyLinkDepositCode: string;
  currencyMarketPriceChangeCode: string;
  currencyPairDepositText: string;
  currencyProductCode: string;
  currencyProductMarketPriceCode: string;
  currencyProductNominalValueAmountCode: string;
  dayRangeHigh: number;
  dayRangeLow: number;
  depositDate: string;
  depositType: string;
  dividend: number;
  dividendYield: number;
  docAnnualReport: string;
  docFactsheet: string;
  docInterimReport: string;
  docProspectus: string;
  exchangeBreakEvenRate: number;
  exchangeInitialRate: number;
  exchangeRateFixDate: string;
  exchangeRetrieveDate: string;
  exchangeSpotRate: number;
  exchangeTriggerRate: number;
  executionPriceSuspectTypeCode: string;
  flexFundProductIndicator: string;
  holdingDepositInformation: HoldingDepositInformation[];
  holdingDetailMultipleCurrencyInformation: HoldingDetailMultipleCurrencyInformation[];
  incomeCurrentPurchasePeriodAmount: number | null;
  interestAccrueUnitAmount: number;
  interestRate: number;
  interestUpperBoundRate: number;
  markToMarketIndicator: string;
  marketPriceChangeAmount: number;
  marketPriceChangePercent: number;
  marketStatus: string;
  minBuyAmount: number;
  minMipAmount: number;
  peRatio: number;
  priceQuoteTypeCode: string;
  productDepositHoldingCode: string;
  productHoldingQuantityCount: number;
  productHoldingTradableQuantityCount: number;
  productMarketPriceAmount: number;
  productNominalValueAmount: number;
  productPriceUpdateDate: string;
  restrOnlScribIndicator: string;
  returnPersonalRate: number;
  sellProductAvailableIndicator: boolean;
  updateWatchListLastDate: string;
  watchItemIdentifier: number;
  yearHighPrice: number;
  yearLowPrice: number;
  yieldAnnualMinimumPercent: number;
  yieldAnnualPotentialPercent: number;
}

export interface HoldingDepositInformation {
  currencyExchangeGainLossCode: string;
  currencyLocalBookCostValueCode: string;
  exchangeGainLossAmount: number;
  localBookCostValueAmount: number;
}

export interface HoldingDetailMultipleCurrencyInformation {
  balanceMarginAvailableAmount: number | null;
  currencyBalanceMarginAvailableAmountCode: string | null;
  currencyForecastIncomeAmountCode: string | null;
  currencyIncomeCurrentPurchasePeriodCode: string | null;
  currencyIncomeProductAmountCode: string | null;
  currencyProductHoldingBookValueAmountCode: string | null;
  currencyProductHoldingMarketValueAmountCode: string;
  currencyProductHoldingUnitCostAverageCode: string;
  currencyProfitLossRealizedAmountCode: string | null;
  currencyProfitLossRealizedIncludeIncomeCode: string | null;
  currencyProfitLossUnrealizedAmountCode: string | null;
  currencyProfitLossUnrealizedIncludeIncomeCode: string | null;
  currencyTypeCode: string;
  estimatedYieldPercent: number | null;
  forecastIncomeAmount: number | null;
  incomeCurrentPurchasePeriodAmount: number | null;
  incomeProductAmount: number | null;
  productHoldingBookValueAmount: number | null;
  productHoldingMarketValueAmount: number;
  productHoldingUnitCostAverageAmount: number;
  profitLossRealizedAmount: number | null;
  profitLossRealizedIncludeIncomeAmount: number | null;
  profitLossRealizedIncludeIncomePercent: number | null;
  profitLossRealizedPercent: number | null;
  profitLossUnrealizedAmount: number | null;
  profitLossUnrealizedIncludeIncomeAmount: number | null;
  profitLossUnrealizedIncludeIncomePercent: number | null;
  profitLossUnrealizedPercent: number | null;
}

export interface HoldingELIProdInformation {
  equityLinkIndexBarrierPercent: number;
  equityLinkIndexCallPricePercent: number;
  equityLinkIndexKnockInPercent: number;
  periodicityEquityLinkIndexCallCode: string;
  periodicityEquityLinkIndexKnockInCode: string;
  productExercisePricePercent: number;
  tradeDate: string;
  yieldToMaturityEquityLinkedIndexAnnualPercent: number;
  yieldToMaturityEquityLinkedIndexMonthlyPercent: number;
  yieldToMaturityEquityLinkedIndexPercent: number;
}

export interface HoldingFYILCYProdInformation {
  allowNewDepositIndicator: string;
  curencyMaturityValueCode: string;
  currencyInterestAccruedMaturityCode: string;
  instructionForeignLocalTimeDepositMaturityCode: string;
  interestAccruedMaturityAmount: number;
  periodicityForeignLocalTimeDepositInterestPaymentCode: string;
  valueForeignLocalTimeDepositMaturityAmount: number;
}

export interface HoldingFundProdInformation {
  fundShoreLocationCode: string;
  fundShortListedIndicator: string;
  riskLevelFundCode: number;
  topPerformanceFundIndicator: string;
  topSellFundIndicator: string;
}

export interface HoldingInsuranceProdInformation {
  accountInsuranceHoldingDeferredInformation: DeferredInformation[];
  arrangementIdentifierInsurancePolicy: string;
  cashValueGuaranteedToDateAmount: number;
  currencyCashValueGuaranteedToDateCode: string;
  currencyOutstandingPremiumAmount: number;
  currencyOutstandingPremiumCode: string;
  currencyPaymentBenefitRegularCode: string;
  currencyPolicyCode: string;
  currencyPremiumAnnualCode: string;
  holdingInsuranceProdMultipleCurrencyInformation: MultipleCurrencyInformation[];
  ilasHoldingInsuranceProdInformation: IlasHoldingInsuranceProdInformation[];
  paymentBenefitOptionCode: string;
  paymentBenefitRegularAmount: number;
  paymentDividendOptionCode: string;
  paymentPeriodicityCode: string;
  policyStartDate: string;
  policyStatusCode: string;
  policyTermText: number;
  premiumAnnualAmount: number;
  productName: string;
  productShortName: string;
  trustInvestmentIndicator: boolean;
}

export interface IlasHoldingInsuranceProdInformation {
  currencyPremiumPayableCode: string;
  currencyTotalAccountValueCode: string;
  currencyTotalPremiumPaidCode: string;
  premiumPayableAmount: number;
  premiumTotalPaidAmount: number;
  totalAccountValueAmount: number;
}

export interface HoldingLoanMortgageLiabilityInformation {
  holdingLoanMortgageLiabilityMultipleCurrencyInformation: LoanMortgageLiabilityMultipleCurrencyInformation[];
  interestCalculationPreferenceCode: string;
  interestRate: number;
  interestRateTypeCode: string;
  interestSpreadRate: number;
  loanDueDate: string;
  mortgagePaymentTypeCode: string;
  paymentNextDate: string;
  periodicityRepaymentCode: string;
  policyStartDate: string;
  policyTermText: number;
  policyTermTypeCode: string;
  residentialTypeCode: string;
}

export interface HoldingMaturityInformation {
  productMaturityDate: string;
  productPeriodText: string;
}

export interface HoldingOtherAssetInformation {
  accountExternalTypeCode: string;
  assetOtherVersionNumber: number;
  currencyInvestmentMonthlyCode: string;
  investmentMonthlyAmount: number;
  jointOwnershipIndicator: boolean;
  otherAssetIdentifier: string;
  otherAssetRemarkText: string;
  otherAssetReviewIndicator: string;
  productHoldingTaxStatusCode: string;
  productOtherAssetTypeCode: string;
  productSubtypeCode: string;
  productThirdPartyIdentifer: string;
  productThirdPartyMaturityDate: string;
  productTypeCode: string;
  providerOtherAssetName: string;
}

export interface HoldingOtherLiabilityInformation {
  creditLimitAmount: number;
  currencyCreditLimitCode: string;
  currencyInvestmentMonthlyCode: string;
  currencyOutstandingLiabilityCode: string;
  interestRate: number;
  investmentMonthlyAmount: number;
  jointOwnershipIndicator: boolean;
  liabilityOtherIdentifier: string;
  liabilityOtherName: string;
  liabilityOtherRemarkText: string;
  liabilityOtherSubTypeCode: string;
  liabilityOtherTypeCode: string;
  liabilityOtherVersionNumber: number;
  liabilityOutstandingAmount: number;
  policyStartDate: string;
  policyTermText: number;
  productThirdPartyIdentifer: string;
  productThirdPartyMaturityDate: string;
  providerOtherLiabilityText: string;
  residentialIndicator: boolean;
}

export interface HoldingOtherProtectionInformation {
  currencyInvestmentMonthlyCode: string;
  currencyPolicyValueCode: string;
  currencySumInsuredCode: string;
  holdingOtherProtectionDeferredInformation: DeferredInformation[];
  investmentMonthlyAmount: number;
  policyEffectiveDate: string;
  policyTermText: number;
  policyValueAmount: number;
  productOtherInsuranceIdentifier: string;
  productOtherInsuranceName: string;
  productOtherInsuranceRemarkText: string;
  productOtherInsuranceTypeCode: string;
  productOtherInsuranceVersionNumber: number;
  providerOtherInsuranceText: string;
  sumInsuredAmount: number;
  trustInvestmentIndicator: boolean;
}

export interface HoldingSNProdInformation {
  periodSeniorityProductTenorNumber: number;
}

export interface HoldingSummaryInformation {
  accountControlNumber: string | null;
  accountCurrencyCode: string;
  accountGroupIdentifier: string | null;
  accountInvestmentDataStoreNumber: string;
  accountNickName: string;
  accountNumber: string;
  accountOwnerInformation: AccountOwnerInformation[];
  accountProductTypeCode: string | null;
  accountSegmentText: string | null;
  accountTypeCode: string;
  accountValidationDateTime: string;
  allowBuyAmountProductIndicator: string;
  allowBuyProductIndicator: string;
  allowBuyUnitProductIndicator: string;
  allowSellAmountProductIndicator: string;
  allowSellMonthlyInvestmentProgramAmountProductIndicator: string;
  allowSellMonthlyInvestmentProgramUnitProductIndicator: string;
  allowSellProductIndicator: string;
  allowSellUnitProductIndicator: string;
  allowSwitchInAmountProductIndicator: string;
  allowSwitchInProductIndicator: string;
  allowSwitchInUnitProductIndicator: string;
  allowSwitchOutAmountProductIndicator: string;
  allowSwitchOutProductIndicator: string;
  allowSwitchOutUnitProductIndicator: string;
  allowTradeMonthlyInvestmentProgramProductIndicator: string;
  containValidationDateTimeIndicator: boolean;
  countryInvestmentAccount: string;
  currencyHoldingMarketPriceCode: string;
  executionPriceSuspectTypeCode: string;
  groupMemberInvestmentAccountCode: string | null;
  holdingMarketPriceAmount: number;
  holdingSummaryMultipleCurrencyInformation: HoldingSummaryMultipleCurrencyInformation[];
  jointAccountIndicator: string | null;
  jointRequestCustomerIndicator: string | null;
  markToMarketIndicator: string;
  productHoldingQuantityCount: number;
  timeZoneDisplayCode: string;
}

export interface HoldingSummaryMultipleCurrencyInformation {
  currencyIncomeCurrentPurchasePeriodCode: string | null;
  currencyProductHoldingBookValueAmountCode: string | null;
  currencyProductHoldingMarketValueAmountCode: string;
  currencyProductHoldingUnitCostAverageCode: string;
  currencyProfitLossUnrealizedAmountCode: string | null;
  currencyProfitLossUnrealizedIncludeIncomeCode: string | null;
  currencyTypeCode: string;
  forecastIncomeAmount: number | null;
  incomeCurrentPurchasePeriodAmount: number | null;
  productHoldingBookValueAmount: number | null;
  productHoldingMarketValueAmount: number;
  productHoldingUnitCostAverageAmount: number;
  profitLossUnrealizedAmount: number | null;
  profitLossUnrealizedIncludeIncomeAmount: number | null;
  profitLossUnrealizedIncludeIncomePercent: number | null;
  profitLossUnrealizedPercent: number | null;
}

export interface HoldingUnderlyingProdInformation {
  countryISOCode: string;
  countryProductTradableCode: string;
  currencyEquityLinkIndexCallPriceCode: string;
  currencyEquityLinkIndexKnockInCode: string;
  currencyEquityLinkIndexStrikePriceCode: string;
  currencyInstrumentUnderlyingMarketPriceCode: string;
  currencyInstrumentUnderlyingMarketValueCode: string;
  currencyProductCode: string;
  currencyProductExercisePriceCode: string;
  currencyProductExpiryAmountCode: string;
  equityLinkIndexCallPriceAmount: number;
  equityLinkIndexCallPricePercent: number;
  equityLinkIndexKnockInAmount: number;
  equityLinkIndexKnockInPercent: number;
  equityLinkIndexStrikePriceAmount: number;
  equityLinkIndexStrikePricePercent: number;
  groupMemberCode: string;
  instrumentUnderlyingCode: string;
  instrumentUnderlyingMarketPriceAmount: number;
  instrumentUnderlyingMarketValueAmount: number;
  instrumentUnderlyingName: string;
  instrumentUnderlyingShortName: string;
  priceQuoteTypeCode: string;
  productAlternativeNumber: string;
  productCodeAlternativeClassificationCode: string;
  productExercisePriceAmount: number;
  productExpiryAmount: number;
  productIdInformation: ProductIDInformation[];
  productInitialSpotPriceAmount: number;
  productInitialSpotPriceCurrency: string;
  productStatusCode: string;
  productSubtypeCode: string;
  productTypeCode: string;
  unitsHoldNumber: number;
}

export interface OrderInformation {
  accountGroupIdentifier: string | null;
  accountNickName: string;
  accountNumber: string;
  accountProductTypeCode: string | null;
  accountTypeCode: string;
  allowOrderAmendmentIndicator: string;
  allowOrderCancellationIndicator: string;
  allowViewOrderDetailIndicator: string;
  channelTransactionCode: string;
  countryInvestmentAccountCode: string | null;
  currencyAccountCode: string;
  currencyExecutedCode: string;
  currencyLimitPriceCode: string;
  currencyPrincipalCode: string;
  currencyProductPriceQuoteCode: string;
  currencyStopLossLowestSellingPriceCode: string;
  currencyStopLossPriceCode: string;
  currencyTransactionNetCode: string;
  groupMemberInvestmentAccountCode: string | null;
  orderDealDate: string;
  orderDealtQuantityCount: number;
  orderExpiryDate: string;
  orderLimitPriceAmount: number;
  orderOutstandingQuantityCount: number;
  orderProcessDate: string;
  orderProcessingStatusCode: string;
  orderProjectedSettlementDate: string;
  orderQuantityCount: number;
  orderReceiveDateTime: string;
  orderStopLossLowestSellingPriceAmount: number;
  orderStopLossPriceAmount: number;
  portfolioLinkOrderReferenceNumber: number;
  portfolioLinkOrderTypeCode: string;
  portfolioOrderReferenceNumber: number;
  portfolioOrderReferencePrefixCode: string;
  portfolioOrderReferenceSuffixCode: string;
  portfolioOrderReferenceTypeCode: string;
  portfolioOrderTypeCode: string;
  principalAmount: number;
  productExecutionPriceAmount: number;
  productPriceQuoteAmount: number;
  reasonCancelCode: string;
  reasonCancelOrderText: string;
  recordUpdateLastDateTime: string;
  shortSellIndicator: boolean;
  switchingOrderIndicator: string;
  transactionNetAmount: number;
}

export interface HoldingSummary {
  countryISOCode: string;
  countryProductTradableCode: string;
  currencyProductCode: string;
  groupMemberCode: string;
  productAlternativeNumber: string;
  productCodeAlternativeClassificationCode: string;
  productDashboardSubTypeCode: string;
  productDashboardTypeCode: string;
  productIdInformation: ProductIDInformation[];
  productName: string;
  productShortName: string;
  productStatusCode: string;
  productSubtypeCode: string;
  productTypeCode: string;
  productXRayInformation: ProductXRayInformation[];
}

export interface ProductXRayInformation {
  dashboardProductHoldingSubTypeCode: string;
  dashboardProductHoldingTypeCode: string;
}

export interface ModelPortfolioInformation {
  modelPortfolioCode: string;
}

export interface MonthlyRealizedGainLossInformation {
  dataAggregatedDate: string;
  dataAggregationCode: string;
  monthlyRealizedGainLossMultipleCurrencyInformation: MonthlyRealizedGainLossMultipleCurrencyInformation[];
}

export interface MonthlyRealizedGainLossMultipleCurrencyInformation {
  currencyIncomeCashCode: string;
  currencyProfitLossRealizedCode: string;
  currencyProfitLossRealizedIncludeIncomeCode: string | null;
  currencyTypeCode: string;
  incomeCashAmount: number;
  profitLossRealizedAmount: number | null;
  profitLossRealizedIncludeIncomeAmount: number | null;
}

export interface OtherHoldingAdditionalInformation {
  maxOtherAssetCountIndicator: boolean;
  maxOtherInsuranceCountIndicator: boolean;
  maxOtherLiabilityCountIndicator: boolean;
}

export interface PaginationResponse {
  endDetail: string | null;
  numberOfRecords: number;
  pagingDirectionCode: string | null;
  startDetail: string | null;
  totalNumberOfRecords: number;
}

export interface PortfolioAnalysisHoldingDetailsInformation {
  assetClassPercent: number;
  countryISOCode: string;
  countryProductTradableCode: string;
  currencyProductCode: string;
  currencyProductHoldingBookValueLocalAmountCode: string;
  currencyProductHoldingMarketValueLocalAmountCode: string;
  currencyProductHoldingMarketValueWithinAssetClassLocalAmountCode: string;
  currencyProfitLossUnrealizedLocalAmountCode: string;
  groupMemberCode: string;
  holdingBalanceTotalTypeCode: string;
  holdingMaturityInformation: HoldingMaturityInformation[];
  productAlternativeNumber: string;
  productCode: string;
  productCodeAlternativeClassificationCode: string;
  productDashboardSubTypeCode: string;
  productDashboardTypeCode: string;
  productHoldingBookValueLocalAmount: number;
  productHoldingMarketValueLocalAmount: number;
  productHoldingMarketValueWithinAssetClassLocalAmount: number;
  productIdInformation: ProductIDInformation[];
  productName: string;
  productShortName: string;
  productStatusCode: string;
  productSubtypeCode: string;
  productTypeCode: string;
  profitLossUnrealizedLocalAmount: number;
  profitLossUnrealizedLocalPercent: number;
}

export interface PortfolioAnalysisInformation {
  accountMarketValueLocalAmount: number;
  allocationInvestmentPercent: number;
  currencyAccountMarketValueLocalCode: string;
  dashboardProductHoldingSubTypeCode: string;
  dashboardProductHoldingTypeCode: string;
  productHoldingPercent: number;
  productHoldingSubTypeName: string;
  productHoldingTypeName: string;
}

export interface PortfolioDetailInformation {
  holdingBalanceTotalTypeCode: string;
  ilasHoldingInsuranceProdInformation: IlasHoldingInsuranceProdInformation[];
  portfolioDetailMultipleCurrencyInformation: PortfolioDetailMultipleCurrencyInformation[];
  priceLastUpdateDateTime: number | null;
  productDashboardTypeCode: string;
  productHoldingMarketValuePercent: number | null;
  timeZoneDisplayCode: string;
}

export interface PortfolioDetailMultipleCurrencyInformation {
  balanceMarginAvailableAmount: number | null;
  currencyBalanceMarginAvailableAmountCode: string | null;
  currencyForecastIncomeAmountCode: string | null;
  currencyIncomeCurrentPurchasePeriodCode: string | null;
  currencyIncomeProductAmountCode: string | null;
  currencyProductHoldingBookValueAmountCode: string | null;
  currencyProductHoldingMarketValueAmountCode: string;
  currencyProfitLossRealizedAmountCode: string | null;
  currencyProfitLossRealizedIncludeIncomeCode: string | null;
  currencyProfitLossUnrealizedAmountCode: string | null;
  currencyProfitLossUnrealizedIncludeIncomeCode: string | null;
  currencyTypeCode: string;
  estimatedYieldPercent: number | null;
  forecastIncomeAmount: number | null;
  incomeCurrentPurchasePeriodAmount: number | null;
  incomeProductAmount: number | null;
  productHoldingBookValueAmount: number | null;
  productHoldingMarketValueAmount: number;
  profitLossRealizedAmount: number | null;
  profitLossRealizedIncludeIncomeAmount: number | null;
  profitLossRealizedIncludeIncomePercent: number | null;
  profitLossRealizedPercent: number | null;
  profitLossUnrealizedAmount: number | null;
  profitLossUnrealizedIncludeIncomeAmount: number | null;
  profitLossUnrealizedIncludeIncomePercent: number | null;
  profitLossUnrealizedPercent: number | null;
}

export interface PortfolioTotalInformation {
  holdingBalanceTotalTypeCode: string;
  marginAccountIndicator: boolean;
  portfolioTotalCurrencyGroupInformation: PortfolioTotalCurrencyGroupInformation[];
  portfolioTotalMultipleCurrencyInformation: PortfolioTotalMultipleCurrencyInformation[];
}

export interface PortfolioTotalCurrencyGroupInformation {
  currencyProductHoldingMarketValueAmountCode: string;
  productHoldingMarketValueAmount: number;
}

export interface PortfolioTotalMultipleCurrencyInformation {
  assetMarketValueAmount: number | null;
  balanceMarginAvailableAmount: number | null;
  currencyAssetMarketValueCode: string | null;
  currencyBalanceMarginAvailableAmountCode: string | null;
  currencyForecastIncomeAmountCode: string | null;
  currencyIncomeCurrentPurchasePeriodCode: string | null;
  currencyIncomeProductAmountCode: string | null;
  currencyLiabilityMarketValueCode: string | null;
  currencyProductHoldingBookValueAmountCode: string | null;
  currencyProductHoldingMarketValueAmountCode: string;
  currencyProfitLossRealizedAmountCode: string | null;
  currencyProfitLossRealizedIncludeIncomeCode: string | null;
  currencyProfitLossUnrealizedAmountCode: string | null;
  currencyProfitLossUnrealizedIncludeIncomeCode: string | null;
  currencyTypeCode: string;
  estimatedYieldPercent: number | null;
  forecastIncomeAmount: number | null;
  incomeCurrentPurchasePeriodAmount: number | null;
  incomeProductAmount: number | null;
  liabilityMarketValueAmount: number | null;
  productHoldingBookValueAmount: number | null;
  productHoldingMarketValueAmount: number;
  profitLossRealizedAmount: number | null;
  profitLossRealizedIncludeIncomeAmount: number | null;
  profitLossRealizedIncludeIncomePercent: number | null;
  profitLossRealizedPercent: number | null;
  profitLossUnrealizedAmount: number | null;
  profitLossUnrealizedIncludeIncomeAmount: number | null;
  profitLossUnrealizedIncludeIncomePercent: number | null;
  profitLossUnrealizedPercent: number | null;
}

export interface SessionInformation {
  httpSessionId: string | null;
  recordUpdateLastDateTime: number;
  requestIdentificationNumber: string;
}

export interface SortingCriterion {
  sortField: string;
  sortOrder: string;
}

export interface SubPortfolioDetailInformation {
  holdingBalanceTotalTypeCode: string;
  priceLastUpdateDateTime: string;
  productDashboardSubTypeCode: string;
  productDashboardTypeCode: string;
  productHoldingMarketValuePercent: number | null;
  subPortfolioDetailMultipleCurrencyInformation: PortfolioDetailMultipleCurrencyInformation[];
  timeZoneDisplayCode: string;
}

export interface WatchlistDetailInformation {
  watchListName: string;
  watchListServiceIdentifier: string;
  watchlistItemInformation: WatchlistItemInformation[];
}

export interface WatchlistItemInformation {
  countryISOCode: string;
  countryProductTradableCode: string;
  currencyFromCode: string;
  currencyISOToCode: string;
  currencyProductCode: string;
  currencyToCode: string;
  groupMemberCode: string;
  productAlternativeNumber: string;
  productCode: string;
  productCodeAlternativeClassificationCode: string;
  productDashboardSubTypeCode: string;
  productDashboardTypeCode: string;
  productIdInformation: ProductIDInformation[];
  productName: string;
  productShortName: string;
  productStatusCode: string;
  productSubtypeCode: string;
  productTypeCode: string;
  productXRayInformation: ProductXRayInformation[];
}
