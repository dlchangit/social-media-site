export interface TransactionHistoryResponse {
  reasonCodes: any[];
  responseCode: string;
  sessionInformation: SessionInformation;
  accountFilterInformation: AccountFilterInformation[];
  accountGroupInformation: AccountGroupInformation[];
  coreReserveArea: any[];
  localFieldsArea: any[];
  paginationResponse: PaginationResponse;
  secondaryHolder: any[];
  sortingCriteria: any[];
  transactionDetailInformation: TransactionDetailInformation[];
}

export interface AccountFilterInformation {
  accountBenchmarkCodes: any[];
  accountControlNumber: null;
  accountFilterMultipleCurrencyInformation: AccountFilterMultipleCurrencyInformation[];
  accountGroupIdentifier: null;
  accountListInformations: any[];
  accountModelTypeCode: null;
  accountNickName: AccountNickName;
  accountNumber: string;
  accountOwnerInformation: any[];
  accountProductTypeCode: null | string;
  accountSegmentText: null;
  accountStatusCode: string;
  accountTypeCode: AccountTypeCode;
  countryInvestmentAccountCode: null;
  currencyAccountCode: CurrencyCode;
  groupMemberInvestmentAccountCode: null;
  jointAccountIndicator: string;
  jointRequestCustomerIndicator: string;
}

export interface AccountFilterMultipleCurrencyInformation {
  accountMarketValueAmount: number;
  currencyAccountMarketValueCode: CurrencyCode;
  currencyTypeCode: CurrencyTypeCode;
}

export enum CurrencyCode {
  Cny = 'CNY',
  Hkd = 'HKD',
  Usd = 'USD',
}

export enum CurrencyTypeCode {
  Account = 'ACCOUNT',
  Cny = 'CNY',
  Local = 'LOCAL',
  Product = 'PRODUCT',
  Usd = 'USD',
}

export enum AccountNickName {
  CustIa117097 = 'CUST IA117097',
  CustomerIa117097 = 'CUSTOMER IA117097',
}

export enum AccountTypeCode {
  SEC = 'SEC',
}

export interface AccountGroupInformation {
  accountGroupMultipleCurrencyInformation: AccountGroupMultipleCurrencyInformation[];
  accountListInformation: AccountListInformation[];
  cardAccountInformation: any[];
  dashboardAccountGroupIdentifier: string;
  dashboardAccountSubGroupIdentifier: string;
  insuranceAccountInformation: any[];
  loanMortgageAccountInformation: any[];
}

export interface AccountGroupMultipleCurrencyInformation {
  accountCashMarketValueAmount: null;
  accountInvestmentMarketValueAmount: null;
  accountMarketValueAmount: number;
  currencyAccountCashMarketValueCode: null;
  currencyAccountInvestmentMarketValueCode: null;
  currencyAccountMarketValueCode: CurrencyCode;
  currencyProductHoldingBookValueAmountCode: CurrencyCode;
  currencyProfitLossUnrealizedAmountCode: CurrencyCode;
  currencyTypeCode: CurrencyTypeCode;
  productHoldingBookValueAmount: number;
  profitLossUnrealizedAmount: number;
  profitLossUnrealizedPercent: number;
}

export interface AccountListInformation {
  accountControlNumber: null;
  accountGroupIdentifier: null;
  accountNickName: AccountNickName;
  accountNumber: string;
  accountProductTypeCode: null | string;
  accountTypeCode: AccountTypeCode;
  countryInvestmentAccountCode: null;
  currencyAccountCode: CurrencyCode;
  groupMemberInvestmentAccountCode: null;
}

export interface PaginationResponse {
  endDetail: string;
  numberOfRecords: number;
  pagingDirectionCode: string;
  startDetail: string;
  totalNumberOfRecords: number;
}

export interface SessionInformation {
  httpSessionId: null;
  recordUpdateLastDateTime: number;
  requestIdentificationNumber: string;
}

export interface TransactionDetailInformation {
  accountControlNumber: null;
  accountGroupIdentifier: null;
  accountNickName: AccountNickName;
  accountNumber: string;
  accountProductTypeCode: null | string;
  accountTypeCode: AccountTypeCode;
  allowBuyAmountProductIndicator: string;
  allowBuyProductIndicator: string;
  allowBuyUnitProductIndicator: string;
  allowRolloverIndicator: null;
  allowSellAmountProductIndicator: string;
  allowSellMonthlyInvestmentProgramAmountProductIndicator: string;
  allowSellMonthlyInvestmentProgramUnitProductIndicator: string;
  allowSellProductIndicator: string;
  allowSellUnitProductIndicator: string;
  allowSwitchInAmountProductIndicator: string;
  allowSwitchInProductIndicator: string;
  allowSwitchInUnitProductIndicator: string;
  allowSwitchOutAmountProductIndicator: string;
  allowSwitchOutProductIndicator: string;
  allowSwitchOutUnitProductIndicator: string;
  allowTradeMonthlyInvestmentProgramProductIndicator: string;
  allowViewOrderDetailIndicator: string;
  bookCostEditRemarkCodes: null;
  bookCostEditRemarkText: null;
  chargeTransactionCollectSettlementCurrencyAmount: null;
  countryInvestmentAccountCode: null;
  countryProductTradableCode: ProductTradableCode;
  currencyAccountCode: CurrencyCode;
  currencyChargeTransactionCollectSettlementCode: null;
  currencyLinkDepositCode: null;
  currencyPrincipalCode: CurrencyCode | null;
  currencyPrincipalPortfolioCode: null;
  currencyPrincipalSettlementCode: null;
  currencyProductCode: CurrencyCode;
  currencyProductDealPriceCode: CurrencyCode | null;
  currencyProductExpiryAmoutCode: CurrencyCode;
  currencyProductNominalValueAmountCode: CurrencyCode;
  currencySettlementCode: CurrencyCode;
  exchangeBreakEvenRate: null;
  exchangeInitialRate: null;
  exchangeRateFixDate: null;
  exchangeSpotRate: null;
  exchangeTriggerRate: null;
  executionPriceSuspectTypeCode: null;
  fundSettlementCurrencyOptionCode: null;
  groupMemberInvestmentAccountCode: null;
  instrumentUnderlyingName: null;
  investmentStartDate: number | null;
  lotHoldingNumber: string;
  markToMarketIndicator: string;
  newBookCost: NewBookCost;
  originalBookCost: OriginalBookCost;
  principalAmount: number | null;
  principalPortfolioCurrencyAmount: null;
  principalSettlementCurrencyAmount: null;
  productDashboardSubTypeCode: string;
  productDashboardTypeCode: ProductTypeCode;
  productDealPriceAmount: number | null;
  productDepositHoldingCode: null;
  productExecutedTransactionQuantityCount: number | null;
  productExpiryAmount: number;
  productInvestmentDataStoreNumber: string;
  productKey: ProductKey[];
  productMaturityDate: null;
  productName: string;
  productNominalValueAmount: number;
  productPeriodText: null;
  productPriceDivisorAmount: number;
  productShortName: string;
  productStatusCode: string;
  productSubtypeCode: string;
  productTypeCode: ProductTypeCode;
  settlementDateTime: number;
  settlementFxRate: number;
  staffId: null;
  timeZoneDisplayCode: string;
  tradeAsDifferentCurrencyIndicator: string;
  transactionDateTime: number;
  transactionDetailMultipleCurrencyInformation: TransactionDetailMultipleCurrencyInformation[];
  transactionNarrativeText: null;
  transactionReferenceNumber: string;
  transactionSettlementAmount: number;
  transactionStatusCode: null;
  transactionTypeCode: string;
  yieldAnnualMinimumPercent: null;
  yieldAnnualPotentialPercent: null;
  monthlyAverageHoldingBalance: null;
  currencyMonthlyAverageHoldingBalance: null;
}

export enum ProductTradableCode {
  Hk = 'HK',
}

export interface NewBookCost {
  currencyProductHoldingBookValueAmountCode: null;
  currencyProductHoldingBookValueLocalAmountCode: null;
  productHoldingBookValueAmount: null;
  productHoldingBookValueLocalAmount: null;
}

export interface OriginalBookCost {
  currencyProductHoldingBookValueAmountCode: CurrencyCode;
  currencyProductHoldingBookValueLocalAmountCode: CurrencyCode;
  productHoldingBookValueAmount: number;
  productHoldingBookValueLocalAmount: number;
}

export enum ProductTypeCode {
  Ut = 'UT',
}

export interface ProductKey {
  currencyProductCode: CurrencyCode;
  productAlternativeNumber: string;
  productCodeAlternativeClassCode: string;
  productTradableCode: ProductTradableCode;
  productTypeCode: ProductTypeCode;
}

export interface TransactionDetailMultipleCurrencyInformation {
  currencyProfitLossRealizedAmountCode: CurrencyCode;
  currencyTypeCode: CurrencyTypeCode;
  profitLossRealizedAmount: number;
  profitLossRealizedPercent: number;
}
