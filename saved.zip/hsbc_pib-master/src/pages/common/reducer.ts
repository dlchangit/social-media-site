import {
  SET_SUMMARY,
  SET_SYSTEM_EMPTY,
  SET_SYSTEM_ERROR,
  SET_SYSTEM_LOADING,
  SET_SYSTEM_LOCALE,
} from './saga';
import { R18Response } from '../../@types/R18Response';
import channelData from '../../json-config/channelData.json';
import wdConfig from '../../json-config/wdConfig.json';
import commonConfig from '../../json-config/commonConfig.json';

export interface ActionPayload extends Record<string, any> {
  type: string;
  payload?: any;
}

export enum LOCALE {
  en = 'en',
  zh_cn = 'zh_cn',
  zh_hk = 'zh_hk',
}

export interface SystemState {
  locale: LOCALE;
  timezone: string;
  loading: boolean;
  error: string;
  //TODO for demo empty state, remove after integrating the API
  empty: boolean;
  summary?: R18Response;
  cacheDateTime?: string;

  //TODO remove once use actual config
  channelData: typeof channelData;

  //TODO remove once use actual config
  wdConfig: typeof wdConfig;

  //TODO remove once use actual config
  commonConfig: typeof commonConfig;
}

const initialState: SystemState = {
  locale: LOCALE.en,
  timezone: 'HKT',
  loading: false,
  error: '',
  //TODO for demo empty state, remove after integrating the API
  empty: false,
  summary: undefined,
  cacheDateTime: undefined,
  channelData,
  wdConfig,
  commonConfig,
};

export default function reducer(state = initialState, action: ActionPayload): SystemState {
  switch (action.type) {
    case SET_SYSTEM_LOCALE:
      return { ...state, locale: action.payload };
    case SET_SYSTEM_LOADING:
      return { ...state, loading: action.payload };
    case SET_SYSTEM_ERROR:
      return { ...state, error: action.payload };
    case SET_SYSTEM_EMPTY:
      return { ...state, empty: action.payload };
    case SET_SUMMARY:
      return { ...state, summary: action.payload, cacheDateTime: new Date().toISOString() };
    default:
      return state;
  }
}
