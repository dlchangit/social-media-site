import { all, call, put, takeLatest } from 'redux-saga/effects';
import { ActionPayload, SystemState } from './reducer';
import { AllEffect, ForkEffect } from '@redux-saga/core/effects';
import { useSelector } from 'react-redux';
import { RootState } from '../../store';
import { AxiosResponse } from 'axios';
import { R18Response } from '../../@types/R18Response';
import { fetchWrapper } from '../../utils/fetch';

export const SET_SYSTEM_LOCALE = 'SET_SYSTEM_LOCALE';
export const SET_SYSTEM_LOADING = 'SET_SYSTEM_LOADING';
export const SET_SYSTEM_ERROR = 'SET_SYSTEM_ERROR';
export const SET_SYSTEM_EMPTY = 'SET_SYSTEM_EMPTY';
export const FETCH_SUMMARY = 'FETCH_SUMMARY';
export const SET_SUMMARY = 'SET_SUMMARY';

export function setSystemLocale(payload: SystemState['locale']): ActionPayload {
  return { type: SET_SYSTEM_LOCALE, payload };
}

export function setSystemError(payload: SystemState['error']): ActionPayload {
  return { type: SET_SYSTEM_ERROR, payload };
}

export function setSystemEmpty(payload: SystemState['empty']): ActionPayload {
  return { type: SET_SYSTEM_EMPTY, payload };
}

export function fetchSummary(): ActionPayload {
  return { type: FETCH_SUMMARY, payload: '/api/summary' };
}

function* doFetchSummary(action: ActionPayload) {
  try {
    yield put({ type: SET_SYSTEM_LOADING, payload: true });
    yield put({ type: SET_SYSTEM_ERROR, payload: undefined });
    const response: AxiosResponse<R18Response> = yield call(fetchWrapper, action.payload);
    yield put({ type: SET_SUMMARY, payload: response.data });
  } catch (e) {
    yield put({ type: SET_SYSTEM_ERROR, payload: e.message });
  } finally {
    yield put({ type: SET_SYSTEM_LOADING, payload: false });
  }
}

export function* watchFetchSummary(): Generator<ForkEffect> {
  yield takeLatest(FETCH_SUMMARY, doFetchSummary);
}

export const selectSystem = (): SystemState => useSelector((state: RootState) => state.system);

export default function* rootSaga(): Generator<AllEffect<any>> {
  yield all([watchFetchSummary()]);
}
