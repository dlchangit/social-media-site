import { AxiosResponse } from 'axios';
import { all, call, put, takeLatest } from 'redux-saga/effects';
import { TransactionHistoryState } from './reducer';
import { SET_SYSTEM_ERROR } from '../common/saga';
import { ActionPayload } from '../common/reducer';
import { AllEffect, ForkEffect } from '@redux-saga/core/effects';
import { useSelector } from 'react-redux';
import { RootState } from '../../store';
import { fetchWrapper } from '../../utils/fetch';
import { TransactionHistoryResponse } from '../../@types/TransactionHistoryResponse';

export const SET_TRANSACTION_HISTORY = 'SET_TRANSACTION_HISTORY';
export const FETCH_TRANSACTION_HISTORY = 'FETCH_TRANSACTION_HISTORY';
export const FETCHING_TRANSACTION_HISTORY = 'FETCHING_TRANSACTION_HISTORY';
export const SET_TRANSACTION_HISTORY_PREFERENCE = 'SET_TRANSACTION_HISTORY_PREFERENCE';

export function fetchTransactionHistory(url: string): ActionPayload {
  return { type: FETCH_TRANSACTION_HISTORY, payload: url };
}

export function setTransactionHistoryPreference(
  payload: TransactionHistoryState['preference']
): ActionPayload {
  return { type: SET_TRANSACTION_HISTORY_PREFERENCE, payload };
}

function* doFetchTransactionHistory(action: ActionPayload) {
  try {
    yield put({ type: FETCHING_TRANSACTION_HISTORY, payload: true });
    const response: AxiosResponse<TransactionHistoryResponse> = yield call(
      fetchWrapper,
      action.payload
    );
    yield put({ type: SET_TRANSACTION_HISTORY, payload: response.data });
    yield put({ type: FETCHING_TRANSACTION_HISTORY, payload: false });
  } catch (e) {
    yield put({ type: SET_SYSTEM_ERROR, payload: e.message });
    yield put({ type: FETCHING_TRANSACTION_HISTORY, payload: false });
  }
}

export function* watchFetchTransactionHistory(): Generator<ForkEffect> {
  yield takeLatest(FETCH_TRANSACTION_HISTORY, doFetchTransactionHistory);
}

export const selectTransactionHistory = (): TransactionHistoryState =>
  useSelector((state: RootState) => state.transaction);

export default function* rootSaga(): Generator<AllEffect<any>> {
  yield all([watchFetchTransactionHistory()]);
}
