import React, { useState } from 'react';

import css from './Header.module.scss';
import {
  IconFilter,
  IconModal,
  IconRefresh,
  IconTooltip,
  IconTooltipActive,
  Typography,
  Button,
  ErrorBanner,
  Space,
  Modal,
  Tooltip,
  Input,
  InputDateRange,
  DropdownItem,
  MultipleDropdown,
  SingleDropdown,
  ChevronAnchor,
  PrimaryTitle,
  GlobalHeader,
} from '../../components';
import { addYears, format } from 'date-fns';
import cn from 'classnames';
import { useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { AccountConfig, accountTypeConfig, mask } from '../../utils/account';
import { setTime } from '../../utils/date';
import config from '../../config/HK/common/config/pib';
import { useInView } from 'react-intersection-observer';
import { selectSystem } from '../common/saga';
import { fetchTransactionHistory, selectTransactionHistory } from './saga';

const countryData = [
  { value: 'afghanistan', label: 'Afghanistan' },
  { value: 'burundi', label: 'Burundi' },
  { value: 'cameroon', label: 'Cameroon' },
  { value: 'canada', label: 'Canada' },
  { value: 'czech_republic', label: 'Czech Republic' },
  { value: 'denmark', label: 'Denmark' },
  { value: 'hong_kong', label: 'Hong Kong' },
  { value: 'iceland', label: 'Iceland' },
  { value: 'india', label: 'India' },
  { value: 'japan', label: 'Japan' },
];

export interface StickyHeaderProp {
  onAccountChange?: () => void;
}

type State = {
  orderPlacedVia: string;
  transactionType: string;
  productType: string;
  productName: string;
  dateRange: {
    from: Date;
    to: Date;
  };
};

export const Header: React.FC<StickyHeaderProp> = () => {
  const { t } = useTranslation();

  const dispatch = useDispatch();
  const systemState = selectSystem();
  const transactionHistoryState = selectTransactionHistory();
  const accountList = (transactionHistoryState?.root?.accountGroupInformation ?? [])
    .flatMap((it) => it.accountListInformation)
    .map((it) => {
      return {
        ...it,
        config: accountTypeConfig(it.accountTypeCode, it.accountProductTypeCode),
      };
    })
    .filter((it) => {
      return it.config !== undefined && it.config.isAllowSelect === 'YES';
    })
    .map((it) => {
      const config = it.config as AccountConfig;
      return {
        value: it.accountNumber,
        label:
          mask(config.acctFormat, it.accountNumber) +
          ' ' +
          (it.accountProductTypeCode !== null ? t(it.accountProductTypeCode) : ''),
      };
    })
    .slice(0, 1);

  const { ref: scrollRef, inView: notScrolled } = useInView({
    delay: 100,
  });
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [selected, setSelected] = useState<State>({
    orderPlacedVia: 'all',
    productType: 'all',
    transactionType: 'all',
    productName: '',
    dateRange: {
      from: setTime(addYears(new Date(), -3), 0, 0),
      to: setTime(new Date(), 0, 0),
    },
  });
  const [helpVisible, setHelpVisible] = useState(false);

  const onReset = () => {
    setSelected({
      orderPlacedVia: 'all',
      transactionType: 'all',
      productType: 'all',
      productName: '',
      dateRange: {
        from: setTime(addYears(new Date(), -3), 0, 0),
        to: setTime(new Date(), 0, 0),
      },
    });
  };

  const setPartialSelected = (partials: Partial<State>) => {
    setSelected((prevState) => ({
      ...prevState,
      ...partials,
    }));
  };

  const lastUpdated = () => {
    return (
      <Space align={'center'} className={cn({ [css.lastUpdated]: notScrolled })}>
        {transactionHistoryState.cacheDateTime && (
          <span>
            <span className={css.block}>Last updated:</span>
            <span className={css.block}>
              {format(new Date(transactionHistoryState.cacheDateTime), 'HH:mm d LLL y')} (HKT)
            </span>
          </span>
        )}
        <Button
          icon={<IconRefresh />}
          style={{ marginLeft: 8 }}
          onClick={() => {
            dispatch(fetchTransactionHistory('/api/transaction-history'));
          }}
        />
      </Space>
    );
  };
  const renderModal = () => {
    const modalSections: {
      header: string;
      contents: { title: string; description: string }[];
    }[] = t('transactionHistory.help.modal_sections', { returnObjects: true });
    return modalSections.map((it, si) => {
      return (
        <div key={si} className={css.mt24}>
          <PrimaryTitle>{it.header}</PrimaryTitle>
          {it.contents.map(({ title, description }, ci) => (
            <div className={css.mt12} key={ci}>
              <Typography size={5} weight={'medium'}>
                {title}
              </Typography>
              <div className={css.mt4}>{description}</div>
            </div>
          ))}
        </div>
      );
    });
  };
  const renderDropdown = () => {
    if (systemState.error) {
      return <ErrorBanner className={css.mt24}>{systemState.error}</ErrorBanner>;
    }
    if (transactionHistoryState.error) {
      return <ErrorBanner className={css.mt24}>{transactionHistoryState.error}</ErrorBanner>;
    }

    return (
      <div
        className={cn(
          { [css.menuContentSticky]: !notScrolled },
          { [css.largeView]: !notScrolled },
          { [css.menuOpen]: mobileMenuOpen }
        )}
      >
        <Space className={cn(css.menuRow, css.firstRow)} align={'end'} wrap={true}>
          <Space className={cn(css.account)} wrap={true}>
            <Typography size={6}>Account(s):</Typography>
            <MultipleDropdown
              className={css.dropdown}
              allOption={'All'}
              placeholder={'SELECT'}
              values={accountList.map((it) => it.value)}
            >
              {accountList.map((it, index) => (
                <DropdownItem key={index} value={it.value}>
                  {it.label}
                </DropdownItem>
              ))}
            </MultipleDropdown>
          </Space>
          <Space className={cn(css.dateRange, css.gutter)} wrap={true}>
            <Typography size={6}>Date range:</Typography>
            <div className={css.dropdown}>
              <InputDateRange
                onChange={(dateRange) => setPartialSelected({ dateRange })}
                max={setTime(new Date(), 23, 59)}
                min={setTime(addYears(new Date(), -3), 0, 0)}
                value={selected.dateRange}
                formatter={({ from, to }) =>
                  `${format(from, 'dd/MM/yyyy')} to ${format(to, 'dd/MM/yyyy')}`
                }
              />
            </div>
          </Space>
          <Space wrap={true} className={cn(css.orderPlaced, css.gutter)}>
            <Typography size={6}>Order placed via:</Typography>
            <SingleDropdown
              className={css.dropdown}
              value={selected.orderPlacedVia}
              onChange={(value) => setPartialSelected({ orderPlacedVia: value })}
              placeholder={''}
            >
              {config.transactionHistory.filter.orderPlacedVia.map((it) => (
                <DropdownItem key={it} value={it}>
                  {t(`transactionHistory.orderPlacedVia.${it}`)}
                </DropdownItem>
              ))}
            </SingleDropdown>
          </Space>
        </Space>
        <Space className={cn(css.menuRow, css.secondRow)} align={'end'} wrap={true}>
          <Space wrap={true} className={cn(css.transactionType)}>
            <Typography size={6}>Transaction type:</Typography>
            <SingleDropdown
              className={css.dropdown}
              value={selected.transactionType}
              onChange={(value) => setPartialSelected({ transactionType: value })}
              placeholder={''}
            >
              {config.transactionHistory.filter.transactionType.map((it) => (
                <DropdownItem key={it} value={it}>
                  {t(`transactionHistory.transactionType.${it}`)}
                </DropdownItem>
              ))}
            </SingleDropdown>
          </Space>
          <Space wrap={true} className={cn(css.productType, css.gutter)}>
            <Typography size={6}>Product Type:</Typography>
            <SingleDropdown
              className={css.dropdown}
              value={selected.productType}
              onChange={(value) => setPartialSelected({ productType: value })}
              placeholder={''}
            >
              {config.transactionHistory.filter.productType.map((it) => (
                <DropdownItem key={it} value={it}>
                  {t(`transactionHistory.productType.${it}`)}
                </DropdownItem>
              ))}
            </SingleDropdown>
          </Space>

          <Space wrap={true} className={cn(css.productName, css.gutter)}>
            <Typography size={6}>Product Name:</Typography>
            <Input
              className={css.dropdown}
              onChange={(productName) => {
                setPartialSelected({ productName: productName.toString() });
              }}
              type={'text'}
              value={selected.productName}
              freeText={true}
              autoCompleteCallback={async (keyword) => {
                return countryData
                  .filter((it) => it.label.toLowerCase().startsWith(keyword.toLowerCase()))
                  .map((it) => it.label);
              }}
            />
          </Space>

          <Space className={cn(css.buttonGroup)}>
            <Button secondary>Apply</Button>
            <Button onClick={onReset} htmlType={'reset'}>
              Reset
            </Button>
          </Space>

          <Space className={css.help} justify={'end'}>
            <Button icon={<IconModal />} type={'raw'} onClick={() => setHelpVisible(true)}>
              {t('transactionHistory.help.button')}
            </Button>
          </Space>

          <Modal
            visible={helpVisible}
            onClose={() => setHelpVisible(false)}
            header={t('transactionHistory.help.modal_header')}
          >
            {renderModal()}
          </Modal>
        </Space>
      </div>
    );
  };
  return (
    <div className={css.headerContainer}>
      <GlobalHeader />
      <div ref={scrollRef} className={css.controlSticky} />
      <div className={cn({ [css.menuSticky]: !notScrolled })}>
        <Typography
          size={4}
          weight={'light'}
          className={cn(css.backLink, { [css.largeView]: !notScrolled })}
        >
          <ChevronAnchor href={'/#'} direction={'backward'}>
            {t('common.backToMyWealthDashboard')}
          </ChevronAnchor>
        </Typography>
        <Space
          className={cn({ [css.menuControl]: !notScrolled })}
          justify={'between'}
          align={'center'}
          wrap={true}
        >
          <div className={cn({ [css.largeView]: !notScrolled })}>
            <Typography size={2} weight={'light'}>
              Transaction history
            </Typography>
            <Tooltip
              className={css.ml8}
              direction={'bottom-center'}
              message={'Only Hong Kong transaction records are available to view.'}
              activeChildren={<IconTooltipActive />}
            >
              <IconTooltip />
            </Tooltip>
          </div>
          <div className={cn(css.smallView, { [css.hide]: notScrolled })}>
            <Button icon={<IconFilter />} onClick={() => setMobileMenuOpen(!mobileMenuOpen)} />
          </div>
          {lastUpdated()}
        </Space>
        {renderDropdown()}
      </div>

      <div
        className={cn(css.smallView, css.menuControlHeight, {
          [css.hide]: notScrolled,
        })}
      />

      <Space className={css.helpSmallVersion} justify={'end'}>
        <Button icon={<IconModal />} type={'raw'} onClick={() => setHelpVisible(true)}>
          {t('transactionHistory.help.button')}
        </Button>
      </Space>
    </div>
  );
};
