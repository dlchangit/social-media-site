import { FETCHING_TRANSACTION_HISTORY, SET_TRANSACTION_HISTORY } from './saga';
import { TransactionHistoryResponse } from '../../@types/TransactionHistoryResponse';
import { ActionPayload } from '../common/reducer';

export interface TransactionHistoryState {
  root?: TransactionHistoryResponse;
  loading: boolean;
  error?: string;
  cacheDateTime?: string;
  preference?: {
    accounts?: string[];
    currency?: string;
  };
}

const initialState: TransactionHistoryState = {
  root: undefined,
  cacheDateTime: undefined,
  loading: false,
  error: undefined,
  preference: undefined,
};

export default function reducer(
  state = initialState,
  action: ActionPayload
): TransactionHistoryState {
  switch (action.type) {
    case SET_TRANSACTION_HISTORY:
      return { ...state, root: action.payload, cacheDateTime: new Date().toISOString() };
    case FETCHING_TRANSACTION_HISTORY:
      return { ...state, loading: action.payload };
    default:
      return state;
  }
}
