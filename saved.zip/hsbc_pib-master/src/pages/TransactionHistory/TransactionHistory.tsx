import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import css from './TransactionHistory.module.scss';
import { Header } from './Header';
import { useTranslation } from 'react-i18next';

import { format } from 'date-fns';
import { formatDigits } from '../../utils/math';
import config from '../../config/HK/common/config/pib';
import { TransactionDetailInformation } from '../../@types/TransactionHistoryResponse';
import { selectSystem } from '../common/saga';
import { fetchTransactionHistory, selectTransactionHistory } from './saga';
import {
  Disclaimers,
  EmptyView,
  ErrorView,
  LoadingView,
  Pagination,
  SortableTable,
  Tag,
  Typography,
} from '../../components';

const t_prefix = 'transactionHistory';

export default function TransactionHistory(): JSX.Element {
  const transactionHistoryState = selectTransactionHistory();
  const systemState = selectSystem();
  const dispatch = useDispatch();

  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);

  const { t } = useTranslation();

  useEffect(() => {
    if (!transactionHistoryState.cacheDateTime) {
      dispatch(fetchTransactionHistory('/api/transaction-history'));
    }
  }, [page, recordPerPage]);

  return (
    <div className={css.container}>
      <Header />
      <SortableTable<TransactionDetailInformation>
        className={css.mt20}
        fontSize={6}
        data={transactionHistoryState.root?.transactionDetailInformation ?? []}
        emptyView={
          (transactionHistoryState.root?.transactionDetailInformation?.length ?? 0) === 0 ? (
            <EmptyView message={t('transactionHistory.table.emptyMsg')} />
          ) : undefined
        }
        errorView={
          systemState.error || transactionHistoryState.error ? (
            <ErrorView message={t('transactionHistory.table.errorMsg')} />
          ) : undefined
        }
        loadingView={
          transactionHistoryState.loading ? (
            <LoadingView message={t('transactionHistory.table.loadingMsg')} />
          ) : undefined
        }
        columns={[
          {
            key: 'settlementDateTime',
            label: t('transactionHistory.table.header.settlementDate'),
            width: '13%',
            formatter(row) {
              return (
                <Typography size={5} weight={'light'}>
                  {format(row.settlementDateTime || row.transactionDateTime, 'dd MMM yyyy')}
                </Typography>
              );
            },
          },
          {
            key: 'productShortName',
            label: `${t('transactionHistory.table.header.productName')}\n(${t(
              'transactionHistory.table.header.transactionReferenceNo'
            )})`,
            width: '30%',
            formatter(row) {
              return (
                <Typography size={5} weight={'light'}>
                  {row.productShortName}{' '}
                  <Tag>
                    <Typography size={7}>{row.productTypeCode}</Typography>
                  </Tag>
                  <br />({row.transactionReferenceNumber})
                </Typography>
              );
            },
          },
          {
            key: 'transactionTypeCode',
            label: t('transactionHistory.table.header.transactionType'),
            formatter(row) {
              return (
                <Typography size={5} weight={'light'}>
                  {t(
                    `transactionHistory.transaction_type.${row.productTypeCode}_${row.transactionTypeCode}`
                  )}
                </Typography>
              );
            },
          },
          {
            key: 'lotHoldingNumber',
            label: `${t('transactionHistory.table.header.unitPrice')}\n(${t(
              'transactionHistory.table.header.noOfUnits'
            )})`,
            align: 'right',
            width: '13%',
            formatter(row) {
              const quantity = row.productExecutedTransactionQuantityCount
                ? `(${row.productExecutedTransactionQuantityCount})`
                : '';
              const unitPrice = `${row.currencyProductCode} ${formatDigits(
                row.productDealPriceAmount || 0,
                2
              )}`;

              return (
                <Typography size={5} weight={'light'}>
                  {row.productDealPriceAmount ? (
                    <>
                      {unitPrice}
                      <br />
                      {quantity}
                    </>
                  ) : (
                    '-'
                  )}
                </Typography>
              );
            },
          },
          {
            key: 'chargeTransactionCollectSettlementCurrencyAmount',
            label: t('transactionHistory.table.header.feesAndCharges'),
            align: 'right',
            formatter(row) {
              const val = row.chargeTransactionCollectSettlementCurrencyAmount;
              const result =
                val != null ? `(${row.chargeTransactionCollectSettlementCurrencyAmount})` : '-';
              return (
                <Typography size={5} weight={'light'}>
                  {result}
                </Typography>
              );
            },
          },
          {
            key: 'transactionSettlementAmount',
            label: t('transactionHistory.table.header.settlementAmount'),
            align: 'right',
            formatter(row) {
              const result = `${row.currencySettlementCode} ${formatDigits(
                row.transactionSettlementAmount
              )}`;
              return (
                <Typography size={5} weight={'light'}>
                  {result}
                </Typography>
              );
            },
          },
          {
            key: 'staffId',
            label: t(`${t_prefix}.table.header.orderPlacedVia`),
            formatter(row) {
              return (
                <Typography size={5} weight={'light'}>
                  {row.productMaturityDate}
                </Typography>
              );
            },
          },
        ]}
      />
      <Pagination
        className={css.mt28}
        totalPages={3}
        currentPage={page}
        recordsPerPage={config.transactionHistory.showRecords}
        onPageChange={setPage}
        onRecordsPerPageChange={setRecordPerPage}
      />
      <Disclaimers
        className={css.mt40}
        title={t(`${t_prefix}.disclaimers.title`)}
        content={t(`${t_prefix}.disclaimers.content`)}
      />
    </div>
  );
}
