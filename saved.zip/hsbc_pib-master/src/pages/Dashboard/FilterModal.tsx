import React, { useState } from 'react';
import { Button } from '../../components/Button';
import { IconFilter } from '../../components/Icon';
import { Modal } from '../../components/Modal';
import { Space } from '../../components/Space';

export const FilterModal: React.FC<React.HTMLAttributes<HTMLDivElement>> = (props) => {
  const [visible, setVisible] = useState(false);

  const onOpen = () => {
    setVisible(true);
  };

  const onClose = () => {
    setVisible(false);
  };

  return (
    <div {...props}>
      <Button type={'raw'} icon={<IconFilter />} onClick={onOpen}>
        Filter
      </Button>
      <Modal visible={visible} onClose={onClose} header={'Header'}>
        <Space direction={'vertical'}>
          <div>
            The Laser Interferometer Gravitational-Wave Observatory (LIGO) is a large-scale physics
            experiment and observatory to detect cosmic gravitational waves and to develop
            gravitational-wave observations as an astronomical tool.[1] Two large observatories were
            built in the United States with the aim of detecting gravitational waves by laser
            interferometry. These observatories use mirrors spaced four kilometers apart which are
            capable of detecting a change of less than one ten-thousandth the charge diameter of a
            proton.[2] The initial LIGO observatories were funded by the National Science Foundation
            (NSF) and were conceived, built and are operated by Caltech and MIT.[3][4] They
            collected data from 2002 to 2010 but no gravitational waves were detected. The Advanced
            LIGO Project to enhance the original LIGO detectors began in 2008 and continues to be
            supported by the NSF, with important contributions from the United Kingdom&#39;s Science
            and Technology Facilities Council, the Max Planck Society of Germany, and the Australian
            Research Council.[5][6] The improved detectors began operation in 2015. The detection of
            gravitational waves was reported in 2016 by the LIGO Scientific Collaboration (LSC) and
            the Virgo Collaboration with the international participation of scientists from several
            universities and research institutions. Scientists involved in the project and the
            analysis of the data for gravitational-wave astronomy are organized by the LSC, which
            includes more than 1000 scientists worldwide,[7][8][9] as well as 440,000 active
            Einstein@Home users as of December 2016.[10] LIGO is the largest and most ambitious
            project ever funded by the NSF.[11][12] In 2017, the Nobel Prize in Physics was awarded
            to Rainer Weiss, Kip Thorne and Barry C. Barish &quot;for decisive contributions to the
            LIGO detector and the observation of gravitational waves&quot;.[13]
          </div>
          <Space style={{ marginTop: 24 }}>
            <Button onClick={onClose} primary>
              Save
            </Button>
            <Button style={{ marginLeft: 12 }} onClick={onClose}>
              Cancel
            </Button>
          </Space>
        </Space>
      </Modal>
    </div>
  );
};
