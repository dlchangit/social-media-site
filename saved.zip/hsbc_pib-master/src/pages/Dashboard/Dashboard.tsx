import React from 'react';
import './Dashboard.module.scss';
import css from './Dashboard.module.scss';
import { useTranslation } from 'react-i18next';

import arrowUp from '../../components/CurrencyAmount/icn_position_up_16x8@2x.png';
import { formatDigits } from '../../utils/math';
import { ArticleHolding, GenericNews } from '../../demo/InsightDemo';

import {
  Accordion,
  Carousel,
  ChevronAnchor,
  CurrencyAmount,
  Divider,
  EmptyResult,
  HealthScoreCard,
  Holding,
  HoldingChart,
  ImageAssetManagement,
  ImageDataChart,
  ImageInvestment,
  ImageLiquidity,
  Panel,
  PrimaryTitle,
  Space,
  StickyHeader,
  Typography,
} from '../../components';

import { FilterModal } from './FilterModal';

export default function Dashboard(): JSX.Element {
  const { t } = useTranslation();

  const labels = [
    {
      id: 'unit_trusts',
      label: 'Unit Trusts',
    },
    {
      id: 'stock',
      label: 'Stock',
    },
    {
      id: 'bond_and_cds',
      label: 'Bond and CDs',
    },
    {
      id: 'eli_and_structured_notes',
      label: 'ELI and Structured Notes',
    },
    {
      id: 'capital_protected_investments',
      label: 'Capital Protected Investments',
    },
    {
      id: 'deposit_plus',
      label: 'Deposit Plus',
    },
    {
      id: 'cash',
      label: 'Cash',
    },
  ];

  const data = [
    {
      id: 'unit_trusts',
      value: '0.32',
    },
    {
      id: 'stock',
      value: '0.2',
    },
    {
      id: 'bond_and_cds',
      value: '0.16',
    },
    {
      id: 'eli_and_structured_notes',
      value: '0.12',
    },
    {
      id: 'capital_protected_investments',
      value: '0.1',
    },
    {
      id: 'deposit_plus',
      value: '0.05',
    },
    {
      id: 'cash',
      value: '0.05',
    },
  ];

  return (
    <div className={css.container}>
      <StickyHeader />
      <Space align={'start'} className={css.mt40} wrap={true}>
        <div className={css.left}>
          <PrimaryTitle>{t('dashboard.holdings.title')}</PrimaryTitle>
          <Space className={css.currencyMargin}>
            <CurrencyAmount amount={120000} currency={'HKD'} label={'Total market value'} />
            <CurrencyAmount
              amount={120000}
              currency={'HKD'}
              showSign={true}
              label={'Total unrealised gain / loss'}
            />
            <CurrencyAmount
              amount={120000}
              currency={'HKD'}
              label={
                <ChevronAnchor href={'#realised-gain-loss'}>
                  Dividend / cash income in past 12 moths
                </ChevronAnchor>
              }
            />
          </Space>
          <Accordion className={css.collapse} defaultActiveKey={0}>
            <Panel
              header={
                <Space justify={'between'}>
                  <span>Investment</span>
                  <span>HKD {formatDigits(880000)}</span>
                </Space>
              }
            >
              <div style={{ paddingBottom: 20 }}>
                <div style={{ marginTop: 16 }}>Market Value</div>
                <Space justify={'between'} style={{ marginTop: 8 }}>
                  <div>
                    <Typography size={4}>HKD {formatDigits(880000)}</Typography>
                    <span className={css.prefix}>
                      <img src={arrowUp} alt="" />
                      <Typography size={6} weight={'medium'}>
                        +20000
                      </Typography>
                    </span>
                  </div>
                  <ChevronAnchor href={'/#'}>
                    {t('dashboard.links.analyzeMyPortfolio')}
                  </ChevronAnchor>
                </Space>
                <HoldingChart
                  id={'holding-chart-4'}
                  style={{ height: 200 }}
                  legendFormatter={(label, value) => {
                    return `${label} (${parseFloat(value) * 100}%)`;
                  }}
                  labels={labels}
                  data={data}
                />
                <ChevronAnchor href={'/'}>View detail</ChevronAnchor>
              </div>
            </Panel>
            <Panel header={'MPF'}>
              <div style={{ backgroundColor: '#eee', padding: 30 }}>
                <h1>Testing</h1>
              </div>
            </Panel>
          </Accordion>

          <Space justify={'between'} className={css.mt40}>
            <PrimaryTitle>My holdings&#39; performance highlights</PrimaryTitle>
            <FilterModal />
          </Space>
          <div className={css.mt12}>Information is calculated from unrealised gain/loss.</div>

          <Space>
            <Space
              direction={'vertical'}
              split={<Divider style={{ marginBottom: 12 }} />}
              style={{ width: 400, marginRight: 20 }}
            >
              <div style={{ marginTop: 20, marginBottom: 20 }}>
                <Typography size={4}>Top gainers</Typography>
              </div>
              <Holding
                stock={'Apple Inc.'}
                symbol={'AAPL'}
                currency={'HKD'}
                amount={100000.0}
                percentage={75.0}
              />
              <Holding
                stock="General Electric Company"
                symbol="GE"
                currency={'HKD'}
                amount={100000.0}
                percentage={33.3}
              />
              <Holding
                stock={'Apple Inc.'}
                symbol={'AAPL'}
                currency={'HKD'}
                amount={100000.0}
                percentage={20.1}
              />
            </Space>
            <Space direction={'vertical'} style={{ width: 400 }}>
              <div style={{ marginTop: 20, marginBottom: 20 }}>
                <Typography size={4}>Top losers</Typography>
              </div>
              <EmptyResult label={'No top losers at the moment.'} border={false} />
            </Space>
          </Space>

          <div className={css.mt40}>
            <PrimaryTitle>My portfolio health scores</PrimaryTitle>
            <div className={css.mt12}>
              Note: Certain portfolio analysis functions are only available in Hong Kong accounts.
            </div>
            <Space wrap={true} className={css.mt20}>
              <HealthScoreCard
                title={'Asset Allocation'}
                description={'Your Concentration of Global Equities '}
                img={<ImageLiquidity alt={''} />}
                percent={'35'}
                className={css.mr20}
              />
              <HealthScoreCard
                title={'Exposure'}
                description={'High concentration of assets in the United States'}
                img={<ImageDataChart alt={''} />}
                percent={'40'}
              />
            </Space>
            <Space wrap={true} className={css.mt20}>
              <HealthScoreCard
                title={'Risk'}
                description={'Your risk level is outside your recommended band'}
                img={<ImageInvestment alt={''} />}
                className={css.mr20}
              />
              <HealthScoreCard
                title={'Universe management'}
                description={'3 of your UT holdings are closed for subscription'}
                img={<ImageAssetManagement alt={''} />}
              />
            </Space>
            <div className={css.mt12}>
              <ChevronAnchor href={'/#'}>{t('dashboard.links.analyzeMyPortfolio')}</ChevronAnchor>
            </div>
          </div>
        </div>

        <div className={css.right}>
          <div>
            <PrimaryTitle>What&apos;s news?</PrimaryTitle>
            <Carousel
              className={css.mt32}
              anchorOfAll={
                <ChevronAnchor href={'/'} direction={false}>
                  View all
                </ChevronAnchor>
              }
            >
              <GenericNews />
              <ArticleHolding />
              <GenericNews />
              <ArticleHolding />
            </Carousel>
          </div>
        </div>
      </Space>
    </div>
  );
}
