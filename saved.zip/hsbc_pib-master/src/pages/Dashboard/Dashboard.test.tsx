import React from 'react';
import { render, screen } from '@testing-library/react';
import Dashboard from './Dashboard';
import '../../i18n/config';

class SVGPathElement extends HTMLElement {}
// @ts-ignore
window.SVGPathElement = SVGPathElement;

test('renders dashboard', () => {
  render(<Dashboard />);

  const linkElement = screen.getByText(/My Wealth Dashboard/i);
  expect(linkElement).toBeInTheDocument();
});
