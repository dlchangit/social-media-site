import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import css from './Drawer.module.css';
import cn from 'classnames';
import i18n from 'i18next';
import { Link } from 'react-router-dom';
import { Button, Checkbox, IconAnchor, Space } from '../../components';
import { selectSystem, setSystemEmpty, setSystemError, setSystemLocale } from '../common/saga';
import { LOCALE } from '../common/reducer';

export default function Drawer(): JSX.Element {
  const dispatch = useDispatch();
  const systemState = selectSystem();

  const [active, setActive] = useState(false);

  const keydownListener = (event: KeyboardEvent) => {
    if (event.key === 'F2') {
      setActive(!active);
    }
  };

  const changeLocale = (locale: LOCALE) => {
    i18n.changeLanguage(locale).then();
    dispatch(setSystemLocale(locale));
  };

  useEffect(() => {
    // dispatch(setAccount(r18));
    window.addEventListener('keydown', keydownListener, true);
    return () => {
      window.removeEventListener('keydown', keydownListener, true);
    };
  }, [active]);

  const cls = cn(css.drawer, { [css.active]: active });
  return (
    <div className={cls}>
      <Space direction={'vertical'}>
        <Link to={'/'} component={IconAnchor}>
          dashboard
        </Link>
        <Link to={'/transaction-history'} component={IconAnchor}>
          transaction history
        </Link>
        <Link to={'/realised-gain-loss'} component={IconAnchor}>
          realised gain/loss
        </Link>
        <Link to={'/my-holdings'} component={IconAnchor}>
          my holdings
        </Link>
      </Space>
      <Space className={css.row}>
        <div>Locale: {systemState.locale}</div>
        <Button
          onClick={() => {
            changeLocale(LOCALE.zh_hk);
          }}
        >
          HK
        </Button>
        <Button
          onClick={() => {
            changeLocale(LOCALE.en);
          }}
        >
          EN
        </Button>
      </Space>
      <Space className={css.row} direction={'vertical'}>
        <div>
          <label htmlFor="system-error">
            system error
            <input
              type="text"
              id="system-error"
              onChange={(event) => dispatch(setSystemError(event.target.value))}
              value={systemState.error ?? ''}
            />
          </label>
        </div>
        <div>
          <Checkbox
            onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
              dispatch(setSystemEmpty(event.target.checked));
            }}
          >
            empty
          </Checkbox>
        </div>
      </Space>
    </div>
  );
}
