import React, { useEffect, useState } from 'react';

import cn from 'classnames';
import css from './GenericHeader.module.scss';
import { useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { normalizeAccounts } from '../../utils/account';
import {
  Button,
  ChevronAnchor,
  DropdownItem,
  ErrorBanner,
  GlobalHeader,
  IconRefresh,
  MultipleDropdown,
  SingleDropdown,
  Space,
  Typography,
} from '../../components';
import { formatDateTime } from '../../utils/date';
import config from '../../config/HK/common/config/pib';
import { selectSystem } from '../common/saga';
import {
  fetchRealisedGainLoss,
  selectRealisedGainLoss,
  setRealisedGainLossPreference,
} from './saga';
import { RealisedGainLossState } from './reducer';

interface GenericHeaderProps {
  pageTitle: string;
  error?: string;
}

export const GenericHeader: React.VFC<GenericHeaderProps> = (props) => {
  const { t } = useTranslation();

  const { pageTitle, error } = props;

  const dispatch = useDispatch();
  const system = selectSystem();
  const accountState = selectRealisedGainLoss();

  const normalizedAccounts = normalizeAccounts(accountState.root?.accountGroupInformation ?? [], t);

  const [selected, setSelected] = useState<RealisedGainLossState['preference']>(
    accountState.preference || {
      accounts: normalizedAccounts.map((it) => it.value),
      currency: config.realisedGainLoss.currency[0],
    }
  );

  const setPartialSelected = (partials: Partial<RealisedGainLossState['preference']>) => {
    setSelected((prevState) => ({
      ...prevState,
      ...partials,
    }));
  };

  useEffect(() => {
    if (accountState.cacheDateTime && !accountState.preference) {
      const def = {
        account: normalizeAccounts(accountState.root?.accountGroupInformation ?? [], t).map(
          (it) => it.value
        ),
        currency: config.realisedGainLoss.currency[0],
      };
      setSelected(def);
      dispatch(setRealisedGainLossPreference(def));
    }
  }, [accountState.cacheDateTime]);

  const onApply = () => {
    dispatch(setRealisedGainLossPreference(selected));
  };

  const lastUpdated = () => {
    return (
      <Space align={'center'}>
        {accountState.cacheDateTime && (
          <div>
            <div>{t('common.lastUpdated')}:</div>
            <div>{formatDateTime(new Date(accountState.cacheDateTime), system.timezone)}</div>
          </div>
        )}
        <Button
          icon={<IconRefresh />}
          className={css.buttonRefresh}
          onClick={() => {
            dispatch(fetchRealisedGainLoss());
          }}
        />
      </Space>
    );
  };

  const renderDropdown = () => {
    if (system.error) {
      return <ErrorBanner className={css.errorBanner}>{system.error}</ErrorBanner>;
    }
    if (error) {
      return <ErrorBanner className={css.errorBanner}>{error}</ErrorBanner>;
    }

    return (
      <Space className={cn(css.dropdownContainer)} justify={'end'} align={'end'} wrap={true}>
        <div className={cn(css.account)}>
          <MultipleDropdown
            className={css.dropdown}
            allOption={t('myHoldings.dropdown.accounts.all')}
            placeholder={t('myHoldings.dropdown.accounts.placeholder')}
            values={selected?.accounts}
            onChange={(accounts) => setPartialSelected({ accounts })}
          >
            {normalizedAccounts.map((it, index) => (
              <DropdownItem key={index} value={it.value}>
                {it.label}
              </DropdownItem>
            ))}
          </MultipleDropdown>
        </div>
        <div className={css.currency}>
          <SingleDropdown
            placeholder={'Currency'}
            value={selected?.currency}
            onChange={(currency) => setPartialSelected({ currency })}
          >
            {config.realisedGainLoss.currency.map((it) => (
              <DropdownItem value={it} key={it}>
                {it.toUpperCase()}
              </DropdownItem>
            ))}
          </SingleDropdown>
        </div>
        <Button className={css.buttonApply} secondary onClick={onApply}>
          {t('common.apply')}
        </Button>
        {lastUpdated()}
      </Space>
    );
  };

  return (
    <div className={css.container}>
      <GlobalHeader />
      <div className={css.desktopView}>
        <Typography size={4} weight={'light'}>
          <ChevronAnchor href={'/#'} direction={'backward'}>
            {t('common.backToMyWealthDashboard')}
          </ChevronAnchor>
        </Typography>
        <Space align={'center'} className={css.pageTitle}>
          <Typography size={2} weight={'light'}>
            {pageTitle}
          </Typography>
          {renderDropdown()}
        </Space>
      </div>
    </div>
  );
};
