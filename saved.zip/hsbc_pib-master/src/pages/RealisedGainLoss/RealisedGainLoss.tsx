import React, { useEffect } from 'react';
import css from './RealisedGainLoess.module.scss';
import { Tab, TabPane } from '../../components';
import { useTranslation } from 'react-i18next';
import { useDispatch } from 'react-redux';
import { GenericHeader } from './GenericHeader';
import { PassiveIncome } from './PassiveIncome';
import { selectSystem } from '../common/saga';
import { fetchRealisedGainLoss, selectRealisedGainLoss } from './saga';

const t_prefix = 'realisedGainLoss';

export default function RealisedGainLoss(): JSX.Element {
  const { t } = useTranslation();

  const systemState = selectSystem();
  const realisedState = selectRealisedGainLoss();
  const dispatch = useDispatch();

  useEffect(() => {
    if (!realisedState.cacheDateTime) {
      dispatch(fetchRealisedGainLoss());
    }
  }, [realisedState.cacheDateTime]);

  return (
    <div className={css.page}>
      <GenericHeader pageTitle={'Realised gain/loss'} error={realisedState.error} />
      <Tab defaultKey={'passiveIncome'} className={css.section}>
        <TabPane title={t(`${t_prefix}.passiveIncome`)} key={'passiveIncome'}>
          <PassiveIncome
            investment={realisedState}
            system={systemState}
            currency={realisedState.preference?.currency ?? ''}
          />
        </TabPane>
        <TabPane title={t(`${t_prefix}.capitalGainLoss`)} key={'capitalGainLoss'}>
          <div className={css.tabContent}>Capital Gain/Loss content</div>
        </TabPane>
      </Tab>
    </div>
  );
}
