import { AxiosResponse } from 'axios';
import { all, call, put, takeLatest } from 'redux-saga/effects';
import { RealisedGainLossState } from './reducer';
import { SET_SYSTEM_ERROR } from '../common/saga';
import { ActionPayload } from '../common/reducer';
import { AllEffect, ForkEffect } from '@redux-saga/core/effects';
import { useSelector } from 'react-redux';
import { RootState } from '../../store';
import { fetchWrapper } from '../../utils/fetch';
import { R18Response } from '../../@types/R18Response';

export const SET_REALISED_GAIN_LOSS = 'SET_REALISED_GAIN_LOSS';
export const FETCH_REALISED_GAIN_LOSS = 'FETCH_REALISED_GAIN_LOSS';
export const FETCHING_REALISED_GAIN_LOSS = 'FETCHING_REALISED_GAIN_LOSS';
export const SET_REALISED_GAIN_LOSS_PREFERENCE = 'SET_REALISED_GAIN_LOSS_PREFERENCE';

export function fetchRealisedGainLoss(): ActionPayload {
  return { type: FETCH_REALISED_GAIN_LOSS, payload: '/api/account' };
}

export function setRealisedGainLossPreference(
  payload: RealisedGainLossState['preference']
): ActionPayload {
  return { type: SET_REALISED_GAIN_LOSS_PREFERENCE, payload };
}

function* doFetchRealisedGainLoss(action: ActionPayload) {
  try {
    yield put({ type: FETCHING_REALISED_GAIN_LOSS, payload: true });
    const response: AxiosResponse<R18Response> = yield call(fetchWrapper, action.payload);
    yield put({ type: SET_REALISED_GAIN_LOSS, payload: response.data });
    yield put({ type: FETCHING_REALISED_GAIN_LOSS, payload: false });
  } catch (e) {
    yield put({ type: SET_SYSTEM_ERROR, payload: e.message });
    yield put({ type: FETCHING_REALISED_GAIN_LOSS, payload: false });
  }
}

export function* watchFetchRealisedGainLoss(): Generator<ForkEffect> {
  yield takeLatest(FETCH_REALISED_GAIN_LOSS, doFetchRealisedGainLoss);
}

export const selectRealisedGainLoss = (): RealisedGainLossState =>
  useSelector((state: RootState) => state.holding);

export default function* rootSaga(): Generator<AllEffect<any>> {
  yield all([watchFetchRealisedGainLoss()]);
}
