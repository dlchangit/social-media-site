import React, { useEffect, useState } from 'react';
import { add, format, subMonths } from 'date-fns';
import { setTime } from '../../utils/date';
import config from '../../config/HK/common/config/pib';
import { useTranslation } from 'react-i18next';
import * as am4core from '@amcharts/amcharts4/core';
import { DataItem, Label } from '@amcharts/amcharts4/core';
import cn from 'classnames';
import css from './RealisedGainLoess.module.scss';
import {
  Button,
  CategoryData,
  Checkbox,
  createTooltipLabel,
  CurrencyAmount,
  DateChart,
  Disclaimers,
  DonutChart,
  DropdownItem,
  EmptyResult,
  Grid,
  IconBar,
  IconChart,
  IconModal,
  IconTooltip,
  IconTooltipActive,
  InputDateRange,
  Item,
  LoadResult,
  Modal,
  PrimaryTitle,
  Row,
  SingleDropdown,
  Space,
  Tag,
  Tooltip,
  Typography,
} from '../../components';
import { QuickLinks } from './QuickLinks';
import ReactDOMServer from 'react-dom/server';
import { formatDigits } from '../../utils/math';
import { LegendDataItem } from '@amcharts/amcharts4/charts';
import { RealisedGainLossState } from './reducer';
import { SystemState } from '../common/reducer';
import { IncomeTable } from './IncomeTable';
import faker from 'faker';

const t_prefix = 'realisedGainLoss';

const tooltipFormatter = (item: DataItem, currency: string) => {
  return ReactDOMServer.renderToString(
    <Space align={'start'}>
      <Typography weight={'light'} size={5}>
        Income:&nbsp;
      </Typography>
      <Typography size={5}>
        {currency.toUpperCase()} {formatDigits(item.values.valueY.value)}
      </Typography>
    </Space>
  );
};

const barData = (currency: string) => {
  return Array.from({ length: 12 }).map((_, i) => {
    const amount = faker.finance.amount(1000, 20000);
    return {
      date: new Date(2020, i + 1, faker.random.number({ min: 10, max: 20 })).toISOString(),
      value: parseFloat(faker.random.boolean() ? amount : amount),
      tooltipFormatter: (item: DataItem) => tooltipFormatter(item, currency),
    };
  });
};

const donutData: (currency: string) => CategoryData[] = (currency: string) => {
  return [
    'Unit Trusts',
    'FlexInvest',
    'Stocks',
    'Capital Protected Investment',
    'Deposit Plus',
    'ELI & Structure Notes',
    'Cash',
    'Time Deposits',
    'Others',
  ].map((name) => {
    return {
      category: name,
      value: faker.finance.amount(1000, 10000, 2) as never,
      tooltipFormatter(item: DataItem) {
        const container = new am4core.Container();
        container.layout = 'vertical';
        container.horizontalCenter = 'middle';
        const label = createTooltipLabel();
        const l = ((item as unknown) as {
          legendDataItem: LegendDataItem;
        }).legendDataItem;
        label.text =
          (l.sprites[2] as Label).currentText + ' ' + (l.sprites[3] as Label).currentText;
        label.parent = container;

        const label2 = createTooltipLabel({ bold: true });
        label2.text = currency.toUpperCase() + ' ' + formatDigits(item.values?.value?.value);
        label2.marginTop = 4;
        label2.parent = container;

        return container;
      },
    };
  });
};

export const PassiveIncome: React.FC<{
  investment: RealisedGainLossState;
  system: SystemState;
  currency: string;
}> = React.memo(({ investment, system, currency }) => {
  const [chartType, setChartType] = useState<'bar' | 'donut'>('bar');
  const [labelMeaningVisible, setLabelMeaningVisible] = useState<boolean>(false);
  const [donutDataSet, setDonutDataSet] = useState(donutData(currency));
  const [dateRange, setDataRange] = useState({
    from: add(setTime(new Date(), 0, 0), config.realisedGainLoss.filter.dateRange.default.from),
    to: add(setTime(new Date(), 0, 0), config.realisedGainLoss.filter.dateRange.default.to),
  });
  const [productType, setProductType] = useState(config.realisedGainLoss.filter.productType[0]);

  const { t } = useTranslation();

  const [normalized, setNormalized] = useState(barData(currency));

  useEffect(() => {
    const data = barData(currency);
    if (data.length > 0 && data.length < 12) {
      const diff = 12 - normalized.length;
      setNormalized(
        Array.from({ length: diff })
          .map((_, index) => {
            return {
              date: subMonths(new Date(data[0].date), index + 1).toISOString(),
              value: 0,
              tooltipFormatter: (item: DataItem) => tooltipFormatter(item, currency),
            };
          })
          .concat(data)
      );
    }

    setDonutDataSet(donutData(currency));
  }, [currency]);

  const renderModal = () => {
    const modalSections: {
      header: string;
      subHeader: string;
      contents: { title: string; description: string; theme: 'dark' | 'light' }[];
    }[] = t(`${t_prefix}.label.modal_sections`, { returnObjects: true });
    return modalSections.map((it, sessionIndex) => {
      return (
        <div
          key={sessionIndex}
          className={cn({ [css.mt24]: sessionIndex === 0, [css.mt28]: sessionIndex !== 0 })}
        >
          <PrimaryTitle>{it.header}</PrimaryTitle>
          <Typography size={6}>{it.subHeader}</Typography>
          {it.contents.map(({ title, description, theme }, contentIndex) => {
            return (
              <div
                className={cn({ [css.mt20]: contentIndex === 0, [css.mt16]: contentIndex !== 0 })}
                key={contentIndex}
              >
                <Tag theme={theme} size={7}>
                  {title}
                </Tag>
                <span className={css.ml4}>{description}</span>
              </div>
            );
          })}
        </div>
      );
    });
  };

  const lastYear = add(new Date(), { years: -1 });
  const lastMonth = add(new Date(), { months: -1 });

  return (
    <div className={css.tabContent}>
      <Grid>
        <Row flush>
          <Item lgSize={8} mdSize={12} smSize={12}>
            <PrimaryTitle>{t(`${t_prefix}.overview`)}</PrimaryTitle>
            <CurrencyAmount
              style={{ marginTop: 22 }}
              amount={120000}
              currency={currency.toUpperCase()}
              label={
                <Space align={'center'}>
                  <Typography size={5}>
                    {t(`${t_prefix}.totalDividend`)
                      .replace('{from-month}', format(lastYear, 'MMM'))
                      .replace('{from-year}', format(lastYear, 'yyyy'))
                      .replace('{to-month}', format(lastMonth, 'MMM'))
                      .replace('{to-year}', format(lastMonth, 'yyyy'))}
                  </Typography>
                  <Tooltip
                    className={css.ml8}
                    direction={'bottom-center'}
                    message={'Only Hong Kong transaction records are available to view.'}
                    activeChildren={<IconTooltipActive />}
                  >
                    <IconTooltip />
                  </Tooltip>
                </Space>
              }
            />
            <Space style={{ marginTop: 44, marginBottom: 40 }} align={'center'} justify={'between'}>
              <Typography size={4} weight={'light'}>
                {t(`${t_prefix}.incomesContribution`)}
              </Typography>
              <Space>
                <Button
                  onClick={() => setChartType('bar')}
                  icon={<IconBar />}
                  selected={chartType === 'bar'}
                />
                <Button
                  onClick={() => setChartType('donut')}
                  icon={<IconChart />}
                  style={{ borderLeft: 'none' }}
                  selected={chartType === 'donut'}
                />
              </Space>
            </Space>

            <div style={{ height: 400, width: '100%' }}>
              {chartType === 'bar' && (
                <DateChart
                  data={investment.loading || system.empty ? [] : normalized}
                  id={'income-chart'}
                  valueTitle={currency.toUpperCase()}
                  style={{ height: 300 }}
                  emptyResult={
                    <EmptyResult label={'You do not have any investment products'} border={true} />
                  }
                  loadingResult={
                    investment.loading ? <LoadResult label={'Loading'} border={true} /> : undefined
                  }
                />
              )}
              {chartType === 'donut' && (
                <DonutChart
                  data={investment.loading || system.empty ? [] : donutDataSet}
                  id={'income-donut'}
                  style={{ height: 300, width: '100%' }}
                  emptyResult={
                    <EmptyResult label={'You do not have any investment products'} border={true} />
                  }
                  loadingResult={
                    investment.loading ? <LoadResult label={'Loading'} border={true} /> : undefined
                  }
                />
              )}
            </div>
            <PrimaryTitle className={css.mt40}>Income record</PrimaryTitle>
          </Item>
          <Item lgSize={3} lgOffset={1}>
            <QuickLinks data={t(`${t_prefix}.quickLinks`, { returnObjects: true })} />
          </Item>
        </Row>
      </Grid>
      <Space align={'center'} className={css.mt20}>
        <Typography size={6} weight={'light'}>
          Product type:
        </Typography>
        <SingleDropdown
          placeholder={'Product'}
          value={productType}
          onChange={(val) => setProductType(val as string)}
          className={cn(css.ml8, css.incomeFilterProductType)}
        >
          {config.realisedGainLoss.filter.productType.map((it) => (
            <DropdownItem value={it} key={it}>
              {t(`productType.${it}`)}
            </DropdownItem>
          ))}
        </SingleDropdown>
        <Typography size={6} weight={'light'} className={css.ml20}>
          Date range:
        </Typography>
        <InputDateRange
          className={cn(css.ml8, css.incomeFilterDateRange)}
          onChange={setDataRange}
          formatter={({ from, to }) => (
            <Typography size={5} weight={'light'}>
              {format(from, 'dd/MM/yyyy')} to {format(to, 'dd/MM/yyyy')}
            </Typography>
          )}
          min={add(setTime(new Date(), 0, 0), config.realisedGainLoss.filter.dateRange.minDate)}
          max={add(setTime(new Date(), 23, 59), config.realisedGainLoss.filter.dateRange.maxDate)}
          value={dateRange}
        />
        <Space align={'center'} className={css.ml20}>
          <Checkbox defaultChecked={true} size={'large'}>
            <Space align={'center'}>
              <Typography size={6} weight={'light'}>
                Show initial currency
              </Typography>
            </Space>
          </Checkbox>
          <Tooltip
            className={css.ml8}
            direction={'bottom-center'}
            message={'Only Hong Kong transaction records are available to view.'}
            activeChildren={<IconTooltipActive />}
          >
            <IconTooltip />
          </Tooltip>
        </Space>
        <Button
          icon={<IconModal />}
          type={'raw'}
          className={css.labelButton}
          onClick={() => setLabelMeaningVisible(true)}
        >
          {t(`${t_prefix}.label.button`)}
        </Button>
        <Modal
          visible={labelMeaningVisible}
          onClose={() => setLabelMeaningVisible(false)}
          header={t(`${t_prefix}.label.modal_header`)}
        >
          {renderModal()}
        </Modal>
      </Space>

      <div className={css.mt20}>
        {investment.loading ? (
          <LoadResult style={{ height: 300 }} label={'Loading'} border={true} />
        ) : (
          <IncomeTable />
        )}
      </div>
      <Disclaimers
        className={css.mt40}
        title={t(`${t_prefix}.disclaimers.title`)}
        content={t(`${t_prefix}.disclaimers.content`)}
      />
    </div>
  );
});
