import React from 'react';
import {
  Button,
  CurrencyAmount,
  EmptyView,
  ExpandableTable,
  ExpandableTableRow,
  IconAddWatch,
  IconBuy,
  IconSell,
  QuickMenu,
  Space,
  TableCol,
  TableRow,
  Tag,
  Tooltip,
  ExpandControlV2,
} from '../../components';
import css from './IncomeTable.module.scss';
import cn from 'classnames';
import { selectSystem } from '../common/saga';

interface Row {
  name: string;
  type?: string;
  shortName?: string;
  currency: string;
  amount: number;
  percent: number;
  tags?: {
    name: string;
    tooltip: string;
    theme?: 'dark' | 'light';
  }[];
}

interface GroupRow extends Row {
  nested: Row[];
}

const groups: GroupRow[] = [
  {
    name: 'Total',
    currency: 'USD',
    amount: 135641.28,
    percent: 12.42,
    nested: [],
  },
  {
    name: 'Unit Trust',
    type: 'unit_trust',
    currency: 'HKD',
    amount: 135641.28,
    percent: 12.42,
    nested: [
      {
        name: 'HSBC Asian ex Japan Equity Fund (Class AD)',
        shortName: 'U62909',
        tags: [
          {
            name: 'HK',
            tooltip: 'Hong Kong',
          },
          {
            name: 'I.F',
            tooltip: 'Currently using Investment Financing on this product',
            theme: 'light',
          },
        ],
        currency: 'HKD',
        amount: 135641.28,
        percent: 12.42,
      },
      {
        name: 'HSBC Portfolios - World Selection 3 (AMFLX-RMBH-MD-C)',
        shortName: 'U62909',
        currency: 'USD',
        amount: 135641.28,
        percent: 12.42,
      },
    ],
  },
  {
    name: 'Bonds and CDs',
    type: 'fund',
    currency: 'HKD',
    amount: 135641.28,
    percent: 12.42,
    nested: [
      {
        name: 'HSBC Asian ex Japan Equity Fund (Class AD)',
        shortName: 'U62909',
        currency: 'HKD',
        amount: 135641.28,
        percent: 12.42,
      },
      {
        name: 'HSBC Portfolios - World Selection 3 (AMFLX-RMBH-MD-C)',
        shortName: 'U62909',
        currency: 'USD',
        amount: 135641.28,
        percent: 12.42,
      },
    ],
  },
];

export const IncomeTable: React.FC = () => {
  const systemState = selectSystem();

  const renderNestedRow = (nested: Row[]) => {
    return nested.map((it, index) => {
      return (
        <TableRow className={css.childRow} key={index}>
          <TableCol className={cn(css.colFill)}>
            <Space justify={'between'} align={'center'}>
              <div>{it.name}</div>
              <QuickMenu>
                {(_, setVisible) => (
                  <>
                    <Button type="text" icon={<IconBuy />} block onClick={() => setVisible(false)}>
                      Quick buy
                    </Button>
                    <Button type="text" icon={<IconSell />} block onClick={() => setVisible(false)}>
                      Quick sell
                    </Button>
                    <Button
                      type="text"
                      icon={<IconAddWatch />}
                      block
                      onClick={() => setVisible(false)}
                    >
                      Add to wishlist
                    </Button>
                  </>
                )}
              </QuickMenu>
            </Space>
            <Space className={css.mt4}>
              <div className={css.shortName}>{it.shortName}</div>
              {it.tags?.map((tag, tagIndex) => (
                <Tooltip direction={'bottom-center'} message={tag.tooltip} key={tagIndex}>
                  <Tag className={css.tag} theme={tag.theme} size={7}>
                    {tag.name}
                  </Tag>
                </Tooltip>
              ))}
            </Space>
          </TableCol>
          <TableCol className={cn(css.colData)} align={'right'}>
            <CurrencyAmount
              currency={it.currency}
              percent={it.percent}
              amount={it.amount}
              size={'small'}
              light={true}
              showSign={true}
            />
          </TableCol>
        </TableRow>
      );
    });
  };

  const renderRows = () => {
    return groups.map((it, index) => {
      if (it.nested.length === 0) {
        return (
          <TableRow key={index}>
            <TableCol className={cn(css.colFill)}>{it.name}</TableCol>
            <TableCol className={cn(css.colData)} align={'right'}>
              <CurrencyAmount
                currency={it.currency}
                percent={it.percent}
                amount={it.amount}
                size={'small'}
                light={true}
                showSign={true}
              />
            </TableCol>
          </TableRow>
        );
      } else {
        return (
          <ExpandableTableRow expandChild={renderNestedRow(it.nested)} key={index}>
            {(isExpanded, setExpanded) => {
              return (
                <>
                  <TableCol
                    className={cn(css.colFill)}
                    onClick={() => {
                      setExpanded(!isExpanded);
                    }}
                  >
                    <ExpandControlV2 isActive={isExpanded}>
                      <span style={{ marginLeft: 8 }}>{it.name}</span>
                    </ExpandControlV2>
                  </TableCol>
                  <TableCol className={cn(css.colData)} align={'right'}>
                    <CurrencyAmount
                      currency={it.currency}
                      percent={it.percent}
                      amount={it.amount}
                      size={'small'}
                      light={true}
                      showSign={true}
                    />
                  </TableCol>
                </>
              );
            }}
          </ExpandableTableRow>
        );
      }
    });
  };

  return (
    <ExpandableTable
      header={
        <TableRow header={true}>
          <TableCol className={cn(css.colFill)}>Product</TableCol>
          <TableCol className={cn(css.colData)} align={'right'}>
            Dividend/cash income
          </TableCol>
        </TableRow>
      }
      emptyView={<EmptyView message={'We are unable to load the content at this moment.'} />}
    >
      {systemState.empty ? [] : renderRows()}
    </ExpandableTable>
  );
};
