import {
  FETCHING_REALISED_GAIN_LOSS,
  SET_REALISED_GAIN_LOSS,
  SET_REALISED_GAIN_LOSS_PREFERENCE,
} from './saga';
import { R18Response } from '../../@types/R18Response';
import { ActionPayload } from '../common/reducer';

export interface RealisedGainLossState {
  root?: R18Response;
  loading: boolean;
  error?: string;
  cacheDateTime?: string;
  preference?: {
    accounts?: string[];
    currency?: string;
  };
}

const initialState: RealisedGainLossState = {
  root: undefined,
  cacheDateTime: undefined,
  loading: false,
  error: undefined,
  preference: undefined,
};

export default function reducer(
  state = initialState,
  action: ActionPayload
): RealisedGainLossState {
  switch (action.type) {
    case SET_REALISED_GAIN_LOSS:
      return { ...state, root: action.payload, cacheDateTime: new Date().toISOString() };
    case FETCHING_REALISED_GAIN_LOSS:
      return { ...state, loading: action.payload };
    case SET_REALISED_GAIN_LOSS_PREFERENCE:
      return { ...state, preference: action.payload };
    default:
      return state;
  }
}
