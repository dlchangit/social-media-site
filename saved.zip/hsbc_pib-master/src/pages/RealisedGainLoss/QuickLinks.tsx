import React from 'react';
import css from './RealisedGainLoess.module.scss';
import cn from 'classnames';
import { IconAnchor, IconAsset, IconInvestment, PrimaryTitle, Space } from '../../components';

export interface QuickLinksProps {
  data: {
    header: string;
    links: {
      icon: 'asset' | 'investment';
      text: string;
      href: string;
    }[];
  };
}

export const QuickLinks: React.VFC<QuickLinksProps> = (props) => {
  const { data } = props;
  return (
    <Space direction={'vertical'}>
      <PrimaryTitle>{data.header}</PrimaryTitle>
      {data.links.map((it, index) => {
        const first = index === 0;
        let icon = undefined;
        if (it.icon === 'asset') {
          icon = <IconAsset />;
        }
        if (it.icon === 'investment') {
          icon = <IconInvestment />;
        }
        return (
          <IconAnchor
            key={index}
            href={it.href}
            icon={icon}
            className={cn({ [css.mt20]: first, [css.mt8]: !first })}
            style={{ maxWidth: 225 }}
          >
            {it.text}
          </IconAnchor>
        );
      })}
    </Space>
  );
};
