import React from 'react';

function NoMatch(): JSX.Element {
  return <div>404 no match</div>;
}

export default NoMatch;
