import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import cn from 'classnames';
import css from './InvestmentTab.module.scss';
import {
  Button,
  createTooltipLabel,
  CurrencyAmount,
  DonutChart,
  EmptyResult,
  HorizontalBarChart,
  IconBar,
  IconChart,
  LoadResult,
  PrimaryTitle,
  Space,
  Typography,
} from '../../components';
import faker from 'faker';
import * as am4core from '@amcharts/amcharts4/core';
import { DataItem, Label } from '@amcharts/amcharts4/core';
import { LegendDataItem } from '@amcharts/amcharts4/charts';
import { formatDigits } from '../../utils/math';
import { selectSystem } from '../common/saga';
import { selectMyHoldings } from './saga';
import { TableSwitcher } from './InvestmentTable';

export const InvestmentTab: React.VFC = () => {
  const { t } = useTranslation();

  const systemState = selectSystem();
  const holdingState = selectMyHoldings();

  const [chartType, setChartType] = useState<'bar' | 'donut'>('bar');

  const investmentData = [
    'Unit Trusts',
    'FlexInvest',
    'Stocks',
    'Capital Protected Investment',
    'Deposit Plus',
    'Cash',
    'Time Deposits',
  ].map((name) => {
    return {
      category: name,
      value: faker.finance.amount(100, 20000, 2) as any,
      tooltipFormatter(item: DataItem) {
        const container = new am4core.Container();
        container.layout = 'vertical';
        container.horizontalCenter = 'middle';
        const label = createTooltipLabel();
        // label.text = '{category}' + ' ' + "({value.percent.formatNumber('#.0')}%)";
        const l = ((item as unknown) as {
          legendDataItem: LegendDataItem;
        }).legendDataItem;
        label.text =
          (l.sprites[2] as Label).currentText + ' ' + (l.sprites[3] as Label).currentText;
        label.parent = container;

        const label2 = createTooltipLabel({ bold: true });
        label2.text = 'HKD' + ' ' + formatDigits(item.values?.value?.value);
        label2.marginTop = 4;
        label2.parent = container;

        return container;
      },
    };
  });

  const empty = (
    <EmptyResult
      label={'You do not have any investment products.'}
      border={true}
      className={css.resultHeight}
    />
  );

  const loading = holdingState.loading ? (
    <LoadResult label={'Loading'} border={true} className={css.resultHeight} />
  ) : undefined;

  return (
    <div>
      <div>
        <PrimaryTitle>{t('myHoldings.investment.overview.title')}</PrimaryTitle>
        <Space className={css.currencyContainer}>
          <div className={css.currencyGutter}>
            <CurrencyAmount
              currency={'HKD'}
              amount={1000000}
              label={<span>{t('myHoldings.investment.overview.totalMarketValue')}</span>}
            />
          </div>
          <div className={css.currencyGutter}>
            <CurrencyAmount
              currency={'HKD'}
              amount={1000000}
              label={<span>{t('myHoldings.investment.overview.totalUGL')}</span>}
              showSign={true}
            />
          </div>
        </Space>
      </div>

      <div className={cn(css.left)}>
        <Space justify={'between'} align={'center'}>
          <Typography size={4} weight={'light'}>
            {t(`myHoldings.investment.holdingsContribution`)}
          </Typography>
          <Space>
            <Button
              onClick={() => setChartType('bar')}
              icon={<IconBar />}
              selected={chartType === 'bar'}
            />
            <Button
              onClick={() => setChartType('donut')}
              icon={<IconChart />}
              style={{ borderLeft: 'none' }}
              selected={chartType === 'donut'}
            />
          </Space>
        </Space>
        <div className={css.chartContainer}>
          {chartType === 'bar' && (
            <HorizontalBarChart
              data={holdingState.loading || systemState.empty ? [] : investmentData}
              id={'investment-chart'}
              valueTitle={'HKD'}
              style={{ height: '100%' }}
              emptyResult={empty}
              loadingResult={loading}
            />
          )}
          {chartType === 'donut' && (
            <DonutChart
              data={holdingState.loading || systemState.empty ? [] : investmentData}
              id={'investment-donut'}
              style={{ height: '100%' }}
              valueTitle={'Product Type:'}
              emptyResult={empty}
              loadingResult={loading}
            />
          )}
        </div>
      </div>

      <TableSwitcher />
    </div>
  );
};
