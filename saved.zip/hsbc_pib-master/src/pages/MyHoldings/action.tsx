//appController.js 196
import React from 'react';

export function normalSubmitAction(
  event: React.MouseEvent,
  // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
  configObj: any,
  // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
  appParamObj: any
): void {
  console.log('event', event);
  console.log('configObj', configObj);
  console.log('appParamObj', appParamObj);
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
export function loadFunc(event: React.MouseEvent, pageId: string, params: any): void {
  console.log('event', event);
  console.log('pageId', pageId);
  console.log('params', params);
}
