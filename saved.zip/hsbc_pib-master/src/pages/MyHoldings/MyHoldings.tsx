import React, { useEffect } from 'react';
import css from './MyHoldings.module.scss';
import { useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { selectMyHoldings } from './saga';
import { GenericHeader } from './GenericHeader';
import { BackToTop, Disclaimers } from '../../components';
import { InvestmentTab } from './InvestmentTab';
import { fetchSummary, selectSystem } from '../common/saga';

export default function MyHoldings(): JSX.Element {
  const dispatch = useDispatch();
  const holdingState = selectMyHoldings();
  const systemState = selectSystem();
  const { t } = useTranslation();

  useEffect(() => {
    if (!systemState.cacheDateTime) {
      dispatch(fetchSummary());
    }
  }, [systemState.cacheDateTime]);

  return (
    <div>
      <GenericHeader
        pageTitle={t('myHoldings.pageTitle')}
        error={systemState.error || holdingState.error}
      />
      {/*<Tab defaultKey={'investment'} className={css.section}>*/}
      {/*  <TabPane title={t('myHoldings.investment.title')} key={'investment'}>*/}
      <div className={css.section}>
        <InvestmentTab />
      </div>
      {/*</TabPane>*/}
      {/*<TabPane title={t('myHoldings.mpf.title')} key={'mpf'}>*/}
      {/*  <div className={css.section}>mpf content</div>*/}
      {/*</TabPane>*/}
      {/*</Tab>*/}

      <BackToTop className={css.section} label={'Back to top'} />
      <Disclaimers
        className={css.section}
        title={t(`myHoldings.disclaimers.title`)}
        content={t(`myHoldings.disclaimers.content`)}
      />
    </div>
  );
}
