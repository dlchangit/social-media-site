import React from 'react';
import { Button, IconAddWatch, IconBuy, IconSell, QuickMenu } from '../../../components';
import css from './InvestmentTable.module.scss';
import { useTranslation } from 'react-i18next';

interface QuickActionProps {
  showBuy: boolean;
  showSell: boolean;
  showAddToWatchList: boolean;
}

export const QuickAction: React.VFC<QuickActionProps> = (props) => {
  const { t } = useTranslation();

  return (
    <QuickMenu buttonClass={css.quickMenuButton}>
      {(_, setVisible) => (
        <>
          {props.showBuy && (
            <Button
              type="text"
              icon={<IconBuy />}
              block
              align={'left'}
              onClick={() => setVisible(false)}
            >
              {t('quickMenu.buy')}
            </Button>
          )}
          {props.showSell && (
            <Button
              type="text"
              icon={<IconSell />}
              block
              align={'left'}
              onClick={() => setVisible(false)}
            >
              {t('quickMenu.sell')}
            </Button>
          )}
          {props.showAddToWatchList && (
            <Button
              type="text"
              icon={<IconAddWatch />}
              block
              align={'left'}
              onClick={() => setVisible(false)}
            >
              {t('quickMenu.addToWatchlist')}
            </Button>
          )}
        </>
      )}
    </QuickMenu>
  );
};
