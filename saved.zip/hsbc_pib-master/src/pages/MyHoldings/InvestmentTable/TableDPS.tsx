import css from './InvestmentTable.module.scss';
import React from 'react';
import { useTranslation } from 'react-i18next';
import {
  Button,
  CurrencyAmount,
  EmptyResult,
  ExpandableTableV2,
  ExpandControlV2,
  IconAddWatch,
  IconBuy,
  IconSell,
  LoadingView,
  Result,
  Space,
  TableColV2,
  Tag,
  Tooltip,
  Typography,
} from '../../../components';
import { InvestmentSummary, InvestmentSummaryProps } from './InvestmentSummary';
import * as faker from 'faker';
import { formatDigits } from '../../../utils/math';
import { QuickAction } from './QuickAction';
import { selectSystem } from '../../common/saga';
import { selectMyHoldings } from '../saga';
import { dateSort, numericSort, periodSort, SortDirection } from '../../../utils/sort';
import { CurrencyCodeType } from '../../../utils/currency';
import { formatDate, textToPeriod } from '../../../utils/date';

const summaryData: InvestmentSummaryProps['data'] = [
  {
    label: 'Market Value',
    showSign: false,
    currency: 'HKD',
  },
  {
    label: 'Projected Income',
    showSign: false,
    currency: 'HKD',
  },
].map((it) => {
  return {
    ...it,
    amount: faker.random.number(10000000),
    percent: it.showSign ? faker.random.number(100) : undefined,
  };
});

export const TableDPS: React.FC = () => {
  const { t } = useTranslation();

  const systemState = selectSystem();
  const holdingState = selectMyHoldings();

  const parseData = () => {
    return (
      holdingState.depositPlus?.holdingOrderInformation?.map((it) => {
        const detail = it.holdingDetailInformation[0];
        const detailCurrency = detail.holdingDetailMultipleCurrencyInformation.find(
          (it) => it.currencyTypeCode === holdingState?.preference?.currencyCodeType
        );

        const localDetailCurrency = detail.holdingDetailMultipleCurrencyInformation.find(
          (it) => it.currencyTypeCode === CurrencyCodeType.LOCAL
        );

        const portfolioDetail = holdingState.depositPlus?.portfolioDetailInformation[0].portfolioDetailMultipleCurrencyInformation.find(
          (it) => {
            //NO Product currency
            return it.currencyTypeCode === CurrencyCodeType.LOCAL;
          }
        );

        return {
          fund: {
            // productName: detail.currencyLinkDepositCode,
            productName: it.productName,
            tags: ['UT'],
          },
          depositAmount: {
            currency: detailCurrency?.currencyProductHoldingMarketValueAmountCode,
            amount: detailCurrency?.productHoldingMarketValueAmount,
            localAmount: localDetailCurrency?.productHoldingMarketValueAmount,
          },
          realisedIncome: {
            currency: portfolioDetail?.currencyIncomeCurrentPurchasePeriodCode,
            amount: portfolioDetail?.incomeCurrentPurchasePeriodAmount,
            localAmount: portfolioDetail?.incomeCurrentPurchasePeriodAmount,
          },
          projectedIncome: {
            currency: portfolioDetail?.currencyIncomeProductAmountCode,
            amount: portfolioDetail?.incomeProductAmount,
            localAmount: portfolioDetail?.incomeProductAmount,
          },
          interestRate: {
            amount: undefined as number | undefined,
          },
          depositPeriod: {
            period: textToPeriod(it.holdingMaturityInformation[0].productPeriodText),
          },
          maturityDate: {
            date: new Date(it.holdingMaturityInformation[0].productMaturityDate),
          },
          conversionRate: {
            amount: undefined as number | undefined,
          },
          breakevenRate: {
            amount: undefined as number | undefined,
          },
        };
      }) ?? []
    );
  };

  type DataType = ReturnType<typeof parseData>[number];

  const renderText = (
    text: string | React.ReactElement,
    weight: 'light' | 'regular' | 'medium' = 'light'
  ) => {
    return (
      <Typography size={6} weight={weight}>
        {text}
      </Typography>
    );
  };

  const tableData = parseData();

  return (
    <div>
      <InvestmentSummary data={summaryData} />

      <div className={css.tableContainer}>
        <ExpandableTableV2
          emptyView={<EmptyResult label={'You do not have any investment products.'} />}
          loadingView={holdingState.loading && <LoadingView message={'Loading'} />}
          errorView={
            holdingState.error && (
              <Result
                label={
                  'We are unable to display your holdings at this moment. Please try again later.'
                }
              />
            )
          }
          data={systemState.empty ? [] : tableData}
        >
          <TableColV2
            header={'Fund'}
            className={css.colFill}
            align={'left'}
            weight={'regular'}
            render={(row: DataType) => {
              return (
                <Space justify={'between'}>
                  <div>
                    <span>{row.fund.productName}</span>
                    <Space align={'center'} className={css.productInfo}>
                      <Tooltip direction={'bottom-right'} message={'Hong Kong'}>
                        <Tag theme={'dark'} size={7} className={css.productTag}>
                          HK
                        </Tag>
                      </Tooltip>
                      <Tooltip direction={'bottom-right'} message={'I.F'}>
                        <Tag theme={'light'} size={7} className={css.productTag}>
                          I.F.
                        </Tag>
                      </Tooltip>
                    </Space>
                  </div>
                  <QuickAction showBuy={true} showSell={true} showAddToWatchList={true} />
                </Space>
              );
            }}
          />
          <TableColV2
            header={'Deposit amount'}
            className={css.colLarge}
            sorting={(a, b, direction) => {
              return numericSort(
                a.depositAmount.localAmount,
                b.depositAmount.localAmount,
                direction
              );
            }}
            defaultSortDirection={SortDirection.DESC}
            render={(row: DataType) => {
              return (
                <CurrencyAmount
                  size={'small'}
                  light={true}
                  currency={row.depositAmount.currency ?? ''}
                  amount={row.depositAmount.amount ?? '-'}
                />
              );
            }}
          />
          <TableColV2
            header={'Realise income'}
            className={css.colSmall}
            sorting={(a, b, direction) => {
              return numericSort(
                a.realisedIncome.localAmount,
                b.realisedIncome.localAmount,
                direction
              );
            }}
            render={(row: DataType) => {
              return (
                <CurrencyAmount
                  size={'small'}
                  light={true}
                  currency={row.realisedIncome.currency ?? ''}
                  amount={row.realisedIncome.amount ?? '-'}
                />
              );
            }}
          />
          <TableColV2
            header={'Projected income'}
            className={css.colSmall}
            sorting={(a, b, direction) => {
              return numericSort(
                a.projectedIncome.localAmount,
                b.projectedIncome.localAmount,
                direction
              );
            }}
            render={(row: DataType) => {
              return (
                <CurrencyAmount
                  size={'small'}
                  light={true}
                  currency={row.projectedIncome.currency ?? ''}
                  amount={row.projectedIncome.amount ?? '-'}
                />
              );
            }}
          />
          <TableColV2
            header={'Interest rate'}
            className={css.colSmall}
            sorting={(a, b, direction) => {
              return numericSort(a.interestRate.amount, b.interestRate.amount, direction);
            }}
            render={(row: DataType) => {
              return row.interestRate.amount !== undefined
                ? formatDigits(row.interestRate.amount) + '%'
                : '-';
            }}
          />
          <TableColV2
            header={'Maturity date'}
            className={css.colSmall}
            sorting={(a, b, direction) => {
              return dateSort(a.maturityDate.date, b.maturityDate.date, direction);
            }}
            render={(row: DataType) => {
              return formatDate(row.maturityDate.date);
            }}
          />
          <TableColV2
            header={'Deposit period'}
            className={css.colSmall}
            sorting={(a, b, direction) => {
              return periodSort(a.depositPeriod.period, b.depositPeriod.period, direction);
            }}
            render={(row: DataType) => {
              return (
                <div>
                  {row.depositPeriod.period?.digit}{' '}
                  {t(`datePeriod.${row.depositPeriod.period?.unit}`)}
                </div>
              );
            }}
          />

          <TableColV2
            header={t('common.expandable.more')}
            className={css.colMore}
            align={'center'}
            weight={'regular'}
            render={(_, isExpanded, setIsExpanded) => {
              return (
                <ExpandControlV2 isActive={isExpanded} onClick={() => setIsExpanded(!isExpanded)} />
              );
            }}
            expand={(row: DataType) => (
              <div className={css.childRow}>
                <Space wrap={true}>
                  <span className={css.colExtra}>{renderText('Conversion rate', 'regular')}</span>
                  <span className={css.colExtra}>
                    {renderText(
                      row.conversionRate.amount !== undefined
                        ? formatDigits(row.conversionRate.amount)
                        : '-',
                      'medium'
                    )}
                  </span>
                  <span className={css.colExtra}>{renderText('Breakeven rate', 'regular')}</span>
                  <span className={css.colExtra}>
                    {renderText(
                      row.breakevenRate.amount !== undefined
                        ? formatDigits(row.breakevenRate.amount)
                        : '-',
                      'medium'
                    )}
                  </span>
                </Space>
                <Space className={css.buttonGroup}>
                  <Button className={css.quickButton} icon={<IconBuy />}>
                    {t('quickMenu.buy')}
                  </Button>
                  <Button className={css.quickButton} icon={<IconSell />}>
                    {t('quickMenu.sell')}
                  </Button>
                  <Button className={css.quickButton} icon={<IconAddWatch />}>
                    {t('quickMenu.addToWatchlist')}
                  </Button>
                </Space>
              </div>
            )}
          />
        </ExpandableTableV2>
      </div>
    </div>
  );
};
