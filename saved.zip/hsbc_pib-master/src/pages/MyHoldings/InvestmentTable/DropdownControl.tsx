import React from 'react';
import cn from 'classnames';
import css from './InvestmentTable.module.scss';
import { DropdownItem, SingleDropdown, Space, Typography } from '../../../components';
import config from '../../../config/HK/common/config/pib';
import { useTranslation } from 'react-i18next';
import { selectMyHoldings, setMyHoldingsPreference } from '../saga';
import { useDispatch } from 'react-redux';
import { CurrencyCodeType } from '../../../utils/currency';

export const DropdownControl: React.VFC = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();

  const holdingState = selectMyHoldings();

  const setCurrencyCodeType = (value: CurrencyCodeType | undefined) => {
    dispatch(setMyHoldingsPreference({ currencyCodeType: value }));
  };

  const setProductType = (value: string | undefined) => {
    dispatch(setMyHoldingsPreference({ productType: value }));
  };

  const convertValue = (value: string): CurrencyCodeType => {
    if (value === 'denominatedCurrency') return CurrencyCodeType.PRODUCT;
    if (value === 'homeCurrency') return CurrencyCodeType.LOCAL;

    return CurrencyCodeType.PRODUCT;
  };

  return (
    <Space wrap={true} align={'center'} className={css.dropdownContainer}>
      <Typography size={6}>Product Type:</Typography>
      <SingleDropdown
        placeholder={'SELECT'}
        value={holdingState.preference.productType}
        onChange={(val) => setProductType(val as string)}
        className={cn(css.productTypeDropdown)}
      >
        {config.myHoldings.filter.productType.map((it) => (
          <DropdownItem value={it} key={it}>
            {t(`productType.${it}`)}
          </DropdownItem>
        ))}
      </SingleDropdown>

      <Typography size={6}>Show in:</Typography>
      <SingleDropdown
        placeholder={'SELECT'}
        value={holdingState.preference?.currencyCodeType}
        onChange={(val) => setCurrencyCodeType(val as CurrencyCodeType)}
        className={cn(css.currencyDropdown)}
      >
        {config.myHoldings.filter.currency.map((it) => (
          <DropdownItem value={convertValue(it)} key={it}>
            {t(`currency.${it}`)}
          </DropdownItem>
        ))}
      </SingleDropdown>
    </Space>
  );
};
