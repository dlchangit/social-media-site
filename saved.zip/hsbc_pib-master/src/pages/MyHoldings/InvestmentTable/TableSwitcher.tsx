import React, { useEffect } from 'react';
import { fetchMyHoldings, selectMyHoldings } from '../saga';
import { TableUT } from './TableUT';
import { TableCPI } from './TableCPI';
import css from './InvestmentTable.module.scss';
import { LoadResult, PrimaryTitle, Typography } from '../../../components';
import { DropdownControl } from './DropdownControl';
import { useTranslation } from 'react-i18next';
import { TableDPS } from './TableDPS';
import { TableFlexInvest } from './TableFlexInvest';
import { useDispatch } from 'react-redux';

export const TableSwitcher: React.VFC = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const holdingState = selectMyHoldings();

  useEffect(() => {
    if (holdingState.preference.productType) {
      dispatch(fetchMyHoldings(holdingState.preference.productType));
    }
  }, [holdingState.preference.productType]);

  const renderTable = () => {
    if (holdingState.loading) {
      return (
        <LoadResult label={'Loading'} border={true} style={{ minHeight: 400, marginTop: 28 }} />
      );
    }

    switch (holdingState.preference.productType) {
      case 'unitTrust':
        return <TableUT />;
      case 'flexInvest':
        return <TableFlexInvest />;
      case 'capitalProtectedInvestments':
        return <TableCPI />;
      case 'depositPlus':
        return <TableDPS />;
      default:
        return null;
    }
  };

  return (
    <div>
      <div className={css.title}>
        <PrimaryTitle>{t('myHoldings.tableTitle')}</PrimaryTitle>
      </div>
      <div>
        <Typography size={6}>{t('myHoldings.tableNote')}</Typography>
      </div>
      <DropdownControl />
      {renderTable()}
    </div>
  );
};
