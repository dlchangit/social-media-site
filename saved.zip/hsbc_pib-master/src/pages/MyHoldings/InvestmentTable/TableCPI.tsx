import css from './InvestmentTable.module.scss';
import React from 'react';
import { useTranslation } from 'react-i18next';
import {
  Button,
  CurrencyAmount,
  EmptyResult,
  ExpandableTableV2,
  ExpandControlV2,
  IconAddWatch,
  IconBuy,
  IconSell,
  LoadingView,
  Result,
  Space,
  TableColV2,
  Tag,
  Tooltip,
  Typography,
} from '../../../components';
import { InvestmentSummary, InvestmentSummaryProps } from './InvestmentSummary';
import * as faker from 'faker';
import { formatDigits } from '../../../utils/math';
import { QuickAction } from './QuickAction';
import { selectSystem } from '../../common/saga';
import { selectMyHoldings } from '../saga';
import { alphabeticalSort, numericSort, SortDirection } from '../../../utils/sort';
import { CurrencyCodeType } from '../../../utils/currency';
import { formatDate, textToPeriod } from '../../../utils/date';
import { WealthDashboardPresConstants } from '../../../utils/WealthDashboardPresConstants';

const summaryData: InvestmentSummaryProps['data'] = [
  {
    label: 'Deposit Amount',
    showSign: false,
    currency: 'HKD',
  },
  {
    label: 'Potential Interest Gain at Maturity',
    showSign: false,
    currency: 'HKD',
  },
  {
    label: 'Realised income',
    showSign: false,
    currency: 'HKD',
  },
].map((it) => {
  return {
    ...it,
    currency: it.currency,
    amount: faker.random.number(10000000),
    percent: it.showSign ? faker.random.number(100) : undefined,
  };
});

export const TableCPI: React.FC = () => {
  const { t } = useTranslation();

  const systemState = selectSystem();
  const holdingState = selectMyHoldings();

  const parseData = () => {
    return (
      holdingState.capitalProtectedInvestments?.holdingOrderInformation?.map((it) => {
        const detail = it.holdingDetailInformation[0];
        const detailCurrency = detail.holdingDetailMultipleCurrencyInformation.find(
          (it) => it.currencyTypeCode === holdingState?.preference?.currencyCodeType
        );

        const localDetailCurrency = detail.holdingDetailMultipleCurrencyInformation.find(
          (it) => it.currencyTypeCode === CurrencyCodeType.LOCAL
        );

        // const subDetailCurrency = holdingState.capitalProtectedInvestments?.subPortfolioDetailInformation[
        //   index
        // ].subPortfolioDetailMultipleCurrencyInformation.find(
        //   (it) => it.currencyTypeCode === holdingState?.preference?.currencyCodeType
        // );
        // console.log('subDetailCurrency', subDetailCurrency);

        // PortfolioDetailParser 964
        // TODO to be confirmed with BA, how to use this value
        // hdOrderInfo.setProductAlternativeNum(holdingOrderInfo.getProductAlternativeNumber());
        const prodId = it.productIdInformation?.find(
          (id) =>
            WealthDashboardPresConstants.TR_CODE_DISPLAY ==
            id.productCodeAlternativeClassificationCode
        );

        return {
          fund: {
            productName: it.productName,
            productAlternativeNum: prodId?.productAlternativeNumber,
            tags: ['UT'],
          },
          depositAmount: {
            currency: detailCurrency?.currencyProductHoldingMarketValueAmountCode,
            amount: detailCurrency?.productHoldingMarketValueAmount,
            localAmount: localDetailCurrency?.productHoldingMarketValueAmount,
          },
          depositPeriod: {
            period: textToPeriod(it.holdingMaturityInformation[0]?.productPeriodText),
          },
          currencyPair: {
            pair: it.holdingUnderlyingProdInformation[0]?.instrumentUnderlyingName,
          },
          potentialInterestRate: {
            amount: detail.yieldAnnualPotentialPercent,
          },
          realisedIncome: {
            //TODO feild mapping
            currency: 'HKD',
            amount: faker.random.number(10000),
            localAmount: faker.random.number(10000),
          },
          potentialInterestGain: {
            //TODO feild mapping
            currency: 'HKD',
            amount: faker.random.number(1000),
            localAmount: faker.random.number(1000),
          },
          depositDate: {
            date: new Date(detail.depositDate),
          },
          maturityDate: {
            date: new Date(it.holdingMaturityInformation[0].productMaturityDate),
          },
          depositNumber: {
            number: detail?.productDepositHoldingCode,
          },
        };
      }) ?? []
    );
  };

  type DataType = ReturnType<typeof parseData>[number];

  const renderText = (
    text: string | React.ReactElement,
    weight: 'light' | 'regular' | 'medium' = 'light'
  ) => {
    return (
      <Typography size={6} weight={weight}>
        {text}
      </Typography>
    );
  };

  const tableData = parseData();

  return (
    <div>
      <InvestmentSummary data={summaryData} />

      <div className={css.tableContainer}>
        <ExpandableTableV2
          emptyView={<EmptyResult label={'You do not have any investment products.'} />}
          loadingView={holdingState.loading && <LoadingView message={'Loading'} />}
          errorView={
            holdingState.error && (
              <Result
                label={
                  'We are unable to display your holdings at this moment. Please try again later.'
                }
              />
            )
          }
          data={systemState.empty ? [] : tableData}
        >
          <TableColV2
            header={'Fund'}
            className={css.colFill}
            align={'left'}
            weight={'regular'}
            render={(row: DataType) => {
              return (
                <Space justify={'between'}>
                  <div>
                    <span>{row.fund.productName}</span>
                    <Space align={'center'} className={css.productInfo}>
                      <span>{row.fund.productAlternativeNum}</span>
                      <Tooltip direction={'bottom-right'} message={'Hong Kong'}>
                        <Tag theme={'dark'} size={7} className={css.productTag}>
                          HK
                        </Tag>
                      </Tooltip>
                      <Tooltip direction={'bottom-right'} message={'I.F'}>
                        <Tag theme={'light'} size={7} className={css.productTag}>
                          I.F.
                        </Tag>
                      </Tooltip>
                    </Space>
                  </div>
                  <QuickAction showBuy={true} showSell={true} showAddToWatchList={true} />
                </Space>
              );
            }}
          />
          <TableColV2
            header={'Deposit amount'}
            className={css.colLarge}
            sorting={(a, b, direction) => {
              return numericSort(
                a.depositAmount.localAmount,
                b.depositAmount.localAmount,
                direction
              );
            }}
            defaultSortDirection={SortDirection.DESC}
            render={(row: DataType) => {
              return (
                <CurrencyAmount
                  size={'small'}
                  light={true}
                  currency={row.depositAmount.currency ?? ''}
                  amount={row.depositAmount.amount ?? '-'}
                />
              );
            }}
          />
          <TableColV2
            header={'Deposit period'}
            className={css.colSmall}
            sorting={(a, b, direction) => {
              return numericSort(
                a.depositPeriod.period?.digit,
                b.depositPeriod.period?.digit,
                direction
              );
            }}
            render={(row: DataType) => {
              return (
                <div>
                  {row.depositPeriod.period?.digit}{' '}
                  {t(`datePeriod.${row.depositPeriod.period?.unit}`)}
                </div>
              );
            }}
          />
          <TableColV2
            header={'Currency Pair'}
            className={css.colSmall}
            sorting={(a, b, direction) => {
              return alphabeticalSort(a.currencyPair.pair, b.currencyPair.pair, direction);
            }}
            render={(row: DataType) => {
              return <div>{row.currencyPair.pair?.replace('|', ' / ')}</div>;
            }}
          />
          <TableColV2
            header={'Potential interest rate'}
            className={css.colSmall}
            sorting={(a, b, direction) => {
              return numericSort(
                a.potentialInterestRate.amount,
                b.potentialInterestRate.amount,
                direction
              );
            }}
            render={(row: DataType) => {
              return formatDigits(row.potentialInterestRate.amount) + '%';
            }}
          />
          <TableColV2
            header={'Realise income'}
            className={css.colSmall}
            sorting={(a, b, direction) => {
              return numericSort(
                a.realisedIncome.localAmount,
                b.realisedIncome.localAmount,
                direction
              );
            }}
            render={(row: DataType) => {
              return (
                <CurrencyAmount
                  size={'small'}
                  light={true}
                  currency={row.realisedIncome.currency ?? ''}
                  amount={row.realisedIncome.amount ?? '-'}
                />
              );
            }}
          />
          <TableColV2
            header={'Potential Interest Gain at Maturity'}
            className={css.colSmall}
            sorting={(a, b, direction) => {
              return numericSort(
                a.potentialInterestGain.localAmount,
                b.potentialInterestGain.localAmount,
                direction
              );
            }}
            render={(row: DataType) => {
              return (
                <CurrencyAmount
                  size={'small'}
                  light={true}
                  currency={row.potentialInterestGain.currency ?? ''}
                  amount={row.potentialInterestGain.amount ?? '-'}
                />
              );
            }}
          />
          <TableColV2
            header={t('common.expandable.more')}
            className={css.colMore}
            align={'center'}
            weight={'regular'}
            render={(_, isExpanded, setIsExpanded) => {
              return (
                <ExpandControlV2 isActive={isExpanded} onClick={() => setIsExpanded(!isExpanded)} />
              );
            }}
            expand={(row: DataType) => (
              <div className={css.childRow}>
                <Space wrap={true}>
                  <span className={css.colExtra}>{renderText('Deposit Date', 'regular')}</span>
                  <span className={css.colExtra}>
                    {renderText(formatDate(row.depositDate.date), 'medium')}
                  </span>
                  <span className={css.colExtra}>{renderText('Maturity Date', 'regular')}</span>
                  <span className={css.colExtra}>
                    {renderText(formatDate(row.maturityDate.date), 'medium')}
                  </span>
                  <span className={css.colExtra}>{renderText('Maturity Date', 'regular')}</span>
                  <span className={css.colExtra}>
                    {renderText(row.depositNumber.number, 'medium')}
                  </span>
                </Space>
                <Space className={css.buttonGroup}>
                  <Button className={css.quickButton} icon={<IconBuy />}>
                    {t('quickMenu.buy')}
                  </Button>
                  <Button className={css.quickButton} icon={<IconSell />}>
                    {t('quickMenu.sell')}
                  </Button>
                  <Button className={css.quickButton} icon={<IconAddWatch />}>
                    {t('quickMenu.addToWatchlist')}
                  </Button>
                </Space>
              </div>
            )}
          />
        </ExpandableTableV2>
      </div>
    </div>
  );
};
