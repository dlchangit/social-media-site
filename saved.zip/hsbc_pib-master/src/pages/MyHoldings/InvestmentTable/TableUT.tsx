import css from './InvestmentTable.module.scss';
import React from 'react';
import { useTranslation } from 'react-i18next';
import {
  Button,
  CurrencyAmount,
  EmptyResult,
  ExpandableTableV2,
  ExpandControlV2,
  IconAddWatch,
  IconBuy,
  IconSell,
  Result,
  Space,
  TableColV2,
  Tag,
  Tooltip,
  Typography,
} from '../../../components';
import { InvestmentSummary, InvestmentSummaryProps } from './InvestmentSummary';
import { formatDigits } from '../../../utils/math';
import { QuickAction } from './QuickAction';
import { selectSystem } from '../../common/saga';
import { selectMyHoldings } from '../saga';
import { numericSort, SortDirection } from '../../../utils/sort';
import { CurrencyCodeType } from '../../../utils/currency';
import WealthDashboardPresUtil from '../../../utils/WealthDashboardPresUtil';
import { WealthDashboardPresConstants } from '../../../utils/WealthDashboardPresConstants';
import { isBlank } from '../../../utils/check';
import omittedFields from '../omittedFields.json';
import { loadFunc, normalSubmitAction } from '../action';

const fake = 38901.8;

export const TableUT: React.FC = () => {
  const { t } = useTranslation();

  const systemState = selectSystem();
  const holdingState = selectMyHoldings();

  //TODO ask thomas
  const readOnlyMode = systemState.channelData.readOnlyMode === 'true';

  //TODO ask thomas
  const channelAppID = systemState.channelData.channelAppID;
  let hideTransactionButtons = false;
  if (WealthDashboardPresConstants.CHANNEL_APP_ID_SFP == channelAppID) {
    // @ts-ignore
    const checkLeadId = systemState.commonConfig.Check_Lead_ID;
    if ('N' == checkLeadId) {
      hideTransactionButtons = false;
    } else {
      const leadId = systemState.channelData.leadId;
      hideTransactionButtons = isBlank(leadId);
    }
  }
  if (WealthDashboardPresConstants.CHANNEL_APP_ID_RMP == channelAppID) {
    hideTransactionButtons = true;
  }

  const parseData = () => {
    return (
      holdingState.unitTrust?.holdingOrderInformation
        ?.map((it) => {
          const info = it.holdingDetailInformation[0];
          const currencyDetail = info.holdingDetailMultipleCurrencyInformation.find(
            (it) => it.currencyTypeCode === holdingState?.preference?.currencyCodeType
          );

          const localCurrencyDetail = info.holdingDetailMultipleCurrencyInformation.find(
            (it) => it.currencyTypeCode === CurrencyCodeType.LOCAL
          );

          // PortfolioDetailParser 964
          // TODO to be confirmed with BA, how to use this value
          // hdOrderInfo.setProductAlternativeNum(holdingOrderInfo.getProductAlternativeNumber());
          const prodId = it.productIdInformation?.find(
            (id) =>
              WealthDashboardPresConstants.TR_CODE_DISPLAY ==
              id.productCodeAlternativeClassificationCode
          );

          return {
            fund: {
              productName: it.productShortName,
              productAlternativeNum: prodId?.productAlternativeNumber,
              tags: ['UT'],
            },
            marketValue: {
              currency: currencyDetail?.currencyProductHoldingMarketValueAmountCode,
              amount: currencyDetail?.productHoldingMarketValueAmount,
              localAmount: localCurrencyDetail?.productHoldingMarketValueAmount,
            },
            ugl: {
              currency: currencyDetail?.currencyProfitLossUnrealizedAmountCode,
              amount: currencyDetail?.profitLossUnrealizedAmount,
              localAmount: localCurrencyDetail?.profitLossUnrealizedAmount,
              percent: currencyDetail?.profitLossUnrealizedPercent,
            },
            investmentAmount: {
              currency: currencyDetail?.currencyProductHoldingBookValueAmountCode,
              amount: currencyDetail?.productHoldingBookValueAmount,
              localAmount: localCurrencyDetail?.productHoldingBookValueAmount,
            },
            nav: {
              currency: info?.currencyProductMarketPriceCode,
              amount: info.productMarketPriceAmount,
              localAmount: info.productMarketPriceAmount,
            },
            unit: {
              amount: info.productHoldingQuantityCount,
              localAmount: info.productHoldingQuantityCount,
            },
            // PortfolioDetailParser

            //556
            // dashboard type
            wdsProductType: it.productDashboardTypeCode,
            wdsProductSubType: it.productDashboardSubTypeCode,

            // 564 wdDispalyTypeCode <- wrong spelling
            feProductType: WealthDashboardPresUtil.getProductTypeMappingCode(
              systemState.commonConfig.productTypeMapping,
              it.productDashboardTypeCode,
              it.productDashboardSubTypeCode,
              it.productSubtypeCode
            ),

            // 964
            countryProductTradableCode: prodId?.countryProductTradableCode,

            // 1063
            productInvDataStoreNum: it.productInvestmentDataStoreNumber,

            //1055
            productCode: it.productCode,

            // 1071
            wpcProductSubType: it.productSubtypeCode,

            // 2163
            allowBuyProduct: WealthDashboardPresUtil.isAllowIndicator(
              info?.allowBuyProductIndicator
            ),

            // allow buy amount product
            allowBuyAmountProduct: WealthDashboardPresUtil.isAllowIndicator(
              info.allowBuyAmountProductIndicator
            ),

            // allow buy unit product
            allowBuyUnitProduct: WealthDashboardPresUtil.isAllowIndicator(
              info.allowBuyUnitProductIndicator
            ),

            // allow sell product
            allowSellProduct: WealthDashboardPresUtil.isAllowIndicator(
              info.allowSellProductIndicator
            ),

            // allow sell amount product
            allowSellAmountProduct: WealthDashboardPresUtil.isAllowIndicator(
              info.allowSellAmountProductIndicator
            ),

            // allow sell unit product
            allowSellUnitProduct: WealthDashboardPresUtil.isAllowIndicator(
              info.allowSellUnitProductIndicator
            ),

            // wpc product type code
            wpcProductType: it.productTypeCode,

            // Sprint18 France integration begin
            wpcProductTypeEnCode: it.productSubtypeCode,

            // RRC48170:Configure to show/hide drawer action links/buttons
            // according to market. begin
            tradable: WealthDashboardPresUtil.checkWhetherTradableProduct(
              systemState.wdConfig,
              it.productTypeCode,
              it.productSubtypeCode
            ),
          };
        })
        .map((it) => ({
          ...it,
          //fund/holdingDrawer.html 417
          showBuyButton:
            it.wpcProductType === 'UT' &&
            it.allowBuyProduct &&
            !omittedFields.fund_current_buy_button &&
            it.tradable &&
            !hideTransactionButtons &&
            !readOnlyMode,

          //fund/holdingDrawer.html 452
          showSellButton:
            it.wpcProductType === 'UT' &&
            it.allowSellProduct &&
            !omittedFields.fund_current_sell_button &&
            it.tradable &&
            !hideTransactionButtons &&
            !readOnlyMode,
        })) ?? []
    );
  };

  const onBuy = (event: React.MouseEvent, row: DataType) => {
    const actionUrlConfig = systemState.commonConfig.actionUrlConfig;
    normalSubmitAction(
      event,
      {
        isPopupWin: actionUrlConfig.UT_BUY_ISPOPUP,
        windowName: actionUrlConfig.UT_BUY_WINDOWNAME,
        sendMethod: actionUrlConfig.UT_BUY_SENDMETHOD,
        encryptPasskey: actionUrlConfig.UT_BUY_ENCRYPTPASSKEY,
        passGsData: actionUrlConfig.UT_BUY_PASSGSDATA,
        encryptAlgorithm: actionUrlConfig.UT_BUY_ENCRYPTALGORITHM,
        encryptType: actionUrlConfig.UT_BUY_ENCRYPTTYPE,
        encryptParams: actionUrlConfig.UT_BUY_ENCRYPTPARAMS,
        // encryptGsData: actionUrlConfig.UT_BUY_ENCRYPTGSDATA,
        actionUrl: actionUrlConfig.UT_BUY_URL,
      },
      {
        wireFrom: 'externalToBuySell',
        productCodeAlternativeClassificationCode: 'M',
        actionCode: 'P',
        wireSourceEvent: 'WDBuy',
        stepId: 'UT_LANDING',
        prodAltNum: row.fund.productAlternativeNum,
        productTypeCode: row.wpcProductType,
        countryProductTradableCode: row.countryProductTradableCode,
        productSubTypeCode: row.wpcProductSubType,
        //TODO ask thomas
        // holdingOrderInfo.rrspPlanHoldingOrderInformation check if it is a rrsp holding, useless for UT?
        // PortfolioDetailParser 641
        // investmentAccountNumber: row.accountNumber,
        // investmentAccountType: row.accountTypeCode,
        // investmentAccountProductTypeCode: row.accountInvestmentTypeCode,
        // investmentAccountCurrencyCode: row.currencyAccountCode,
        // investmentAccountCountryCode: row.countryInvestmentAccountCode,
        // investmentAccountGroupMember: row.groupMemberInvestmentAccountCode,
      }
    );
  };

  const onSell = (event: React.MouseEvent, row: DataType) => {
    loadFunc(event, 'accounttaxlotbreakdown', {
      target_screen_id: 'wealthdashboard-taxlots-portlet-screenid',
      product_type: row.feProductType,
      prodAltNum: row.fund.productAlternativeNum,
      PRODUCT_ALT_NUMBER: row.fund.productAlternativeNum,
      PRODUCT_INVESTMENT_DATA_STORE_NUMBER: row.productInvDataStoreNum,
      PRODUCT_DASHBOARD_TYPE: row.wdsProductType,
      PRODUCT_DASHBOARD_SUB_TYPE: row.wdsProductSubType,
      PRODUCT_CODE: row.productCode,
      PRODUCT_TYPE_CODE: row.feProductType,
      COUNTRY_PROD_TRAD_CODE: row.countryProductTradableCode,
      TRANSACTION_TYPE: 'SELL',
      productDashboardType: row.wpcProductType,
      productDashboardSubType: row.wpcProductSubType,
      productCode: row.productCode,
      productType: row.wpcProductType,
      productAltCode: row.fund.productAlternativeNum,
      productDataStore: row.productInvDataStoreNum,
      // originPage: originPage,
      originPage: 'myHoldings',
      // not exist-> selectedCurrency: row.ccy,
      displayProductType: row.feProductType,
      tradable: row.tradable,
    });
  };

  const parseSummaryData = (): InvestmentSummaryProps['data'] => {
    const info = systemState.summary?.portfolioDetailInformation.find(
      (it) => it.productDashboardTypeCode === 'UT'
    );
    const detail = info?.portfolioDetailMultipleCurrencyInformation.find(
      (it) => it.currencyTypeCode === CurrencyCodeType.LOCAL
    );
    return [
      {
        label: 'Market Value',
        currency: detail?.currencyProductHoldingMarketValueAmountCode,
        amount: detail?.productHoldingMarketValueAmount,
      },
      {
        label: 'Unrealised gain/loss',
        currency: detail?.currencyProfitLossUnrealizedAmountCode ?? undefined,
        amount: detail?.profitLossUnrealizedAmount ?? undefined,
        percent: detail?.profitLossUnrealizedPercent ?? undefined,
        showSign: true,
      },
      {
        label: 'Investment amount',
        currency: detail?.currencyProductHoldingBookValueAmountCode ?? undefined,
        amount: detail?.productHoldingBookValueAmount ?? undefined,
      },
      {
        label: 'Unit',
        amount: 1000,
      },
      {
        label: 'Cash Income',
        currency: detail?.currencyProductHoldingMarketValueAmountCode,
        amount: fake,
      },
      {
        label: 'Interest Expense',
        currency: detail?.currencyProductHoldingMarketValueAmountCode,
        amount: fake,
      },
    ];
  };

  type DataType = ReturnType<typeof parseData>[number];

  const renderText = (
    text: string | React.ReactElement,
    weight: 'light' | 'regular' | 'medium' = 'light'
  ) => {
    return (
      <Typography size={6} weight={weight}>
        {text}
      </Typography>
    );
  };

  const tableData = parseData();

  return (
    <div>
      <InvestmentSummary data={parseSummaryData()} />
      <div className={css.tableContainer}>
        <ExpandableTableV2
          emptyView={<EmptyResult label={'You do not have any investment products.'} />}
          errorView={
            holdingState.error && (
              <Result
                label={
                  'We are unable to display your holdings at this moment. Please try again later.'
                }
              />
            )
          }
          data={systemState.empty ? [] : tableData}
        >
          <TableColV2
            header={'Fund'}
            className={css.colFill}
            align={'left'}
            weight={'regular'}
            render={(row: DataType) => {
              return (
                <Space justify={'between'} align={'start'}>
                  <div>
                    <span>{row.fund.productName}</span>
                    <Space align={'center'} className={css.productInfo}>
                      <span>{row.fund.productAlternativeNum}</span>
                      <Tooltip direction={'bottom-right'} message={'Hong Kong'}>
                        <Tag theme={'dark'} size={7} className={css.productTag}>
                          HK
                        </Tag>
                      </Tooltip>
                      <Tooltip direction={'bottom-right'} message={'I.F'}>
                        <Tag theme={'light'} size={7} className={css.productTag}>
                          I.F.
                        </Tag>
                      </Tooltip>
                    </Space>
                  </div>
                  <QuickAction
                    showBuy={row.showBuyButton}
                    showSell={row.showSellButton}
                    showAddToWatchList={true}
                  />
                </Space>
              );
            }}
          />
          <TableColV2
            header={'Market Value'}
            className={css.colLarge}
            sorting={(a, b, direction) => {
              return numericSort(a.marketValue.localAmount, b.marketValue.localAmount, direction);
            }}
            defaultSortDirection={SortDirection.DESC}
            render={(row: DataType) => {
              return (
                <CurrencyAmount
                  size={'small'}
                  light={true}
                  currency={row.marketValue.currency ?? ''}
                  amount={row.marketValue.amount ?? '-'}
                />
              );
            }}
          />
          <TableColV2
            header={'Unrealised gain/loss'}
            className={css.colLarge}
            sorting={(a, b, direction) => {
              return numericSort(a.ugl.localAmount, b.ugl.localAmount, direction);
            }}
            render={(row: DataType) => {
              return (
                <CurrencyAmount
                  size={'small'}
                  light={true}
                  currency={row.ugl.currency ?? ''}
                  showSign={'percent' in row.ugl}
                  percent={row.ugl.percent ?? undefined}
                  amount={row.ugl.amount ?? '-'}
                />
              );
            }}
          />
          <TableColV2
            header={'Investment amount'}
            className={css.colLarge}
            sorting={(a, b, direction) => {
              return numericSort(
                a.investmentAmount.localAmount,
                b.investmentAmount.localAmount,
                direction
              );
            }}
            render={(row: DataType) => {
              return (
                <CurrencyAmount
                  size={'small'}
                  light={true}
                  currency={row.investmentAmount.currency ?? ''}
                  amount={row.investmentAmount.amount ?? '-'}
                />
              );
            }}
          />
          <TableColV2
            header={'NAV'}
            className={css.colSmall}
            sorting={(a, b, direction) => {
              return numericSort(a.nav.localAmount, b.nav.localAmount, direction);
            }}
            render={(row: DataType) => {
              return (
                <CurrencyAmount
                  size={'small'}
                  light={true}
                  currency={row.nav.currency ?? ''}
                  amount={row.nav.amount ?? '-'}
                />
              );
            }}
          />
          <TableColV2
            header={'Unit'}
            className={css.colSmall}
            sorting={(a, b, direction) => {
              return numericSort(a.unit.localAmount, b.unit.localAmount, direction);
            }}
            render={(row: DataType) => {
              return formatDigits(row.unit.amount ?? 0);
            }}
          />
          <TableColV2
            header={t('common.expandable.more')}
            className={css.colMore}
            align={'center'}
            weight={'regular'}
            render={(_, isExpanded, setIsExpanded) => {
              return (
                <ExpandControlV2
                  className={css.buttonMore}
                  isActive={isExpanded}
                  onClick={() => setIsExpanded(!isExpanded)}
                />
              );
            }}
            expand={(row: DataType) => (
              <div className={css.childRow}>
                <Space>
                  <span className={css.colExtra}>{renderText('Cash Income', 'regular')}</span>
                  <span className={css.colExtra}>
                    {renderText('HKD ' + formatDigits(fake), 'medium')}
                  </span>
                  <span className={css.colExtra}>{renderText('Interest expense', 'regular')}</span>
                  <span className={css.colExtra}>
                    {renderText('HKD ' + formatDigits(fake), 'medium')}
                  </span>
                </Space>
                <Space className={css.buttonGroup}>
                  {row.showBuyButton || (
                    <Button
                      className={css.quickButton}
                      icon={<IconBuy />}
                      onClick={(event) => onBuy(event, row)}
                    >
                      {t('quickMenu.buy')}
                    </Button>
                  )}
                  {row.showSellButton && (
                    <Button
                      className={css.quickButton}
                      icon={<IconSell />}
                      onClick={(event) => onSell(event, row)}
                    >
                      {t('quickMenu.sell')}
                    </Button>
                  )}
                  <Button className={css.quickButton} icon={<IconAddWatch />}>
                    {t('quickMenu.addToWatchlist')}
                  </Button>
                </Space>
              </div>
            )}
          />
        </ExpandableTableV2>
      </div>
    </div>
  );
};
