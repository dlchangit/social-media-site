import React, { useEffect, useRef, useState } from 'react';
import css from './InvestmentTable.module.scss';
import { CurrencyAmount, Space, Typography } from '../../../components';

export interface InvestmentSummaryProps {
  data: {
    label: string;
    currency?: string;
    amount?: number;
    percent?: number;
    showSign?: boolean;
  }[];
}

export const InvestmentSummary: React.FC<InvestmentSummaryProps> = (props) => {
  const ref = useRef() as React.MutableRefObject<HTMLDivElement>;

  const [minWidth, setMinWidth] = useState(0);

  useEffect(() => {
    if (!ref.current) return;
    const kids = Array.from(ref.current.children);
    let max = 0;
    kids.forEach((it) => {
      max = Math.max(max, it.clientWidth);
    });
    setMinWidth(max + 2);
  }, [JSON.stringify(props.data)]);

  return (
    <div className={css.summaryContainer}>
      <Typography size={5} weight={'medium'} className={css.summaryTitle}>
        Total Summary
      </Typography>
      <Space wrap={true} className={css.summaryDetail} ref={ref}>
        {props.data.map((it, index) => {
          return (
            <CurrencyAmount
              key={index + 1}
              label={it.label}
              currency={it.currency ?? ''}
              amount={it.amount ?? '-'}
              percent={it.percent}
              showSign={it.showSign}
              size={'small'}
              className={css.summaryGutter}
              style={{ width: minWidth !== 0 ? minWidth : undefined }}
            />
          );
        })}
      </Space>
    </div>
  );
};
