import css from './InvestmentTable.module.scss';
import React from 'react';
import { useTranslation } from 'react-i18next';
import {
  Button,
  CurrencyAmount,
  EmptyResult,
  ExpandableTableV2,
  ExpandControlV2,
  IconAddWatch,
  IconBuy,
  IconSell,
  LoadingView,
  Result,
  Space,
  TableColV2,
  Tag,
  Tooltip,
  Typography,
} from '../../../components';
import { InvestmentSummary, InvestmentSummaryProps } from './InvestmentSummary';
import * as faker from 'faker';
import { formatDigits } from '../../../utils/math';
import { QuickAction } from './QuickAction';
import { selectSystem } from '../../common/saga';
import { selectMyHoldings } from '../saga';
import { numericSort, SortDirection } from '../../../utils/sort';
import { CurrencyCodeType } from '../../../utils/currency';
import { WealthDashboardPresConstants } from '../../../utils/WealthDashboardPresConstants';

const summaryData: InvestmentSummaryProps['data'] = [
  {
    label: 'Market Value',
    showSign: false,
    currency: 'HKD',
  },
  {
    label: 'Unrealised gain/loss',
    showSign: true,
    currency: 'HKD',
  },
  {
    label: 'Investment amount',
    showSign: false,
    currency: 'HKD',
  },
  {
    label: 'Unit',
    showSign: false,
  },
  {
    label: 'Cash Income',
    showSign: false,
    currency: 'HKD',
  },
].map((it) => {
  return {
    ...it,
    amount: faker.random.number(10000000),
    percent: it.showSign ? faker.random.number(100) : undefined,
  };
});

export const TableFlexInvest: React.FC = () => {
  const { t } = useTranslation();

  const systemState = selectSystem();
  const holdingState = selectMyHoldings();

  const parseData = () => {
    return (
      holdingState.unitTrust?.holdingOrderInformation?.map((it) => {
        const info = it.holdingDetailInformation[0];
        const detail = info.holdingDetailMultipleCurrencyInformation.find(
          (it) => it.currencyTypeCode === holdingState?.preference?.currencyCodeType
        );

        const localDetail = info.holdingDetailMultipleCurrencyInformation.find(
          (it) => it.currencyTypeCode === CurrencyCodeType.LOCAL
        );

        // PortfolioDetailParser 964
        // TODO to be confirmed with BA, how to use this value
        // hdOrderInfo.setProductAlternativeNum(holdingOrderInfo.getProductAlternativeNumber());
        const prodId = it.productIdInformation?.find(
          (id) =>
            WealthDashboardPresConstants.TR_CODE_DISPLAY ==
            id.productCodeAlternativeClassificationCode
        );

        return {
          fund: {
            productName: it.productShortName,
            productAlternativeNum: prodId?.productAlternativeNumber,
            tags: ['UT'],
          },
          marketValue: {
            currency: detail?.currencyProductHoldingMarketValueAmountCode,
            amount: detail?.productHoldingMarketValueAmount,
            localAmount: localDetail?.productHoldingMarketValueAmount,
          },
          ugl: {
            currency: detail?.currencyProfitLossUnrealizedAmountCode,
            amount: detail?.profitLossUnrealizedAmount,
            localAmount: localDetail?.profitLossUnrealizedAmount,
            percent: detail?.profitLossUnrealizedPercent,
          },
          investmentAmount: {
            currency: detail?.currencyProductHoldingBookValueAmountCode,
            amount: detail?.productHoldingBookValueAmount,
            localAmount: localDetail?.productHoldingBookValueAmount,
          },
          nav: {
            currency: info?.currencyProductMarketPriceCode,
            amount: info.productMarketPriceAmount,
            localAmount: info.productMarketPriceAmount,
          },
          unit: {
            amount: info.productHoldingQuantityCount,
            localAmount: info.productHoldingQuantityCount,
          },
        };
      }) ?? []
    );
  };

  type DataType = ReturnType<typeof parseData>[number];

  const renderText = (
    text: string | React.ReactElement,
    weight: 'light' | 'regular' | 'medium' = 'light'
  ) => {
    return (
      <Typography size={6} weight={weight}>
        {text}
      </Typography>
    );
  };

  const tableData = parseData();

  return (
    <div>
      <InvestmentSummary data={summaryData} />
      <div className={css.tableContainer}>
        <ExpandableTableV2
          emptyView={<EmptyResult label={'You do not have any investment products.'} />}
          loadingView={holdingState.loading && <LoadingView message={'Loading'} />}
          errorView={
            holdingState.error && (
              <Result
                label={
                  'We are unable to display your holdings at this moment. Please try again later.'
                }
              />
            )
          }
          data={systemState.empty ? [] : tableData}
        >
          <TableColV2
            header={'Fund'}
            className={css.colFill}
            align={'left'}
            weight={'regular'}
            render={(row: DataType) => {
              return (
                <Space justify={'between'}>
                  <div>
                    <span>{row.fund.productName}</span>
                    <Space align={'center'} className={css.productInfo}>
                      <span>{row.fund.productAlternativeNum}</span>
                      <Tooltip direction={'bottom-right'} message={'Hong Kong'}>
                        <Tag theme={'dark'} size={7} className={css.productTag}>
                          HK
                        </Tag>
                      </Tooltip>
                      <Tooltip direction={'bottom-right'} message={'I.F'}>
                        <Tag theme={'light'} size={7} className={css.productTag}>
                          I.F.
                        </Tag>
                      </Tooltip>
                    </Space>
                  </div>
                  <QuickAction showBuy={true} showSell={true} showAddToWatchList={true} />
                </Space>
              );
            }}
          />
          <TableColV2
            header={'Market Value'}
            className={css.colLarge}
            sorting={(a, b, direction) => {
              return numericSort(a.marketValue.localAmount, b.marketValue.localAmount, direction);
            }}
            defaultSortDirection={SortDirection.DESC}
            render={(row: DataType) => {
              return (
                <CurrencyAmount
                  size={'small'}
                  light={true}
                  currency={row.marketValue.currency ?? ''}
                  amount={row.marketValue.amount ?? '-'}
                />
              );
            }}
          />
          <TableColV2
            header={'Unrealised gain/loss'}
            className={css.colLarge}
            sorting={(a, b, direction) => {
              return numericSort(a.ugl.localAmount, b.ugl.localAmount, direction);
            }}
            render={(row: DataType) => {
              return (
                <CurrencyAmount
                  size={'small'}
                  light={true}
                  currency={row.ugl.currency ?? ''}
                  showSign={'percent' in row.ugl}
                  percent={row.ugl.percent ?? undefined}
                  amount={row.ugl.amount ?? '-'}
                />
              );
            }}
          />
          <TableColV2
            header={'Investment amount'}
            className={css.colLarge}
            sorting={(a, b, direction) => {
              return numericSort(
                a.investmentAmount.localAmount,
                b.investmentAmount.localAmount,
                direction
              );
            }}
            render={(row: DataType) => {
              return (
                <CurrencyAmount
                  size={'small'}
                  light={true}
                  currency={row.investmentAmount.currency ?? ''}
                  amount={row.investmentAmount.amount ?? '-'}
                />
              );
            }}
          />
          <TableColV2
            header={'NAV'}
            className={css.colSmall}
            sorting={(a, b, direction) => {
              return numericSort(a.nav.localAmount, b.nav.localAmount, direction);
            }}
            render={(row: DataType) => {
              return (
                <CurrencyAmount
                  size={'small'}
                  light={true}
                  currency={row.nav.currency ?? ''}
                  amount={row.nav.amount ?? '-'}
                />
              );
            }}
          />
          <TableColV2
            header={'Unit'}
            className={css.colSmall}
            sorting={(a, b, direction) => {
              return numericSort(a.unit.localAmount, b.unit.localAmount, direction);
            }}
            render={(row: DataType) => {
              return formatDigits(row.unit.amount ?? 0);
            }}
          />
          <TableColV2
            header={t('common.expandable.more')}
            className={css.colMore}
            align={'center'}
            weight={'regular'}
            render={(_, isExpanded, setIsExpanded) => {
              return (
                <ExpandControlV2 isActive={isExpanded} onClick={() => setIsExpanded(!isExpanded)} />
              );
            }}
            expand={() => (
              <div className={css.childRow}>
                <Space>
                  <span className={css.colExtra}>{renderText('Cash Income', 'regular')}</span>
                  <span className={css.colExtra}>
                    {renderText('HKD ' + formatDigits(faker.random.number(10000)), 'medium')}
                  </span>
                </Space>
                <Space className={css.buttonGroup}>
                  <Button className={css.quickButton} icon={<IconBuy />}>
                    {t('quickMenu.buy')}
                  </Button>
                  <Button className={css.quickButton} icon={<IconSell />}>
                    {t('quickMenu.sell')}
                  </Button>
                  <Button className={css.quickButton} icon={<IconAddWatch />}>
                    {t('quickMenu.addToWatchlist')}
                  </Button>
                </Space>
              </div>
            )}
          />
        </ExpandableTableV2>
      </div>
    </div>
  );
};
