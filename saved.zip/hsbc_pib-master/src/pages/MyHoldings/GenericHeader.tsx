import React, { useEffect, useState } from 'react';

import cn from 'classnames';
import css from './GenericHeader.module.scss';
import { useTranslation } from 'react-i18next';
import { normalizeAccounts } from '../../utils/account';
import { formatDateTime } from '../../utils/date';
import { selectSystem } from '../common/saga';
import { fetchMyHoldings, selectMyHoldings, setMyHoldingsPreference } from './saga';
import { useDispatch } from 'react-redux';
import {
  Button,
  ChevronAnchor,
  DropdownItem,
  ErrorBanner,
  GlobalHeader,
  IconRefresh,
  MultipleDropdown,
  Space,
  Typography,
} from '../../components';

interface GenericHeaderProps {
  pageTitle: string;
  error?: string;
}

export const GenericHeader: React.VFC<GenericHeaderProps> = (props) => {
  const { t } = useTranslation();

  const { pageTitle, error } = props;

  const dispatch = useDispatch();
  const systemState = selectSystem();
  const holdingState = selectMyHoldings();

  // const normalized = normalizeAccounts(holdingState.unitTrust?.accountGroupInformation ?? [], t);
  const normalized: any[] = [];
  const [selected, setSelected] = useState<string[]>(normalized.map((it) => it.value));

  useEffect(() => {
    if (holdingState.cacheDateTime && !holdingState.preference) {
      dispatch(
        setMyHoldingsPreference({
          accounts: normalizeAccounts(holdingState.unitTrust?.accountGroupInformation ?? [], t).map(
            (it) => it.value
          ),
        })
      );
    }
  }, [holdingState.cacheDateTime]);

  const onApply = () => {
    dispatch(
      setMyHoldingsPreference({
        accounts: selected,
      })
    );
  };

  const lastUpdated = () => {
    return (
      <Space align={'center'}>
        {holdingState.cacheDateTime && (
          <div>
            <div>{t('common.lastUpdated')}:</div>
            <div>{formatDateTime(new Date(holdingState.cacheDateTime), systemState.timezone)}</div>
          </div>
        )}
        <Button
          icon={<IconRefresh />}
          className={css.buttonRefresh}
          onClick={() => {
            dispatch(fetchMyHoldings(holdingState.preference.productType));
          }}
        />
      </Space>
    );
  };

  const renderDropdown = () => {
    if (systemState.error) {
      return <ErrorBanner className={css.errorBanner}>{systemState.error}</ErrorBanner>;
    }
    if (error) {
      return <ErrorBanner className={css.errorBanner}>{error}</ErrorBanner>;
    }

    return (
      <Space className={cn(css.dropdownContainer)} justify={'end'} align={'end'} wrap={true}>
        <div className={cn(css.account)}>
          <MultipleDropdown
            className={css.dropdown}
            allOption={t('myHoldings.dropdown.accounts.all')}
            placeholder={t('myHoldings.dropdown.accounts.placeholder')}
            values={selected}
            onChange={(accounts) => setSelected(accounts)}
          >
            {normalized.map((it, index) => (
              <DropdownItem key={index} value={it.value}>
                {it.label}
              </DropdownItem>
            ))}
          </MultipleDropdown>
        </div>
        <Button className={css.buttonApply} secondary onClick={onApply}>
          {t('common.apply')}
        </Button>
        {lastUpdated()}
      </Space>
    );
  };

  return (
    <div className={css.container}>
      <GlobalHeader />
      <div className={css.desktopView}>
        <Typography size={4} weight={'light'}>
          <ChevronAnchor href={'/#'} direction={'backward'}>
            {t('common.backToMyWealthDashboard')}
          </ChevronAnchor>
        </Typography>
        <Space align={'center'} className={css.pageTitle}>
          <Typography size={2} weight={'light'}>
            {pageTitle}
          </Typography>
          {renderDropdown()}
        </Space>
      </div>
    </div>
  );
};
