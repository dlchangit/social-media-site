import { all, call, put, takeLatest } from 'redux-saga/effects';
import { MyHoldingsState } from './reducer';
import { ActionPayload } from '../common/reducer';
import { AllEffect, ForkEffect } from '@redux-saga/core/effects';
import { useSelector } from 'react-redux';
import { RootState } from '../../store';
import { fetchWrapper } from '../../utils/fetch';
import { AxiosResponse } from 'axios';
import { R18Response } from '../../@types/R18Response';

export const SET_MY_HOLDINGS = 'SET_MY_HOLDINGS';
export const FETCH_MY_HOLDINGS = 'FETCH_MY_HOLDINGS';
export const FETCHING_MY_HOLDINGS = 'FETCHING_MY_HOLDINGS';
export const SET_MY_HOLDINGS_PREFERENCE = 'SET_MY_HOLDINGS_PREFERENCE';
export const SET_MY_HOLDINGS_ERROR = 'SET_MY_HOLDINGS_ERROR';

export function setMyHoldingsPreference(
  payload: Partial<MyHoldingsState['preference']>
): ActionPayload {
  return { type: SET_MY_HOLDINGS_PREFERENCE, payload };
}

export function fetchMyHoldings(productType: string): ActionPayload {
  return { type: FETCH_MY_HOLDINGS, payload: '/api/' + productType, productType };
}

function* doFetchMyHoldings(action: ActionPayload) {
  try {
    yield put({ type: FETCHING_MY_HOLDINGS, payload: true });
    yield put({ type: SET_MY_HOLDINGS_ERROR, payload: undefined });
    const response: AxiosResponse<R18Response> = yield call(fetchWrapper, action.payload);
    yield put({ type: SET_MY_HOLDINGS, payload: response.data, productType: action.productType });
    yield put({ type: FETCHING_MY_HOLDINGS, payload: false });
  } catch (e) {
    yield put({ type: SET_MY_HOLDINGS_ERROR, payload: e.message });
    yield put({ type: FETCHING_MY_HOLDINGS, payload: false });
  }
}

export function* watchFetchMyHoldings(): Generator<ForkEffect> {
  yield takeLatest(FETCH_MY_HOLDINGS, doFetchMyHoldings);
}

export const selectMyHoldings = (): MyHoldingsState =>
  useSelector((state: RootState) => state.holding);

export default function* rootSaga(): Generator<AllEffect<any>> {
  yield all([watchFetchMyHoldings()]);
}
