import {
  FETCHING_MY_HOLDINGS,
  SET_MY_HOLDINGS,
  SET_MY_HOLDINGS_ERROR,
  SET_MY_HOLDINGS_PREFERENCE,
} from './saga';
import { R18Response } from '../../@types/R18Response';
import { ActionPayload } from '../common/reducer';
import { CurrencyCodeType } from '../../utils/currency';
import config from '../../config/HK/common/config/pib';

export interface MyHoldingsState {
  unitTrust?: R18Response;
  capitalProtectedInvestments?: R18Response;
  depositPlus?: R18Response;
  loading: boolean;
  error?: string;
  cacheDateTime?: string;
  preference: {
    accounts: string[];
    productType: typeof config['myHoldings']['filter']['productType'][number];
    currencyCodeType: CurrencyCodeType;
  };
}

const initialState: MyHoldingsState = {
  unitTrust: undefined,
  capitalProtectedInvestments: undefined,
  depositPlus: undefined,
  cacheDateTime: undefined,
  loading: false,
  error: undefined,
  preference: {
    accounts: [],
    productType: config['myHoldings']['filter']['productType'][0],
    currencyCodeType: CurrencyCodeType.PRODUCT,
  },
};

export default function reducer(state = initialState, action: ActionPayload): MyHoldingsState {
  switch (action.type) {
    case SET_MY_HOLDINGS:
      return {
        ...state,
        [action.productType]: action.payload,
        cacheDateTime: new Date().toISOString(),
      };
    case FETCHING_MY_HOLDINGS:
      return { ...state, loading: action.payload };
    case SET_MY_HOLDINGS_PREFERENCE:
      return {
        ...state,
        preference: {
          ...state.preference,
          ...action.payload,
        },
      };
    case SET_MY_HOLDINGS_ERROR:
      return { ...state, error: action.payload };
    default:
      return state;
  }
}
