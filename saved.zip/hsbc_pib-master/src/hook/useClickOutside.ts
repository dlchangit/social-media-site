import React from 'react';

export const useClickOutside: (
  onOutsideClicked: () => void,
  exclude: React.RefObject<HTMLElement>[]
) => void = (onOutsideClicked, exclude: React.RefObject<HTMLElement>[] = []) => {
  const handleHideDropdown = (event: KeyboardEvent) => {
    if (event.key === 'Escape') {
      onOutsideClicked();
    }
  };

  const handleClickOutside = (event: Event) => {
    const excluded = exclude.some(
      (item) =>
        (event.target as Node) === item.current || item.current?.contains(event.target as Node)
    );
    if (!excluded) {
      onOutsideClicked();
    }
  };

  React.useEffect(() => {
    document.addEventListener('keydown', handleHideDropdown, true);
    document.addEventListener('click', handleClickOutside, true);
    return () => {
      document.removeEventListener('keydown', handleHideDropdown, true);
      document.removeEventListener('click', handleClickOutside, true);
    };
  });
};
