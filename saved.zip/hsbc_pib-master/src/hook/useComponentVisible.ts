import React from 'react';

export const useComponentVisible: (
  initialIsVisible: boolean,
  exclude?: React.RefObject<HTMLElement>[]
) => {
  ref: React.MutableRefObject<HTMLDivElement | null>;
  isComponentVisible: boolean;
  setIsComponentVisible: (value: ((prevState: boolean) => boolean) | boolean) => void;
} = (initialIsVisible: boolean, exclude: React.RefObject<HTMLElement>[] = []) => {
  const [isComponentVisible, setIsComponentVisible] = React.useState(initialIsVisible);
  const ref = React.useRef<HTMLDivElement>(null);

  const handleHideDropdown = (event: KeyboardEvent) => {
    if (event.key === 'Escape') {
      setIsComponentVisible(false);
    }
  };

  const handleClickOutside = (event: Event) => {
    const excluded = exclude.some(
      (item) =>
        (event.target as Node) === item.current || item.current?.contains(event.target as Node)
    );
    if (!excluded && ref.current && !ref.current.contains(event.target as Node)) {
      setIsComponentVisible(false);
    }
  };

  React.useEffect(() => {
    document.addEventListener('keydown', handleHideDropdown, true);
    document.addEventListener('click', handleClickOutside, true);
    return () => {
      document.removeEventListener('keydown', handleHideDropdown, true);
      document.removeEventListener('click', handleClickOutside, true);
    };
  });

  return { ref, isComponentVisible, setIsComponentVisible };
};
