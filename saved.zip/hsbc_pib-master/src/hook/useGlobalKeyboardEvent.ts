import { useEffect } from 'react';

export const useGlobalKeyboardEvent = (keyCode: string, callback: () => void): void => {
  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if (event.code === keyCode) {
        callback();
      }
    };
    document.addEventListener('keydown', handler);
    return () => {
      document.removeEventListener('keydown', handler);
    };
  });
};
