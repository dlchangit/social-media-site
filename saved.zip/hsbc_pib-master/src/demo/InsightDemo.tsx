import React from 'react';
import { InsightCard } from '../components/Insight';
import { Article } from '../components/Insight';
import { IconAnchor } from '../components/Anchor';
import { Holding } from '../components/Holding';
import { Divider } from '../components/Divider';
import imgOffer from './assets/img_01_dashboard_whats_new_380x214@2x.png';
import styled from 'styled-components';
import { Typography } from '../components/Typography';

const Image = styled.img`
  display: block;
  //width: 378px;
  width: 100%;
  height: 214px;
`;
export const GenericNews: React.VFC = () => {
  return (
    <InsightCard
      top={<Image src={imgOffer} alt="" />}
      divider={<Divider />}
      bottom={
        <Article
          title={'Unit Trust Offers'}
          content={
            'New customers: Initial changer offer as low as 1% and first 6 month initial charge waiver for Unit Trust Monthly Investment Plan.'
          }
          anchor={
            <IconAnchor style={{ marginTop: 20 }} href={'/view-offers'}>
              View offers
            </IconAnchor>
          }
        />
      }
      // like={<IconAnchor href={'/'} label={'13,000 likes'} icon={<IconChart />} />}
      // share={<IconAnchor href={'/'} label={'share'} icon={<IconChart />} />}
    />
  );
};

export const ArticleHolding: React.VFC = () => {
  return (
    <InsightCard
      top={
        <Article
          title={
            "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book"
          }
          content={
            'The COVID-19 pandemic has delivered a significant blow to financial markets globally and brought uncertainty, as never seen before. Yet, amongst the myriad of investment and saving decisions, financial planning for overseas education, for their children and next generation, still remains a key priority for investors.'
          }
          anchor={
            <IconAnchor style={{ marginTop: 16, marginBottom: 20 }} href={'/view-full-article'}>
              View full article
            </IconAnchor>
          }
        />
      }
      divider={<Divider />}
      bottom={
        <div style={{ padding: '16px 20px 0 20px' }}>
          <Typography size={5} weight="light">
            Related holdings
          </Typography>
          <Holding
            style={{ marginTop: 12 }}
            currency={'USD'}
            amount={584.76}
            percentage={17.16}
            stock={'Tesla, Inc.'}
            symbol={'TSLA'}
          />
          <Divider />
          <Holding
            style={{ marginTop: 12 }}
            currency={'USD'}
            amount={584.76}
            percentage={-7.16}
            stock={'Nio, Inc.'}
            symbol={'NIO'}
          />
        </div>
      }
    />
  );
};
