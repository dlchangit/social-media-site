import i18n from 'i18next';
import translationEN from './en_US';
import { initReactI18next } from 'react-i18next';

export const resources = {
  en_us: {
    translation: translationEN,
  },
  // zh_hk: {
  //   translation: translationHK,
  // },
} as const;

i18n.use(initReactI18next).init({
  lng: 'en_us',
  // keySeparator: false,
  resources,
});
