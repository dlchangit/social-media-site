const r18 = require('./R18-response example-1.json');
const transactionHistory = require('./RetrieveTransactionHistory-Resp1.json');
const investment = require('./R18-response example-2(Investments dropdown).json');

const summary = require('./mobile-investment.json');
const unitTrust = require('./mobile-ut.json');
const bondsAndCds = require('./mobile-bonds.json');
const depositPlus = require('./mobile-dps.json');
const capitalProtectedInvestments = require('./mobile-sid.json');

const jsonServer = require('json-server');
const server = jsonServer.create();
const router = jsonServer.router({
  account: r18,
  'transaction-history': transactionHistory,
  investment,
  summary,
  unitTrust,
  flexInvest: unitTrust,
  bondsAndCds,
  depositPlus,
  capitalProtectedInvestments,
});
const middlewares = jsonServer.defaults();

server.use(middlewares);
server.use(function (req, res, next) {
  setTimeout(next, 1000);
});
server.use('/api', router);
server.listen(3001, () => {
  console.log('JSON Server is running at port 3001');
});
