module.exports = {
  ENTITIES: ['hk'],
};
