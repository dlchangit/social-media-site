const path = require('path');
const config = require('./config');
const df = require('date-fns');
const fs = require('fs');
const glob = require('glob');
const merge = require('deepmerge');
const env = (() => {
  let e = 'unittest';
  process.argv.forEach(str => {
    if (str.match(/config=.*/g))
      e = str.replace('config=', '');
  });
  return e;
})();

const parsers = {
  'parseAccountTypeConfig': (entries, keyColumn) => {
    console.log('parseAccountTypeConfig', entries);
    let map = {};
    const acctFormatToSuffixWildCard = (acctFormat) => {
      return acctFormat.substring(acctFormat.length - 3).replace(/NNN/g, '*');
    };
    entries.forEach((entry, i) => {
      let key = entry.acctType + '-' + entry.acctProdType + '-' + acctFormatToSuffixWildCard(entry.acctFormat);
      console.log('acctTypeKey', key);
      map[key] = entry;
    });
    return map;
  },
  'parseColumnToKey': (entries, keyColumn) => {
    console.log('parseColumnToKey', entries);
    let map = {};
    entries.forEach((entry, i) => {
      let key = entry[keyColumn];
      // let keyArry = Object.keys(entry);
      // let key =  entry[keyArry[0]];
      console.log('firstKey', key);
      map[key] = entry;
    });
    return map;
  },
};

const parseConfig = function(filepath) {
  let data = fs.readFileSync(filepath, 'utf8');
  let objs = [];
  let i = 1;

  console.log('parse config with metadata');
  // let configWithmetaData = data.match(/<!--config.*metadata((.|\n|\r)*)metadata-->/g);
  let configWithmetaData = data.match(/<!--config.*metadata/g);
  console.log('configWithmetaData', configWithmetaData);
  if (configWithmetaData == null || configWithmetaData.length == 0) {
  } else {
    console.log(`found ${configWithmetaData.length} configWithmetaData`);
    configWithmetaData.forEach((meta) => {
      //let jsonStr = meta.replace(/<!--config.*metadata/g, "").replace(/-->/g,"");
      //console.log('jsonStr = ', jsonStr);
      //metaDatObj = JSON.parse(jsonStr);

      let configId = meta.match(/config\..*\:metadata/g)[0];
      configId = configId.substring(7, configId.length - 9);
      console.log('config id = ', configId);

      let jsObj = extractConfigTables(data, configId);
      objs.push(jsObj);
      i++;
    });
  }
  //return objs;

  let blocks = data.match(/<!--config\..*-->((\n|\r)*)\`\`\`\s*javascript\s*(([^`]|\n|\r)*)\`\`\`/g);

  if (blocks == null || blocks.length == 0) {
  } else {
    console.log(`found ${blocks.length} blocks`);
    blocks.forEach((block) => {
      let jsObj = extractCodeBlockToJson(block, i);
      objs.push(jsObj);
      i++;
    });
  }

  i = i;
  let inlines = data.match(/<!--config\..*-->\s*\`[^`\r\n]+\`/g);
  if (inlines == null || inlines.length == 0) {
  } else {
    console.log(`found ${inlines.length} inlines`);
    inlines.forEach((inlines) => {
      let jsObj = extractInlineToJson(inlines, i);
      objs.push(jsObj);
      i++;
    });
  }
  return merge.all(objs);
};


/**
 * Sample config
 <!--config.pas.accounttype:metadata
 {
"method":"MARKDOWN_TABLE_TO_JSON",
"columns":["", "", "acctType", "acctProdType", "acctFormat", "isAllowSelect", "isAllowRebalance"],
"configParser": "parseAccountTypeConfig"
}
 -->

 <!--config.pas.accounttype:START-->
 | Account Description | Group Member | Product Type | Product Code | Account Format | Eligible for Account Selection | Eligible for re-balancing service |
 | --     | --| --     | --| --     | --| --  |
 | HSBC Premier Investment Services | HBAP | SEC | AVA | NNN-NNNNNC-NNN | YES | YES
 | HSBC Premier Investment Services | HBAP | SEC | AVF | NNN-NNNNNC-NNN | YES | YES
 | HSBC Premier Investment Services | HBAP | SEC | AVT | NNN-NNNNNC-NNN | YES | YES
 | HSBC Investment Service | HBAP | SEC | HPS | NNN-NNNNNC-NNN | YES | YES
 | HSBC Investment Service | HBAP | SEC | INF | NNN-NNNNNC-NNN | YES | YES
 | HSBC Investment Service | HBAP | SEC | INS | NNN-NNNNNC-NNN | YES | YES
 | HSBC Investment Service | HBAP | SEC | INT | NNN-NNNNNC-NNN | YES | YES
 | HSBC Investment Service | HBAP | SEC | INV | NNN-NNNNNC-NNN | YES | YES
 | HSBC Investment Service | HBAP | SEC | MAV | NNN-NNNNNC-NNN | YES | YES
 | HSBC Investment Service | HBAP | SEC | MPV | NNN-NNNNNC-NNN | YES | YES
 | HSBC Investment Service | HBAP | SEC | MSV | NNN-NNNNNC-NNN | YES | YES
 | HSBC Investment Service | HBAP | SEC | OSS | NNN-NNNNNC-NNN | YES | YES
 | HSBC Investment Service | HBAP | SEC |     | NNN-NNNNNC-NNN | YES | YES
 | Unit Trust HKD Financing | HBAP | SEC |    | NNN-NNNNNC-368 | YES | NO
 | Unit Trust USD Financing | HBAP | SEC |    | NNN-NNNNNC-369 | YES | NO
 | HSBC Investment Service | HBAP | SEC | SEC | NNN-NNNNNC-085 | NO  | NO
 | HSBC Personal Integrated Account Investment Services | HBAP | SEC | SVA | NNN-NNNNNC-NNN | YES | YES
 | HSBC Advance Investment Services | HBAP | SEC | YPF | NNN-NNNNNC-NNN | YES | YES
 | HSBC Advance Investment Services | HBAP | SEC | YPO | NNN-NNNNNC-NNN | YES | YES
 | HSBC Advance Investment Services | HBAP | SEC | YPP | NNN-NNNNNC-NNN | YES | YES
 | HSBC Advance Investment Services | HBAP | SEC | YPT | NNN-NNNNNC-NNN | YES | YES
 | HSBC Investment Services | HBAP | POR |  | NNN-NNNNNC-NNN | YES | YES
 | HSBC Investment Services | HBAP | POR | HPO | NNN-NNNNNC-NNN | YES | YES
 | HSBC Investment Services | HBAP | POR | PPO | NNN-NNNNNC-NNN | YES | YES
 | HSBC Investment Services | HBAP | SEC | HPO | NNN-NNNNNC-NNN | YES | YES
 | HSBC Investment Services | HBAP | SEC | PPO | NNN-NNNNNC-NNN | YES | YES
 <!--config.pas.accounttype:END-->
 *
 */
const extractConfigTables = function(data, configId) {
  let posLMetadata = data.indexOf(`<!--config.${configId}:metadata`);
  let posRMetadata = data.indexOf('metadata-->', posLMetadata);
  let metadataStr = data.substring(posLMetadata, posRMetadata).replace(/<!--config.*metadata/g, '').replace(/metadata-->/g, '');
  console.log(`configId:${configId}  metadataStr: ${metadataStr}`);
  let metadataObj = JSON.parse(metadataStr);
  let colNames = metadataObj.columns;
  if ('MARKDOWN_TABLE_TO_JSON' === metadataObj.method) {
    let regex = new RegExp(`<!--config.${configId}\:START-->((.|\n|\r)*)<!--config.${configId}\:END-->`, 'g');
    let block = data.match(regex);
    if (block != null && block.length >= 0) {
      let table = block[0].replace(`<!--config.${configId}\:START-->`, '')
        .replace(`<!--config.${configId}\:END-->`, '').trim();
      let lines = table.split(/\n/g);

      let configObj = {};
      let entries = [];
      lines.forEach((line, row) => {

        if (row > 1) {
          let entry = {};
          line.split('|').forEach((val, i) => {
            if (i > 0 && colNames[i - 1]) {
              entry[colNames[i - 1]] = val.trim();
            }
          });
          if (metadataObj.configParser)
            entries.push(entry);
          if (!metadataObj.configParser && metadataObj.keyFormat) {
            let key = formatStr(metadataObj.keyFormat, entry);
            configObj[key] = entry;
          }
        }
      });
      if (metadataObj.configParser)
        configObj = parsers[metadataObj.configParser](entries, metadataObj.keyColumn);

      let jsonPath = configId.split('.');
      jsonPath.reverse().forEach((nodeName) => {
        let obj = {};
        obj[nodeName] = configObj;
        configObj = obj;
      });
      return configObj;
    } else {
      console.log(`WARN : meta data method not understood : ${metadataObj.method}, configId : ${configId}`);
    }
  }


};

const formatStr = function(str, context) {
  return str.replace(/\${\w+}/g, function(match, number) {
    let key = match.substring(2, match.length - 1);
    if (key in context) {
      return context[key];
    }
    return match;
  });
};

//e.g. <!--config.PAS.baseCurrency-->`HKD`
const extractInlineToJson = function(inline, descriptor) {
  let comment = inline.match(/<!--config\..*-->\s*/g)[0];
  let jsonPath = comment.replace('<!--config.', '').replace(/-->\s*/g, '').trim();
  console.log('inline config : ' + jsonPath);
  let jsonPaths = jsonPath.split('.');
  let val = inline.replace(comment, '').replace(/\`/g, '').trim();
  let numVal = Number(val);
  if (!isNaN(numVal))
    val = numVal;
  jsonPaths.reverse().forEach((nodeName) => {
    let obj = {};
    obj[nodeName] = val;
    val = obj;
  });
  // console.log('parsed obj', val);
  return val;
};


/**
 * Extract code block in the following pattern:
 * <!--config.{config filename}.{object path of the config}
 * ```javascript
 * {json string}
 * e.g.
 <!--config.PAS.spendingCountry-->
 ```javascript
 [
 {"code":"AU","amount":196656},
 {"code":"CA","amount":143174},
 {"code":"GB","amount":195501},
 {"code":"US","amount":149505},
 {"code":"HK","amount":42100},
 {"code":"HN","amount":146000}
 ]
 ```
 */
const extractCodeBlockToJson = function(block, descriptor) {
  let top = block.match(/<!--config\..*-->((\n|\r)*)\`\`\`.?javascript.*((\n|\r)*)/g);
  let jsonPaths = top[0].match(/<!--config\..*-->/g)[0];
  console.log('jsonPaths : ', jsonPaths);
  jsonPaths = jsonPaths.replace('<!--config.', '').replace('-->', '').trim().split('.');
  //console.log(`block ${descriptor} top = `+ top);
  let code = block.replace(top, '').replace('\`\`\`', '');
  //console.log('code = '+ code);
  let val = JSON.parse(code);
  jsonPaths.reverse().forEach((nodeName) => {
    let obj = {};
    obj[nodeName] = val;
    val = obj;
  });
  console.log('parsed obj', val);
  return val;
};

const buildConfig = function() {
  let entities = config.ENTITIES; //environment config
  entities.forEach((entityCode) => {
    let entity = entityCode.toUpperCase().split('-');
    buildConfigOfSelectedEntity(entity[0]);
  });
};

const buildConfigOfSelectedEntity = function(countryCode) {
  //combine the nls files start
  //TODO : get the parameters from environments
  const inputBizConfigDir = `./configurator/bizConfig/${countryCode}`;
  const inputItConfigDir = `./configurator/techConfig/${countryCode}`;
  const outputConfigDir = `./src/config/${countryCode}/common/config/`;

  let configMd;
  let outputs = [];
  console.log('env  = ' + env);

  //for each MD file
  configMd = glob.sync(`${inputBizConfigDir}**/*.md`);
  configMd = configMd.filter((filepath) => {
    //filter out other xxx.{other env}.md
    let name = filepath.match(new RegExp(`[^/]+\\.md$`), 'g')[0].replace('.md', ''); //name = xxx.{other env} or xxx or xxx.{env}
    return (name.match(/^[^\.]+$/g) || name.match(new RegExp(`^[^\\.]+\\.${env}$`), 'g'));
  });
  console.log(`Potential config files = ${configMd}`);

  //detect any env specific xxx.{env}.md to override default xxx.md
  let configToSkip = [];
  if (env) {
    configMd.forEach((filepath) => {
      let envSpecificFile = filepath.match(new RegExp(`[^/]+\\.${env}\\.md$`), 'g');
      if (envSpecificFile)
        configToSkip.push(envSpecificFile[0].replace(`.${env}.md`, ''));
    });
  }

  console.log(`Config files will be overriden by env specific:\n ${configToSkip}\n`);

  configMd.filter((filepath) => {
    //check if need to override
    let filename = filepath.match(new RegExp(`[^/]+\\.md$`), 'g');
    let overridden = configToSkip.includes(filename[0].replace('.md', ''));
    console.log(overridden ? `${filepath} : is overridden by ${env} specific config` : `${filepath} : going to parse `);
    return !overridden;
  }).forEach((filepath) => {
    outputs.push(parseConfig(filepath));
  });

  configMd = glob.sync(`${inputItConfigDir}**/*.md`);
  configMd.forEach((filepath) => {
    console.log(`${filepath} : going to parse `);
    outputs.push(parseConfig(filepath));
  });
  let outputObj = merge.all(outputs);
  // console.log('outputObj', outputObj);

  //write all config to file
  for (var name in outputObj) {
    let outFile = outputConfigDir + name + '.js';
    //console.log("write file : " + outFile);
    //console.log(`${JSON.stringify(outputObj[name], null, 2)}`);
    //moment().zone(8);

    fs.mkdirSync(outputConfigDir, { recursive: true });
    // mkdirp.sync(path.dirname(outFile));

    let ts = df.format(new Date(), 'yyyy-MM-dd, h:mm:ss a z');
    let header = `//generated at ${ts} by parseBusinessConfig.js.//From ${inputBizConfigDir}/*.md and ${inputItConfigDir}/*.md\n//DO NOT MODIFY THIS FILE DIRECTLY`;
    fs.writeFileSync(outFile, `${header}\n\nexport default ${JSON.stringify(outputObj[name], null, 2)};`);
  }

};
buildConfig();
// export default buildConfig;
