# Pas Next Gen (RM Online Journey)

## 1 Overall
### 1.1 What is the currency to be used? <!--config.pas.currencyCodeForInputField-->`HKD`

### 1.2 What are the functionality to the customer (based on customer segment):

| Rules based on type of journey: | All Products | UT only |
| --     | --| --     |
| Customer Segment | (`['J']`)<br>Jade | (`['P']`)<br>Premier |
| Account selection |  Integrated account + UT standalone account (to be configured in 1.3) | InvestmentTab account 380 + UT standalone account(to be configured in 1.3) |
| PAS NexGen All portfolio analysis zoom-in indicator | Y | N/A | 
| Asset product type in current portfolio (dashboard type)| `UT, BOND, SEC, LCYDEP, FCYDEP` <br>(for AMH 2019 March Release<br>- exclude product type :`` <br>- exclude product subtype : `ELI-PPN*`<br>- exclude overseas securities by hard code because not yet supported)<br>- exclude negative cash (by hard code) | `UT` |
| - allow buy | UT, BOND, new dummySP <br>(not allow  buy SEC, temp. FE control, long term WPC app-channel restriction | UT only |
| - sell | existing UT, BOND, SEC, WRTS <br>(TMD, SP are not supported to be sold normally thou feasible, by PAS FE+FPS hard-code/it config) | UT only |
| Reference portfolio Mix ( by control data of customer segment) | Jade reference | non-Jade reference |
| Risk profile for rebalancing journey | `0-5` | `1-5` |
| InvestmentTab Preference Validation | remove blocking on PAS-1454 (based on allowing risk =0) | all validations (due to riskRange >0 ) |
| Core Asset types | GBL_EQ,APEJE,GBL_FI,GBL_HY,THM | GBL_EQ,APEJE,GBL_FI,GBL_HY,THM |
| DashBoard exposure : Current exposure display by cosmetic(Y) or pie chart(N)?  | Y | Y |
| Discussed checkBox : Disable Rebalance step3 checkBox by product type | 'SEC,WRTS,ELI,SID,DPS' | N/A |
| Health Check Report : Make DashBoard page to show Health Check Report link | Y | N/A |
| Health Check Report : PAS Health Check report remote call PAS API with v2 method?  | N | N/A | 
| Health Check Report : get the Health check report by open pdf directly (Y) or download pdf (N)? | Y | N/A | 

<!--config.pas.journeyType.allProducts.customerSegment-->`['J']`
<!--config.pas.journeyType.utOnly.customerSegment-->`['P']`
<!--config.pas.journeyType.allProducts.productDashboardTypes-->`UT,BOND,SEC,SI,LCYDEP,FCYDEP`
<!--config.pas.journeyType.allProducts.excludeProductTypes-->``
<!--config.pas.journeyType.allProducts.excludeProductSubTypes-->`ELI-PPN*`
<!--config.pas.journeyType.allProducts.assetClassGroup-->`GBL_EQ,APEJE,GBL_FI,GBL_HY,THM,MULT_ASTS,OTH_FUND,CASH`
<!--config.pas.journeyType.utOnly.assetClassGroup-->`GBL_EQ,APEJE,GBL_FI,GBL_HY,THM,MULT_ASTS,OTH_FUND`
<!--config.pas.journeyType.utOnly.productDashboardTypes-->`UT`
<!--config.pas.journeyType.allProducts.riskRange-->`0-5`
<!--config.pas.journeyType.utOnly.riskRange-->`1-5`
<!--config.pas.coreAssetType-->`GBL_EQ,APEJE,GBL_FI,GBL_HY,THM`
<!--config.pas.enableExposureCosmetic-->`Y`
<!--config.pas.enableHealthCheckReport-->`Y`
<!--config.pas.disableDiscussBox-->`SEC,WRTS,ELI,SID,DPS`
<!--config.pas.usePasApiV2RemoteCall-->`Y`
<!--config.pas.downloadHCReportBinary-->`N`
<!--config.pas.enableAllPortfolioZoomIn-->`Y`

#### 1.2.1 If I add product, which PAS asset classes could the customer choose?

##### Explain
When you add product, there are product type filter and PAS asset class filter in the dialog. For example, for asset classe "Global Equity Ex Japan", you would be able to add UT and SEC, WRTS, but BOND will never be grouped into "Global Equity Ex Japan".

<!--config.pas.productTypeAssetClassMapping:START-->
| Product Type | Include/Exclude | PAS Asset Class L2 | Remarks |
|-- | -- | -- | -- |
| UT | EXCLUDE | OT_ETF,OT_CBBC,OT_WRTS,OT_DPS,OT_ELI,OT_SID,OT | all asset classes except SP |
| BOND | INCLUDE | GO,HL | part of Bond &others tab<br> Global Fixed income (core) , Global High Yield(core) only |
| ELI | INCLUDE | OT_ELI | part of Bond &others tab |
| SID | INCLUDE | OT_SID | part of Bond &others tab |
| DPS | INCLUDE | OT_DPS | part of Bond &others tab |

<!--config.pas.productTypeAssetClassMapping.utExcludeList--> `OT_ETF,OT_CBBC,OT_WRTS,OT_DPS,OT_ELI,OT_SID,OT`
<!--config.pas.productTypeAssetClassMapping.nonUtIncludeList--> `GO,HL,OT_ELI,OT_SID,OT_DPS`

<!--config.pas.productTypeAssetClassMapping:END-->
Note: OT_WRTS, OT_CBBC, OT_ETF belongs to Equity and is not supported in add product.

#### 1.2.2 If select customer productTypes for PAS journey, single productType category config? 
##### single productType config

<!--config.pas.singleProductTypeConfig:metadata
{
"method":"MARKDOWN_TABLE_TO_JSON",
"columns":["productDashboardType", "riskRange", "assetClassGroup"],
"configParser": "parseColumnToKey",
"keyColumn": "productDashboardType"
}
metadata-->

<!--config.pas.singleProductTypeConfig:START-->
| Product Dashboard Type | Risk Range | Asset Class Group |
|-- | -- | -- |
| UT | 1-5| GBL_EQ,APEJE,GBL_FI,GBL_HY,THM,MULT_ASTS,OTH_FUND |
| BOND | 1-5 | GBL_EQ,APEJE,GBL_FI,GBL_HY,THM,MULT_ASTS,OTH_FUND |
| SEC | 1-5 | GBL_EQ,APEJE,GBL_FI,GBL_HY,THM,MULT_ASTS,OTH_FUND |
| SI | 1-5 | GBL_EQ,APEJE,GBL_FI,GBL_HY,THM,MULT_ASTS,OTH_FUND |
| LCYDEP | 0-5 | CASH |
| FCYDEP | 0-5 | CASH |
<!--config.pas.singleProductTypeConfig:END-->

### 1.3 Which account types will be enabled in PAS Journey?
<!--config.pas.accountType:metadata
{
"method":"MARKDOWN_TABLE_TO_JSON",
"columns":["", "", "acctType", "acctProdType", "acctFormat", "isAllowSelect", "isAllowRebalance", "bundleDec","tealiumAccountTypeDesc"],
"configParser": "parseAccountTypeConfig",
"keyColumn": ""
}
metadata-->

<!--config.pas.accountType:START-->
| Account Description | Group Member | Product Type | Product Code | Account Format | Eligible for Account Selection | Eligible for re-balancing service | Bundle Account Description | Tealium Account Type Description |
| --     | --| --     | --| --     | --| --  | --     | -- |
| HSBC Premier InvestmentTab Services | HBAP | SEC | AVA | NNN-NNNNNC-NNN | YES | YES | | AVA |
| HSBC Premier InvestmentTab Services | HBAP | SEC | AVF | NNN-NNNNNC-NNN | YES | YES | | AVF |
| HSBC Premier InvestmentTab Services | HBAP | SEC | AVT | NNN-NNNNNC-NNN | YES | YES | | AVT |
| HSBC InvestmentTab Service | HBAP | SEC | HPS | NNN-NNNNNC-NNN | YES | YES | | HPS |
| HSBC InvestmentTab Service | HBAP | SEC | INF | NNN-NNNNNC-NNN | YES | YES | | INF |
| HSBC InvestmentTab Service | HBAP | SEC | INS | NNN-NNNNNC-NNN | YES | YES | | INS |
| HSBC InvestmentTab Service | HBAP | SEC | INT | NNN-NNNNNC-NNN | YES | YES | | INT |
| HSBC InvestmentTab Service | HBAP | SEC | INV | NNN-NNNNNC-NNN | YES | YES | | INV |
| HSBC InvestmentTab Service | HBAP | SEC | MAV | NNN-NNNNNC-NNN | YES | YES | | MAV |
| HSBC InvestmentTab Service | HBAP | SEC | MPV | NNN-NNNNNC-NNN | YES | YES | | MPV |
| HSBC InvestmentTab Service | HBAP | SEC | MSV | NNN-NNNNNC-NNN | YES | YES | | MSV |
| HSBC InvestmentTab Service | HBAP | SEC | OSS | NNN-NNNNNC-NNN | YES | YES | | OSS |
| HSBC InvestmentTab Service | HBAP | SEC |  *  | NNN-NNNNNC-NNN | YES | YES | | SEC |
| Unit Trust HKD Financing | HBAP | SEC | *  | NNN-NNNNNC-368 | YES | NO | | 368 |
| Unit Trust USD Financing | HBAP | SEC | *  | NNN-NNNNNC-369 | YES | NO | | 369 |
| Legacy investment        | HBAP | SEC | *  | NNN-NNNNNC-381 | YES | NO | | 381 |
| Legacy investment        | HBAP | SEC | *  | NNN-NNNNNC-383 | YES | NO | | 383 |
| Legacy investment        | HBAP | SEC | *  | NNN-NNNNNC-393 | YES | NO | | 393 |
| Overseas securities      | HBAP | SEC | *  | NNN-NNNNNC-386 | NO | NO | | 386 |
| Securities margin        | HBAP | SEC | *  | NNN-NNNNNC-388 | NO | NO | | 388 |
| Legacy investment        | HBAP | SEC | *  | NNN-NNNNNC-085 | NO | NO | | SEC |
| HSBC InvestmentTab Service | HBAP | SEC | SEC | NNN-NNNNNC-085 | NO  | NO | | 085 |
| HSBC InvestmentTab Service | HBAP | SEC |  *  | NNN-NNNNNC-085 | NO  | NO | | 085 |
| HSBC Personal Integrated Account InvestmentTab Services | HBAP | SEC | SVA | NNN-NNNNNC-NNN | YES | YES | | SVA |
| HSBC Advance InvestmentTab Services | HBAP | SEC | YPF | NNN-NNNNNC-NNN | YES | YES | | YPF |
| HSBC Advance InvestmentTab Services | HBAP | SEC | YPO | NNN-NNNNNC-NNN | YES | YES | | YPO |
| HSBC Advance InvestmentTab Services | HBAP | SEC | YPP | NNN-NNNNNC-NNN | YES | YES | | YPP |
| HSBC Advance InvestmentTab Services | HBAP | SEC | YPT | NNN-NNNNNC-NNN | YES | YES | | YPT |
| HSBC InvestmentTab Services | HBAP | POR | * | NNN-NNNNNC-NNN | YES | YES | Portfolio | POR |
| HSBC InvestmentTab Services | HBAP | POR | * | NNN-NNNNNC-393 | YES | NO | | 393
| HSBC InvestmentTab Services | HBAP | POR | HPO | NNN-NNNNNC-NNN | YES | YES | | HPO |
| HSBC InvestmentTab Services | HBAP | POR | PPO | NNN-NNNNNC-NNN | YES | YES | | PPO |
| HSBC InvestmentTab Services | HBAP | SEC | HPO | NNN-NNNNNC-NNN | YES | YES | | HPO |
| HSBC InvestmentTab Services | HBAP | SEC | PPO | NNN-NNNNNC-NNN | YES | YES | | PPO |
| HSBC InvestmentTab Services | HBAP | SEC | PPO | NNN-NNNNNC-NNN | YES | YES | | PPO |
| HSBC Premier Saving Account | HBAP | SAV | AVA | NNN-NNNNNC-NNN | YES | YES | HSBC Premier Integrated Account | AVA |
| HSBC Premier Saving Account | HBAP | SAV | AVF | NNN-NNNNNC-NNN | YES | YES | HSBC Premier Integrated Account | AVF |
| HSBC Premier Saving Account | HBAP | SAV | AVT | NNN-NNNNNC-NNN | YES | YES | HSBC Premier Integrated Account | AVT |
| HSBC Personal Saving Account | HBAP | SAV | SVA | NNN-NNNNNC-NNN | YES | YES | HSBC Personal Integrated Account | SVA |
| HSBC Advance Saving Account | HBAP | SAV | YPF | NNN-NNNNNC-NNN | YES | YES | HSBC Advance Integrated Account  | YPF |
| HSBC Advance Saving Account | HBAP | SAV | YPO | NNN-NNNNNC-NNN | YES | YES | HSBC Advance Integrated Account | YPO |
| HSBC Advance Saving Account | HBAP | SAV | YPP | NNN-NNNNNC-NNN | YES | YES | HSBC Advance Integrated Account | YPP |
| HSBC Advance Saving Account | HBAP | SAV | YPT | NNN-NNNNNC-NNN | YES | YES | HSBC Advance Integrated Account | YPT |
| HSBC Saving Account | HBAP | SAV | * | NNN-NNNNNC-NNN | NO | NO | | SAV |
| HSBC Current Account | HBAP | CIF | * | NNN-NNNNNC-NNN | NO | NO | | CIF |
| HSBC Foreign Currency Account | HBAP | FCA | * | NNN-NNNNNC-NNN | NO | NO | | FCA |
| HSBC InvestmentTab Services | HBAP | GLD | * | NNN-NNNNNC-NNN | NO | NO | | GLD |
| HSBC Fixed/Time Deposit | HBAP | TMD | * | NNN-NNNNNC-NNN | NO | NO | | TMD |
<!--config.pas.accountType:END-->

### 1.3 RBWMnet link in RiskBar Page
#### RBWMnet link in RiskBar Page
|Locale | URL| Customer Type |
| --    | --| --|
|EN_US | <!--config.pas.riskbarUrl.RBWMnetlink_en_us-->`https://www.hfi.hsbc.com.hk/data/hk/invest/unit/ut_ut-doc7_refassetmixjc_bl.pdf`|JADE|
|ZH_CN | <!--config.pas.riskbarUrl.RBWMnetlink_zh_cn-->`https://www.hfi.hsbc.com.hk/data/hk/invest/unit/ut_ut-doc7_refassetmixjc_bl.pdf`|JADE|
|ZH_HK | <!--config.pas.riskbarUrl.RBWMnetlink_zh_hk-->`https://www.hfi.hsbc.com.hk/data/hk/invest/unit/ut_ut-doc7_refassetmixjc_bl.pdf`|JADE|
|EN_US | <!--config.pas.riskbarUrlForNonJade.RBWMnetlink_en_us-->`https://www.hfi.hsbc.com.hk/data/hk/invest/unit/ut_ut-doc7_refassetmixnjc_bl.pdf`|NONJADE|
|ZH_CN | <!--config.pas.riskbarUrlForNonJade.RBWMnetlink_zh_cn-->`https://www.hfi.hsbc.com.hk/data/hk/invest/unit/ut_ut-doc7_refassetmixnjc_bl.pdf`|NONJADE|
|ZH_HK | <!--config.pas.riskbarUrlForNonJade.RBWMnetlink_zh_hk-->`https://www.hfi.hsbc.com.hk/data/hk/invest/unit/ut_ut-doc7_refassetmixnjc_bl.pdf`|NONJADE|


### 1.4 utonly accounts
####  utonly accounts
If account number suffix is `383` or `393` ,only UT product should be available as a selection option
<!--config.pas.utonlyAccounts-->
```javascript
[
   "383",
   "393"
]
```

### 1.5 scenario config
####  scenario config
Make DashBoard scenario page to be an iterable component
(#scenarioDefaultListConfig):
<!--config.pas.scenarioDefaultListConfig-->
```javascript
[
    { "key": "GLBEQ_UP10", "shortname":"equityMarketUp"},
    { "key": "HKGEQ_DN10", "shortname":"hkStockMarketDrop"},
    { "key": "CVIRUS_GC", "shortname":"coronavirusGlobalContagion"},
    { "key": "DXY_UP5", "shortname":"usdUp"}
]
```

## 2 Rebalancing
### 2.1 Threshold on Allocation gap

#### Explain:
During rebalacing, if user new holding amount after buy/sell is still far from target, then off target warning is shown.
The gap for each asset class is measured as:  sum of (new holding amount after buy/sell) - target amount
Example:
customer current holding on Global fixed income = 

|**Step 1 +2 input target:**| Current Amount | Target Input |
| --     | ---:| ---:|
|Single Asset class |$200,000  | **$600,000**|
| - Global Equity |$0 | **20**% |
| - Asia Equity Ex Japan |$0 | **0**% |
| - Global Fixed Income |$200,000 | **50**% |
| - Global High Yield |$0 | **20**% |
| - Thematic | $0 | **10**% |
|Multi Asset class | $0 | **$300,000**|
|Other Funds |  $0 | **$100,000** |
|Total target<br>(sum of above) |$0 | $1,000,000|
|**That means** | Current Amount | Target Amount |
| Global Fixed income amount: | $200,000 |$600,000 * 50% <br>=$300,000 |
| .. | ..| ..|
|**Then In Step 3** | | |
| Target Buy/Sell | = $300,000-$200,000 | =$100,000 (buy)|
| To be purchased |                     | =$100,000 (buy)|
|**if user add product:** | buy bond A | $50000 |
| To be purchased | = $100,000 - $50,000  | = $50,000 |

In this case, **Gap of Global Fixed Income = Absolute(to be purchased)/Total target amount **
 = $50,000
Gap Percentage = gap / new target portfolio 
 = $50,000 / $1,000,000 = 5%
If the gap is too big, then the category is regarded as off target

#### How big is off target?
If for any 1 of the category Abs(gap > `0.01` * of target new portfolio AND (gap > `5000`)
then the category is off target.
<!--config.pas.rebalance.target.thresholdPercentage-->`0.01`
<!--config.pas.rebalance.target.thresholdAmount-->`5000`

*0.01 means 1%

### 2.2 RBWMnet link for Adjust your holding amount page
#### RBWMnet link in Adjust your holding amount page(Step 1 .More information)
|Locale | URL| Customer Type |
| --    | --| --|
|EN_US | <!--config.pas.rebalancing.MoreInformationUrl_en_us-->`http://hk-web-315.hk.hsbc/apps/pfsnet/invFileStore.nsf/AllFiles/PASNexGen005/$file/Jade%20Reference%20Asset%20Mix%20-%20Market%20Update%20and%20Performance_EN.pdf`|JADE|
|ZH_CN | <!--config.pas.rebalancing.MoreInformationUrl_zh_cn-->`http://hk-web-315.hk.hsbc/apps/pfsnet/invFileStore.nsf/AllFiles/PASNexGen002002/$file/Jade%20Reference%20Asset%20Mix%20-%20Market%20Update%20and%20Performance_SC.pdf`|JADE|
|ZH_HK | <!--config.pas.rebalancing.MoreInformationUrl_zh_hk-->`http://hk-web-315.hk.hsbc/apps/pfsnet/invFileStore.nsf/AllFiles/PASNexGen003/$file/Jade%20Reference%20Asset%20Mix%20-%20Market%20Update%20and%20Performance_TC.pdf`|JADE|
|EN_US | <!--config.pas.rebalancing.MoreInformationUrl_NonJade_en_us-->`http://hk-web-315.hk.hsbc/apps/PFSnet/invFileStore.nsf/AllFiles/PASNexGenNonJade/$file/Non%20Jade%20Reference%20Asset%20Mix%20-%20Market%20Update%20and%20Performance_EN.pdf`|NONJADE|
|ZH_CN | <!--config.pas.rebalancing.MoreInformationUrl_NonJade_zh_cn-->`http://hk-web-315.hk.hsbc/apps/PFSnet/invFileStore.nsf/AllFiles/PASNexGenNonJade001/$file/Non%20Jade%20Reference%20Asset%20Mix%20-%20Market%20Update%20and%20Performance_SC.pdf`|NONJADE|
|ZH_HK | <!--config.pas.rebalancing.MoreInformationUrl_NonJade_zh_hk-->`http://hk-web-315.hk.hsbc/apps/PFSnet/invFileStore.nsf/AllFiles/PASNexGenNonJade002/$file/Non%20Jade%20Reference%20Asset%20Mix%20-%20Market%20Update%20and%20Performance_TC.pdf`|NONJADE|


### 2.3 standard email template link for health check report
|Locale | URL|
| --    | --|
|EN_US | <!--config.pas.healthCheckReport.EmailTemplateUrl_en_us-->`http://hk-web-315.hk.hsbc/apps/pfsnet/invFileStore.nsf/AllFiles/PASHCReportEmailTemplateEN/$file/PAS%20Health%20Check%20Report%20Email%20Template_EN.docx`|
|ZH_CN | <!--config.pas.healthCheckReport.EmailTemplateUrl_zh_cn-->`http://hk-web-315.hk.hsbc/apps/pfsnet/invFileStore.nsf/AllFiles/PASHCReportEmailTemplateSC/$file/PAS%20Health%20Check%20Report%20Email%20Template_SC.docx`|
|ZH_HK | <!--config.pas.healthCheckReport.EmailTemplateUrl_zh_hk-->`http://hk-web-315.hk.hsbc/apps/pfsnet/invFileStore.nsf/AllFiles/PASHCReportEmailTemplateTC/$file/PAS%20Health%20Check%20Report%20Email%20Template_TC.docx`|
 
