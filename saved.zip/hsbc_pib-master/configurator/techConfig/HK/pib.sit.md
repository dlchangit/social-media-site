### PIB Config


### 0. Dashboard
<!--config.pib.dashboard-->


### 1. Transaction History

#### Please ensure the key has a valid translation 
<!--config.pib.transactionHistory.filter.productType-->
```javascript
[
"all",
"bondsAndCds",
"capitalProtectedInvestments",
"cash",
"depositPlus",
"eliAndStructuredNotes",
"flexInvest",
"stocks",
"timeDeposits",
"unitTrust",
"others"
]
```

<!--config.pib.transactionHistory.filter.orderPlacedVia-->
```javascript
[
  "all",
  "internet",
  "automatedPhoneBanking",
  "personalPhoneBanking",
  "mobileBanking",
  "branches",
  "sweep"
]
```

<!--config.pib.transactionHistory.filter.transactionType-->
```javascript
[
  "all",
  "buy",
  "sell",
  "stopLossLimit",
  "switch",
  "targetBuySell",
  "twoWayLimit"
]
```

<!--config.pib.transactionHistory.filter.dateRange.minDate-->
```javascript
{ "years": -3 }
```

<!--config.pib.transactionHistory.filter.dateRange.maxDate-->
```javascript
{ "years": 0 }
```
<!--config.pib.transactionHistory.filter.dateRange.default.from-->
```javascript
{ "months": -3 }
```

<!--config.pib.transactionHistory.filter.dateRange.default.to-->
```javascript
{ "months": 0 }
```

<!--config.pib.transactionHistory.showRecords-->
```javascript
[
  10, 20, 30
]
```

### 2. Realised Gain/Loss
#### The first one is the default value
<!--config.pib.realisedGainLoss.currency-->
```javascript
[
  "hkd",
  "usd",
  "jpy",
  "eur",
  "aud"
]
```


#### Please ensure the key has a valid translation
<!--config.pib.realisedGainLoss.filter.productType-->
```javascript
[
"all",
"bondsAndCds",
"capitalProtectedInvestments",
"cash",
"depositPlus",
"eliAndStructuredNotes",
"flexInvest",
"stocks",
"timeDeposits",
"unitTrust",
"others"
]
```


### 2. My Holdings
#### The first one is the default value
#### Please ensure the key has a valid translation
#### also CHANGE enum CurrencyCodeType
<!--config.pib.myHoldings.filter.currency-->
```javascript
[
  "denominatedCurrency",
  "homeCurrency"
]
```


#### The first one is the default value
#### Please ensure the key has a valid translation
<!--config.pib.myHoldings.filter.productType-->
```javascript
[
"unitTrust",
"bondsAndCds",
"capitalProtectedInvestments",
"cash",
"depositPlus",
"eliAndStructuredNotes",
"flexInvest",
"stocks",
"timeDeposits",
"others"
]
```

#### Minimum date of the filter, format: https://date-fns.org/v2.17.0/docs/add
<!--config.pib.realisedGainLoss.filter.dateRange.minDate-->
```javascript
{ "years": -3 }
```

<!--config.pib.realisedGainLoss.filter.dateRange.maxDate-->
```javascript
{ "years": 0 }
```
<!--config.pib.realisedGainLoss.filter.dateRange.default.from-->
```javascript
{ "months": -3 }
```

<!--config.pib.realisedGainLoss.filter.dateRange.default.to-->
```javascript
{ "months": 0 }
```

