const { when, whenDev, whenProd, whenTest, ESLINT_MODES, POSTCSS_MODES } = require('@craco/craco');

module.exports = {
  babel: {
    plugins: [
      // '@babel/plugin-transform-proto-to-assign',
      // '@babel/plugin-proposal-class-properties',
      // '@babel/plugin-transform-object-set-prototype-of-to-assign',
      '@babel/plugin-transform-async-to-generator',
      [
        '@babel/plugin-transform-runtime',
        {
          corejs: { version: 3, proposals: true },
          helpers: true,
          regenerator: false,
        },
      ],
    ],
    presets: [
      ['@babel/preset-env', {
        useBuiltIns: 'usage',
        corejs: {
          version: 3,
          proposals: true,
        },
      }],
    ],
    loaderOptions: {
      exclude: [
        /\bcore-js\b/,
        /\bwebpack\/buildin\b/,
        /@babel\/runtime-corejs3/,
      ],
    },
  },
  jest: {
    configure(config) {
      config.transformIgnorePatterns = [
        '[/\\\\]node_modules[/\\\\](?!(@amcharts)\\/).+\\.(js|jsx|ts|tsx)$',
      ];
      return config;
    },
  },
  style: {
    css: {
      loaderOptions: (cssLoaderOptions, { env, paths }) => {
        cssLoaderOptions.modules = {
          auto: /\.module\.\w+$/i,
          localIdentName: '[name]_[local]--[hash:base64:5]',
          exportLocalsConvention: 'camelCase',
        };
        return cssLoaderOptions;
      },
    },
  },
  devServer: {
    proxy: {
      '/api': 'http://localhost:3001',
    },
  },
  plugins: [],
};
