const path = require('path');
module.exports = {
  'stories': [
    '../src/**/*.stories.mdx',
    '../src/**/*.stories.@(js|jsx|ts|tsx)',
  ],
  'addons': [
    '@storybook/addon-links',
    '@storybook/addon-essentials',
    '@storybook/preset-create-react-app',
    // '@storybook/preset-scss',
  ],
  typescript: {
    check: true,
    checkOptions: {},
    reactDocgen: 'react-docgen-typescript',
    reactDocgenTypescriptOptions: {
      shouldRemoveUndefinedFromOptional: true,
      propFilter: (prop) => (prop.parent ? !/node_modules/.test(prop.parent.fileName) : true),
    },
  },

  webpackFinal: async (config, { configType }) => {
    // `configType` has a value of 'DEVELOPMENT' or 'PRODUCTION'
    // You can change the configuration based on that.
    // 'PRODUCTION' is used when building the static version of storybook.
    const oneOfRule = config.module.rules.find(rule => rule.oneOf);
    oneOfRule.oneOf.forEach(rule => {
      // if the rule handles CSS or SASS modules
      if (!rule.exclude && (".module.css".match(rule.test) || ".module.scss".match(rule.test))) {
        // look for css loader
        const cssLoader = rule.use.find(use => use.loader && use.loader.match(/\/css-loader\//));

        cssLoader.options = {
          ...cssLoader.options,
          modules: {
            ...cssLoader.options.modules,
            exportLocalsConvention: "camelCase",
          }
        };
      }
    });

    return config;
  },
};
